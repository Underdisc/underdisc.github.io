/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file DestroyOnContact.h
\author Gabe Miller
\par E-mail: g.miller\@digipen.edu
\par Project: Boat Game
\date 11/2/2016 1:00:05 PM
\brief
*/
/*****************************************************************************/
#pragma once

#ifndef DestroyOnContact_H
#define DestroyOnContact_H

#include "Component.h"

/*****************************************************************************/
/*!
\class DestroyOnContact
\brief


\par
	Operations include:
	-

\deprecated
	-

\bug
	-
*/
/*****************************************************************************/
class DestroyOnContact : public Component
{
public:
  void Update();
  DestroyOnContact();
private:
};


Component * CreateDestroyOnContact(Json::Value value);

#endif
/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file EnemyHealth.cpp
\author Gabe Miller
\par E-mail: g.miller\@digipen.edu
\par Project: Boat Game
\date 3/16/2017 3:47:53 PM
\brief

\par
Functions Include:
-
*/
/*****************************************************************************/

#include "EnemyHealth.h"
#include "Object.h"
#include "AudioEngine.h"
#include "GameObjectManager.h"
#include "Transform.h"

// *** ID for enemy damaged event *** //
const std::string EnemyDamaged::ID = "EnemyDamaged";
const std::string EnemyDamaged::DeathID = "EnemyDead";

EnemyHealth::EnemyHealth(int health) : Component("EnemyHealth"), _health(health)
{

}

void EnemyHealth::Init()
{
  Owner().SubscribeCallback(EnemyDamaged::ID, std::bind(&EnemyHealth::Damaged, this, std::placeholders::_1));
}

void EnemyHealth::Damaged(Event * damagedEvent)
{
  // For events with additional data, you will need to cast the pointer type.
  // This is why it is very important that each event has a unique ID.
  // For best results, use the name of the derived class.
  EnemyDamaged * _event = static_cast<EnemyDamaged *>(damagedEvent);
  // Using the data
  _health -= _event->damage;

  if (_health <= 0)
  {
    Event EnemyDead(EnemyDamaged::DeathID);
    Owner().DispatchEvent(&EnemyDead);
    Owner().ObjectManager()->DeleteObject(&Owner());
    return;
  }
}

int EnemyHealth::GetHealth()
{
  return _health;
}

Component * CreateEnemyHealthComponent(Json::Value value)
{
  int health = value["health"].asInt();
  return new EnemyHealth(health);
}
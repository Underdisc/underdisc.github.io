/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file BoatShoot.h
\author Gabe Miller
\par E-mail: g.miller\@digipen.edu
\par Project: Boat Game
\date 11/18/2016 4:27:36 PM
\brief
*/
/*****************************************************************************/
#pragma once

#ifndef BoatShoot_H
#define BoatShoot_H

#include "Component.h"
#include "Transform.h"
#include <vector>

struct Gun
{
  Gun(float fireRate, int damage, std::string archetype) :
    fireRate(fireRate), damage(damage), archetype(archetype)
  {}
  // ! In rounds per second
  float fireRate;
  // ! In health points
  int damage;
  // ! Archetype of the projectile
  std::string archetype;
};

/*****************************************************************************/
/*!
\class BoatShoot
\brief


\par
	Operations include:
	-

\deprecated
	-

\bug
	-
*/
/*****************************************************************************/
class BoatShoot : public Component
{
public:
  BoatShoot(std::string shootEvent);
  void Init();
  void Update();
  void ChangeGun(int index, std::string archetype, const Gun & gunProperties);
private:
  Object * _reticule;
  Object * _cursor;
  Object * _line1;
  Object * _line2;
  float _cooldown;
  std::string _shootEvent;
  std::vector<Gun> _guns;
  std::vector<Object *> _gunObjects;
  int _currentGun;
  int _gunSelected;
  std::vector<Object *> _swivels;
  static bool _autoplay;
  bool autoplaykeypressed;
  Object * _indicator;
  float _time;
};


Component * CreateBoatShootComponent(Json::Value value);

#endif
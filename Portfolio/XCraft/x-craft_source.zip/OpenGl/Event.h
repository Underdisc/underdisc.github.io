/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#pragma once
/*****************************************************************************/
/*!
\file Event.h
\author Matt Chasengnou
\par E-mail: chasengnou.m@digipen.edu
\par Project: Boat Game
\date 10/7/2016 2:31:51 PM
\brief
*/
/*****************************************************************************/

#ifndef Event_H
#define Event_H

#include <string>
#include <functional>

/*****************************************************************************/
/*!
\class Event
\brief
Base class for events. When deriving a new event from this, make sure it has its
own unique event ID. 

\par
Operations include:
-

\deprecated
-

\bug
-
*/
/*****************************************************************************/
struct Event
{
  // Constructors
  Event(std::string eventID) : _eventID(eventID) {}

  std::string _eventID;   // Identifier tag for the event
};

typedef std::function<void(Event *)> eventFunction;

#endif Event_H
/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file ArchetypeManager.h
\author Gabe Miller
\par E-mail: g.miller\@digipen.edu
\par Project: Boat Game
\date 10/14/2016
\brief
  Interface file for the archetype manager, which loads in archetypes and
  creates objects from archetypes.
*/
/*****************************************************************************/
#pragma once
#ifndef ARCHETYPE_MANAGER_H
#define ARCHETYPE_MANAGER_H

#include "Object.h"
#include <string>
#include <map>
#include <glm/glm.hpp>
#include <json/json.h>
#include "GameObjectManager.h"

/*****************************************************************************/
/*!
\class Archetype Manager
\brief
  Manages deserialization and creation of archetyped objects.

\par
    Operations include:
    -Initialize the archetype manager
    -Create a new object from an archetype
    -Create a new object, and set its position

\deprecated
    -

\bug
    -
*/
/*****************************************************************************/
class ArchetypeManager
{
public:
  void InitArchetypes();
private:
  /*! Contains a copy of all archetype game objects,
    linked to an identifying archetype name.*/
  std::map<std::string, Json::Value> _archetypeObjects;
  Object *CreateArchetypeObject(std::string archetype, GameObjectManager * objManager);
  Object *CreateArchetypeObjectAtPosition(std::string archetype, GameObjectManager * objManager, glm::vec3 position);
  friend Object * GameObjectManager::CreateArchetypeObject(std::string archetype);
  friend Object * GameObjectManager::CreateArchetypeObjectAtPosition(std::string archetype, glm::vec3 position);
};



extern ArchetypeManager archetypeManager;

#endif

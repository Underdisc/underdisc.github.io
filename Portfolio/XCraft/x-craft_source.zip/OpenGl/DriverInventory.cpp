/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#include "DriverInventory.h"

void DriverInventory::Allocate()
{

}

void DriverInventory::Load()
{

}

bool DriverInventory::Update()
{
    
  

  return true;
}
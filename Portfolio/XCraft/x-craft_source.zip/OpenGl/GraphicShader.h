/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file GraphicShader.h
\author Connor Deakin
\par E-mail: connor.deakin\@digipen.edu
\par Project: Graphics
\date 07/03/2017
\brief
  Contains the interface for the GraphicShader. Look at the GraphicShader
  class for more information.
*/
/*****************************************************************************/

#ifndef GRAPHICSHADER_H
#define GRAPHICSHADER_H

#include <string>

#include "Graphic.h"
#include "Shader.h"

/*****************************************************************************/
/*!
\class GraphicShader
\brief
  Shader used for displaying a Graphic.
*/
/*****************************************************************************/
class GraphicShader : public Shader
{
  public:
    GraphicShader(const std::string & vert_file, const std::string & frag_file,
                  const Graphic & graphic);
    GLint PositionA() const;
    GLint TransformationU() const;
    GLint ColorU() const;
  private:
    //! The location of the Shader's position attribute.
    GLint _position_A;
    //! The location of the Shader's transformation uniform.
    GLint _transformation_U;
    //! The location of the Shader's color uniform.
    GLint _color_U;
};

#endif // !DEFAULTSHADER_H


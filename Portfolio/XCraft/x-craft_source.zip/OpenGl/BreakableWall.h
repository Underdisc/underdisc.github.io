/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#pragma once
/*****************************************************************************/
/*!
\file BreakableWall.h
\author Jonathan Williams
\par E-mail: jonathan.w@digipen.edu
\par Project: Boat Game
\date 3/13/2017 4:38:38 PM
\brief
*/
/*****************************************************************************/

#ifndef BreakableWall_H
#define BreakableWall_H

#include "Component.h"
#include "Enemy.h" // Damaged event.

/*****************************************************************************/
/*!
\class BreakableWall
\brief


\par
	Operations include:
	-

\deprecated
	-

\bug
	-
*/
/*****************************************************************************/

class BreakableWall : public Component
{
public:
	BreakableWall();
	void Update();
  void Init();
  void Damaged(Event * damagedEvent);
  void Dead(Event * deadEvent);
private:
};

Component* CreateBreakableWallComp(Json::Value value_);


#endif

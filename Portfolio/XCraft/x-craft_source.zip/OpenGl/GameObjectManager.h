/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file GameObjectManager.h
\author Gabe Miller
\par E-mail: g.miller\@digipen.edu
\par Project: Boat Game
\date 10/7/2016
\brief
  This is the interface file for the game object manager.
*/
/*****************************************************************************/

#pragma once
#ifndef GAME_OBJECT_MANAGER_H
#define GAME_OBJECT_MANAGER_H

#include "Object.h"
#include "spaceID.h"
#include <vector> // Container for game objects
#include <string> // Object name
#include <glm\glm.hpp>

#include "CollisionManager.h"

/*****************************************************************************/
/*!
\class GameObjectManager
\brief
  This is the game object manager class, which contains all game objects,
  as well as functions to interact with those objects.

\par
  Operations include:
  -Make a new object
  -Delete an object
  -Get a list of objects

\deprecated
  -

\bug
  -
*/
/*****************************************************************************/
class GameObjectManager
{
  friend class ArchetypeManager;
public:
  GameObjectManager();
  Object * CreateObject(std::string name);
  Object * CreateObject(const Object & other);
  Object * CreateArchetypeObject(std::string archetype);
  Object * CreateArchetypeObjectAtPosition(std::string archetype, glm::vec3 position);
  Object * FindObjectByName(std::string name);
  void DeleteObject(Object * object);
  void ClearObjects();
  spaceID Space();
  void SetSpaceID(spaceID space);
  ~GameObjectManager();

  std::vector<Object *> const & GetObjects();

  void Update();

  CollisionManager * GetCollisionManager();

private:
  // The game object container
  std::vector<Object *> _gameObjects;
  spaceID _space;
  CollisionManager _collisionManager;
};

#endif
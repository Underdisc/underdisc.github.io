/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file Graphics.h
\author Connor Deakin
\par E-mail: connor.deakin@digipen.edu
\par Project: Mecha
\date 07/10/2016
\brief
  This contains the interface for the Graphics namespace. This exists to avoid
  makeing basic global OpenGL calls in project code.
*/
/*****************************************************************************/

#ifndef GRAPHICS_H
#define GRAPHICS_H

/*****************************************************************************/
/*!
\brief
  This is the namespace for basic Graphics operations. OpenGL contains calls
  like glBlend, and glClearColor that are global in the sense that they could
  be really be called in many places. For this reason, they are located in this
  namespace.
*/
/*****************************************************************************/
namespace Graphics
{
  void BlendMode();
  void DepthMode();
  void SetClearColor(float red, float green, float blue, float alpha);
  void Clear();
}

#endif // !GRAPHICS_H
/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#pragma once
/*****************************************************************************/
/*!
\file CharacterHealth.h
\author Gabe Miller
\par E-mail: g.miller\@digipen.edu
\par Project: Boat Game
\date 12/24/2016 7:36:36 PM
\brief
*/
/*****************************************************************************/

#ifndef CharacterHealth_H
#define CharacterHealth_H

#include "Component.h"
#include "spaceID.h"

/*****************************************************************************/
/*!
\class CharacterHealth
\brief
  Component for character health, manages health and shields.

\par
	Operations include:
	-

\deprecated
	-

\bug
	- Exception thrown on picking up a health kit. Sound error.
*/
/*****************************************************************************/
class CharacterHealth : public Component
{
public:
  CharacterHealth(int health, int shield);
  ~CharacterHealth();
  void Update();
  bool IsGod();
  void God(bool is_god);
  void SetHUD(spaceID HUD);
  spaceID GetHUD();
  void Init();
  static bool _gameStart;

private:
  bool _god;
  float _health;
  float _max_health;
  float _shield;
  float _max_shield;
  float _invulnTimer;
  float _shieldCooldown;
  spaceID _HUD;
  Object * _healthSprites[24];
  Object * _shieldSprites[24];

  Object * _shieldObject;
};

Component * CreateCharacterHealthComponent(Json::Value value);

#endif
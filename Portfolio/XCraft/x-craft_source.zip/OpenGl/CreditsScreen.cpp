/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#include "CreditsScreen.h"

#include "Time.h"
#include "SpaceManager.h"
#include "Space.h"
#include "StateFactory.h"
#include "InputManager.h"
#include "GameObjectManager.h"
#include "Transform.h"
#include "Sprite.h"
#include "AudioEngine.h"
#include "RendererWater.h"

#define R (251.0f / 255.0f)
#define G (234.0f / 255.0f)
#define B (70.0f  / 255.0f)

#define STARTY 62.0f

namespace
{
  Transform * cursor_tran;
}


void CreditsScreen::Allocate()
{
  Object * credits;
  credits = _objectManager.CreateArchetypeObjectAtPosition("credits", glm::vec3(0, -STARTY, 0));
  _creditsTransform = credits->GetTransform();

  RendererWater::SetPeakColor(glm::vec3(R, G, B));
  RendererWater::SetTroughColor(-glm::vec3(0.5f, 0.5f, 0.5f));
  audEngine.PlayEvent("event:/Music/Level2BGM");

}

void CreditsScreen::Load()
{
}

bool CreditsScreen::Update()
{
  float speed = 3.0f;
  if (InputManager::Instance()->isKeyDown(SDL_SCANCODE_DOWN))
    speed = 15.0f;

  if (TheInputManager::Instance()->IsKeyPressed(SDL_SCANCODE_RETURN) ||
      TheInputManager::Instance()->getButtonState(0, SDL_CONTROLLER_BUTTON_A) ||
      TheInputManager::Instance()->getButtonState(0, SDL_CONTROLLER_BUTTON_B) ||
      InputManager::Instance()->isMousePressed(LEFT) ||
      _creditsTransform->GetTranslation().y > STARTY && !_done)
  {
    TransitionInfo transition_info(0.75f, 1.0f, MENU_MAIN);
    Global::SpaceManager::Add(transition_info);
    _done = true;
  }
  _creditsTransform->Translation() += glm::vec3(0.0f, Time::DT() * speed, 0.0f);
  return true;
}

void CreditsScreen::Free()
{
  audEngine.StopEvent("event:/Music/Level2BGM");
}

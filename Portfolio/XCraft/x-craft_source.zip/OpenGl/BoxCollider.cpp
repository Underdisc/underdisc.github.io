/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file BoxCollider.cpp
\author Gabe Miller
\par E-mail: g.miller@digipen.edu
\par Project: Boat Game
\date 11/11/2016 9:45:20 AM
\brief

\par
Functions Include:
-
*/
/*****************************************************************************/

#include "BoxCollider.h"
#include "Object.h"
#include "CircleCollider.h"
#include "Transform.h"

#include <iostream>

#include "GameObjectManager.h"
#include "Object.h"
#include "Physics.h"

BoxCollider::BoxCollider(float width, float height, std::string collisionGroup, Collider::ColliderType type) : _width(width), _height(height), Collider(type, collisionGroup)
{
  _boundingRadius = glm::sqrt((width / 2) * (width / 2) + (height / 2) * (height / 2));
}

bool BoxCollider::CheckCollision(Collider * otherCollider)
{
  if (otherCollider->Type() == Box)
    return StaticBoxToStaticBox(this, static_cast<BoxCollider *>(otherCollider));
  if (otherCollider->Type() == Circle)
    return StaticBoxtoStaticCircle(this, static_cast<CircleCollider *>(otherCollider));
  return false;
}



glm::vec2 * BoxCollider::GeneratePoints(int * size)
{
  *size = 8;
  glm::vec2 * points = new glm::vec2[8];
  float rot = Owner().GetTransform()->GetRotation();
  glm::vec3 pos = Owner().GetTransform()->GetTranslation();
  int i;
  // Points are circular
  for (i = 0; i < 3; i++)
  {
    float x = _width / 2;
    float y = (_height / 2) * (i - 1);
    points[i] = glm::vec2(x * glm::cos(rot) - y * glm::sin(rot),
      x * glm::sin(rot) + y * glm::cos(rot));
  }
  float y = _height / 2;
  points[i++] = glm::vec2(-y * glm::sin(rot), y * glm::cos(rot));
  for (; i < 7; i++)
  {
    float x = -_width / 2;
    float y = -(_height / 2) * (i - 5);
    points[i] = glm::vec2(x * glm::cos(rot) - y * glm::sin(rot),
      x * glm::sin(rot) + y * glm::cos(rot));
  }
  y = -_height / 2;
  points[i] = glm::vec2(-y * glm::sin(rot), y * glm::cos(rot));
  return points;
}


void BoxCollider::SetWidth(float width)
{
  _width = width;
  _boundingRadius = glm::sqrt((_width / 2) * (_width / 2) + (_height / 2) * (_height / 2));
}
void BoxCollider::SetHeight(float height)
{
  _height = height;
  _boundingRadius = glm::sqrt((_width / 2) * (_width / 2) + (_height / 2) * (_height / 2));
}

float BoxCollider::GetBoundingRadius()
{
  return _boundingRadius;
}

float BoxCollider::GetWidth()
{
  return _width;
}

float BoxCollider::GetHeight()
{
  return _height;
}
/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file Animation.cpp
\author Connor Deakin
\par E-mail: connor.deakin\@digipen.edu
\par Project: Graphics
\date 28/02/2017
\brief
Contains the implementation of the Animation class. Look in Animation.h for
more information.
*/
/*****************************************************************************/

#include "TexturePool.h"
#include "SpritePool.h"
#include "ShaderPool.h"
#include "Time.h"
#include "Object.h"

#include "Animation.h"

/*****************************************************************************/
/*!
\brief
Creates an Animation instance.

\param sprite
The TextureSheetSprite that will be animated.
\param total_time
The total time (in seconds) it takes to run through the entire animation.
*/
/*****************************************************************************/
Animation::Animation(TextureSheetSprite * sprite, float total_time) :
  Component("Animation"), _forward(true), _totalTime(total_time),
  _frameTime(total_time / sprite->Sheet().TotalFrames()),
  _timePassed(0.0f), _sprite(sprite)
{
}

/*!
\brief Sets the sprite of the Animation component's owner.
*/
void Animation::Init()
{
  _owner->SetSprite(reinterpret_cast<Sprite *>(_sprite));
}

/*!
\brief Updates the animation component.
*/
void Animation::Update()
{
  if (_forward)
    UpdateForward();
  else
    UpdateBackward();
}

/*!
\brief Swaps the direction the animation updates in.
*/
void Animation::SwitchDirection()
{
  _forward = !_forward;
}

/*****************************************************************************/
/*!
\brief
Goes to the frame in that Animation that will allow the entire Animation
to be displayed within the total time.

\par Important Notes
- This should only be called once per frame.
*/
/*****************************************************************************/
void Animation::UpdateForward()
{
  _timePassed += Time::DT();
  while (_timePassed >= _totalTime)
    _timePassed -= _totalTime;
  unsigned int next_frame = (unsigned int)(_timePassed / _frameTime);
  _sprite->SetFrameNumber(next_frame);
}

/*****************************************************************************/
/*!
\brief
Goes to a previous frame in that Animation that will allow the entire
Animation to be displayed in reverse within the total time.

\par Important Notes
- This should only be called once per frame.
*/
/*****************************************************************************/
void Animation::UpdateBackward()
{
  _timePassed -= Time::DT();
  while (_timePassed < 0)
    _timePassed += _totalTime;
  unsigned int next_frame = (unsigned int)(_timePassed / _frameTime);
  _sprite->SetFrameNumber(next_frame);
}

/*!
\brief Animation component creator.
\param json value.
*/
Component * CreateAnimationComponent(Json::Value value)
{
  // create texturesheetsprite
  TextureSheet * sheet = TexturePool::AddSheet(value["texture"].asString(), 
    value["frames"].asUInt(), value["rows"].asUInt(), 
    value["columns"].asUInt());
  TextureSheetSprite * a_sprite;
  a_sprite = SpritePool::AddTextureSheet(&ShaderPool::TextureSheet(), sheet);
  // create animation
  return new Animation(a_sprite, value["totalTime"].asFloat());
}
/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#include "HUDoverlay.h"
#include "SpaceManager.h"
#include "Space.h"
#include "StateFactory.h"
#include "GameObjectManager.h"
#include "Transform.h"
#include "Graphics.h"
#include "SpritePool.h"
#include "ShaderPool.h"
#include "TexturePool.h"

void HUDoverlay::Allocate()
{
  Object * hud = _objectManager.CreateArchetypeObject("hud");
  _objectManager.CreateArchetypeObjectAtPosition("shieldBar", glm::vec3(0.0f, 0.0f, 2.0f));
  _objectManager.CreateArchetypeObjectAtPosition("healthBar", glm::vec3(0.0f, 0.0f, 1.0f));
}

void HUDoverlay::Load()
{
  // Make that bitch transparent
  Graphics::SetClearColor(0.0f, 0.0f, 0.0f, 1.0f);

}

bool HUDoverlay::Update()
{
  return true;
}
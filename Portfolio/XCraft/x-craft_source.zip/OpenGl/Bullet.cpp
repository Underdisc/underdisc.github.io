/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file Bullet.cpp
\author Gabe Miller
\par E-mail: g.miller\@digipen.edu
\par Project: Boat Game
\date 4/7/2017 2:44:41 PM
\brief

\par
Functions Include:
-
*/
/*****************************************************************************/

#include "Bullet.h"
#include "Collider.h"
#include "EnemyHealth.h"
#include "Object.h"
#include "Projectile.h"
#include "GameObjectManager.h"

Bullet::Bullet() : Component("Bullet")
{

}


void Bullet::Update()
{

  Collider * collider = Owner().Find<Collider>();
  if (collider->Collided())
  {
    // send damage event
    for each(CollisionInfo info in collider->GetCollisionList())
    {
      CollisionInfo new_info = CollisionInfo(&Owner(), info.GetNormal(), info.GetContact(), info.GetPenetration());
      info.GetObject()->DispatchEvent(&EnemyDamaged(Owner().Find<Projectile>()->_damage, new_info));
      Object * impact = Owner().ObjectManager()->CreateArchetypeObjectAtPosition("impact", 
        Owner().GetTransform()->GetTranslation() - glm::vec3(info.GetNormal().x, info.GetNormal().y, 0) * (info.GetPenetration() + 0.25f));
      impact->GetTransform()->Rotation() = glm::atan(info.GetNormal().y, info.GetNormal().x);
    }
  }
}

Component * CreateBulletComponent(Json::Value value)
{
  return new Bullet();
}
/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file GraphicSprite.h
\author Connor Deakin
\par E-mail: connor.deakin\@digipen.edu
\par Project: Graphics
\date 07/03/2017
\brief
  Contains the interface for the GraphicSprite.
*/
/*****************************************************************************/

#ifndef GRAPHICSPRITE_H
#define GRAPHICSPRITE_H

#include <glm/vec3.hpp>

#include "Sprite.h"
#include "GraphicShader.h"

/*****************************************************************************/
/*!
\class GraphicSprite
\brief
  Used to draw a Graphic. This will draw the DefaultGraphic.
*/
/*****************************************************************************/
class GraphicSprite : public Sprite
{
  public:
    GraphicSprite(const GraphicShader * shader);
    void Draw(const glm::mat4 & transformation) const;
  private:
    //! The GraphicShader used to display the Graphic.
    const GraphicShader * _shader;

};

#endif // !GRAPHICSPRITE_H

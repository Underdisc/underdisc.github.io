/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#ifndef CONTROLS_SCREEN_H
#define CONTROLS_SCREEN_H

#include "State.h"

class ControlsScreen : public State
{
  public:
    virtual void Allocate();
    virtual void Load();
    virtual bool Update();
    virtual void Free();
};

#endif

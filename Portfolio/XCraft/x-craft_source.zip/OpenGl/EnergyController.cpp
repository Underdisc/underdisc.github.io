/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file EnergyController.cpp
\author Gabe Miller
\par E-mail: g.miller\@digipen.edu
\par Project: Boat Game
\date 3/16/2017 11:27:15 AM
\brief

\par
Functions Include:
-
*/
/*****************************************************************************/


#include "EnergyController.h"
#include "InputManager.h"
#include "Space.h"
#include "GameObjectManager.h"
#include "State.h"
#include "AudioEngine.h"
#include "Sprite.h"
#include "TextureSprite.h"
#include "TexturePool.h"

int EnergyController::_energyValues[4] = { 1, 1, 0, 0 };
int EnergyController::_currEnergy = EnergyController::ENGINE;
int EnergyController::_storedEnergy = 8;

EnergyController::EnergyController() : Component("EnergyController"), _shieldLevel(0.0f), _energyLevel(0.0f)
{
}

void EnergyController::Update()
{

  for (int i = 0; i < 4; i++)
  {
    SDL_Scancode key = (SDL_Scancode)((int)(SDL_SCANCODE_1)+i);
    if (InputManager::Instance()->IsKeyPressed(key))
    {
      _currEnergy = i;
      audEngine.PlayEvent("event:/UISFX/InventoryHover");
    }
  }

  for (int i = 6; i < 9; i++)
  {
    SDL_Scancode key = (SDL_Scancode)((int)(SDL_SCANCODE_1)+i);
    if (InputManager::Instance()->IsKeyPressed(key))
    {
      _currEnergy = i - 6;
      audEngine.PlayEvent("event:/UISFX/InventoryHover");
    }
  }
  if (InputManager::Instance()->IsKeyPressed(SDL_SCANCODE_0))
  {
    _currEnergy = 3;
    audEngine.PlayEvent("event:/UISFX/InventoryHover");
  }

  if (InputManager::Instance()->getDpadState(0, 2))
  {
    _currEnergy += 1;
    audEngine.PlayEvent("event:/UISFX/InventoryHover");
  }
  if (InputManager::Instance()->getDpadState(0, 8))
  {
    _currEnergy -= 1;
    audEngine.PlayEvent("event:/UISFX/InventoryHover");
  }


  if (_currEnergy  > 3)
  {
    _currEnergy = 0;
  }
  if (_energyLevel > 3)
  {
    _energyLevel = 0;
  }
  if (_shieldLevel > 3)
  {
    _shieldLevel = 0;
  }
  if (_currEnergy  < 0)
  {
    _currEnergy = 3;
  }
  if (_energyLevel < 0)
  {
    _energyLevel = 3;
  }
  if (_shieldLevel < 0)
  {
    _shieldLevel = 3;
  }
  //std::cout << _currEnergy << std::endl;

  if ((InputManager::Instance()->IsKeyPressed(SDL_SCANCODE_O) || InputManager::Instance()->getDpadState(0, 4)) && _energyValues[_currEnergy] > 0)
  {
    _energyValues[_currEnergy] -= 1;
    _storedEnergy += 1;
    _energyLevel -= 1;
    _shieldLevel -= 1;
 

    if (_currEnergy == 2)
    {
      audEngine.PlayEvent(audEngine.GetMusicEvent("ShieldDown"));
    }
    else
    {
      audEngine.PlayEvent(audEngine.GetMusicEvent("EnergyDown"));
    }

  }
  if ((InputManager::Instance()->IsKeyPressed(SDL_SCANCODE_P) || InputManager::Instance()->getDpadState(0, 1)) && _energyValues[_currEnergy] < 4 && _storedEnergy > 0)
  {
    _energyValues[_currEnergy] += 1;
    _storedEnergy -= 1;
    _energyLevel += 1;
    _shieldLevel += 1;

    if (_currEnergy == 2)
    {
      audEngine.PlayEvent(audEngine.GetMusicEvent("ShieldUp"));
    }
    else
    {
      audEngine.PlayEvent(audEngine.GetMusicEvent("EnergyUp"));
    }
  }

  for (int i = 0; i < 16; i++)
  {
    if (_energyValues[i / 4] > i % 4)
    {
      reinterpret_cast<TextureSprite *>(_pipSprites[i]->GetSprite())->SetTexture(TexturePool::Add("Resources/Visual/HUD/FullPip.png"));
    }
    else
    {
      reinterpret_cast<TextureSprite *>(_pipSprites[i]->GetSprite())->SetTexture(TexturePool::Add("Resources/Visual/HUD/Nothing.png"));
    }
  }

  int i;
  for (i = 0; i < _storedEnergy; i++)
  {
    reinterpret_cast<TextureSprite *>(_energySprites[i]->GetSprite())->SetTexture(TexturePool::Add("Resources/Visual/HUD/medpip.png"));
  }
  for (; i < 10; i++)
  {
    reinterpret_cast<TextureSprite *>(_energySprites[i]->GetSprite())->SetTexture(TexturePool::Add("Resources/Visual/HUD/Nothing.png"));
  }
  _highlight->GetTransform()->Translation() = glm::vec3(-22.825 + _currEnergy * 2.5, -11.45, 2);

  audEngine.SetEventParameter("event:/SFX/ShieldIncrease", "ShieldLevel", _shieldLevel);
  audEngine.SetEventParameter("event:/SFX/ShieldDecrease", "ShieldLevel", _shieldLevel);
  audEngine.SetEventParameter("event:/SFX/EnergyAdd", "EnergyLevel", _energyValues[_currEnergy]);
  audEngine.SetEventParameter("event:/SFX/EnergyMinus", "EnergyLevel", _energyValues[_currEnergy]);
}

int EnergyController::GetEnergyLevel(EnergyType energy)
{
  return _energyValues[energy];
}

void EnergyController::SetHUD(spaceID hud)
{
  _HUD = hud;
  for (int i = 0; i < 16; i++)
  {
    _pipSprites[i] = (**_HUD).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("energyPip", glm::vec3(-22.3 + (i / 4) * 2.5, -12 + (i % 4 * 0.3), 1));
  }
  for (int i = 0; i < 10; i++)
  {
    _energySprites[i] = (**_HUD).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("medPip", glm::vec3(-23.8 + i * 1.05, -13.85, -1));
  }
  _highlight = (**_HUD).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("energyHighlight", glm::vec3(-22.825, -11.45, 0));
}

Component * CreateEnergyControllerComponent(Json::Value value)
{
  return new EnergyController();
}
/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file GraphicPool.h
\author Connor Deakin
\par E-mail: connor.deakin\@digipen.edu
\par Project: Graphics
\date 13/03/2017
\brief
  Contains the interface for the GraphicPool.
*/
/*****************************************************************************/

#ifndef GRAPHICPOOL_H
#define GRAPHICPOOL_H

#include "TextureGraphic.h"
#include "DefaultGraphic.h"

/*****************************************************************************/
/*!
\class GraphicPool
\brief
  A pool of all of the Graphic types that exist.
*/
/*****************************************************************************/
class GraphicPool
{
  public:
    static void Initialize();
    static bool Initialized();
    static const DefaultGraphic & Default();
    static const TextureGraphic & Texture();
    static const GraphicScreen & Screen();
    static void Purge();
  private:
    GraphicPool() {}
    //! The DefaultGraphic.
    static DefaultGraphic * _defaultGraphic;
    //! The TextureGraphic.
    static TextureGraphic * _textureGraphic;
    //! The Graphic used for drawing frame buffers to the screen.
    static GraphicScreen * _screenGraphic;
    //! Identifies whether to pool has been initialized or not.
    static bool _initialized;
};

#endif // !GRAPHICPOOL_H


/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file GraphicPool.cpp
\author Connor Deakin
\par E-mail: connor.deakin\@digipen.edu
\par Project: Graphics
\date 13/03/2017
\brief
  Contains the implementation of the GraphicPool.
*/
/*****************************************************************************/

#include <iostream>

#include "Error.h"

#include "GraphicPool.h"

DefaultGraphic * GraphicPool::_defaultGraphic = nullptr;
TextureGraphic * GraphicPool::_textureGraphic = nullptr;
GraphicScreen *  GraphicPool::_screenGraphic  = nullptr;
bool GraphicPool::_initialized = false;

/*****************************************************************************/
/*!
\brief
  Creats all of the Graphic types that exist within the GraphicPool.
*/
/*****************************************************************************/
void GraphicPool::Initialize()
{
  if (_initialized) {
    Error error("GraphicPool.cpp", "Initialize");
    error.Add("GraphicPool has already been initialized.");
    error.Add("Only one initialization is needed for the GraphicPool");
    throw(error);
  }
  // create graphics
  try {
    _defaultGraphic = new DefaultGraphic();
    _textureGraphic = new TextureGraphic();
    _screenGraphic =  new GraphicScreen();
  }
  catch (const Error & error) {
    std::cout << error;
  }
  _initialized = true;
}

/*!
\brief A bool identifying if the pool has been initialized.
\return False if the pool has not been initialized.
*/
bool GraphicPool::Initialized()
{
  return _initialized;
}

/*!
\brief Gets the DefaultGraphic.
\return The DefaultGraphic.
*/
const DefaultGraphic & GraphicPool::Default()
{
  return *_defaultGraphic;
}

/*!
\brief Gets the TextureGraphic.
\return The TextureGraphic.
*/
const TextureGraphic & GraphicPool::Texture()
{
  return *_textureGraphic;
}

/*!
\brief Gets the Graphic used for frame buffer drawing.
\return The Graphic used for frame buffer drawing.
*/
const GraphicScreen & GraphicPool::Screen()
{
  return *_screenGraphic;
}

/*****************************************************************************/
/*!
\brief
  Deletes all of the Graphic types in the GraphicPool.
*/
/*****************************************************************************/
void GraphicPool::Purge()
{
  if (!_initialized) {
    Error error("GraphicPool.cpp", "Purge");
    error.Add("GraphicPool must be Initialized before it can be Purged.");
    throw(error);
  }
  // purging
  try {
    _defaultGraphic->Purge();
    _textureGraphic->Purge();
    _screenGraphic->Purge();
  }
  catch (const Error & error) {
    std::cout << error;
  }
  // freeing memory
  delete _defaultGraphic; _defaultGraphic = nullptr;
  delete _textureGraphic; _textureGraphic = nullptr;
  delete _screenGraphic; _screenGraphic = nullptr;

  _initialized = false;
}
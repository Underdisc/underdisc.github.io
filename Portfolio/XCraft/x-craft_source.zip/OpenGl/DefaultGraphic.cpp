/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file DefaultGraphic.cpp
\author Connor Deakin
\par E-mail: connor.deakin\@digipen.edu
\par Project: Graphics
\date 13/03/2017
\brief
  Contains the implementation for the DefaultGraphic.
*/
/*****************************************************************************/

#include "OpenGLError.h"

#include "DefaultGraphic.h"

/*****************************************************************************/
/*!
\brief
  Creates the OpenGL buffer for the DefaultGraphic. It's just a box centered at
  the origin.
*/
/*****************************************************************************/
DefaultGraphic::DefaultGraphic() :
Graphic()
{
  // setting up opengl buffer
  GLfloat vertices[12] = { -0.5f,  0.5f, 0.0f,
                            0.5f,  0.5f, 0.0f,
                           -0.5f, -0.5f, 0.0f,
                            0.5f, -0.5f, 0.0f };
  GLuint indices[6] = { 0, 1, 2, 1, 2, 3 };
  PrepBuffer(vertices, 12, indices, 6);
}

/*****************************************************************************/
/*!
\brief
  Draws the DefaultGraphic.
*/
/*****************************************************************************/
void DefaultGraphic::Draw() const
{
  // draw
  glBindVertexArray(_vertexArray);
  glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
  glBindVertexArray(0);
  // error check
  GLenum error_code = glGetError();
  if (error_code) {
    OpenGLError error("TextureGraphic.cpp", "Draw");
    error.Code(error_code);
    throw(error);
  }
}
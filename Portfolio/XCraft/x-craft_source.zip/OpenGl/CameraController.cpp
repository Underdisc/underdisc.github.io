/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file CameraController.cpp
\author yourname
\par E-mail: youremail
\par Project: Boat Game
\date 2/15/2017 2:24:56 PM
\brief

\par
Functions Include:
-
*/
/*****************************************************************************/

#include "CameraController.h"
#include "Transform.h"
#include <glm\glm.hpp>
#include "Object.h"
#include "GameObjectManager.h"
#include "Space.h"


CameraController::CameraController() :
  Component("CameraController"),
  _camera(nullptr),
  _shakeDuration(20),
  _shakeTimer(0),
  _shakeFrequency(2)
{
}

void CameraController::Init()
{
  _camera = (*Owner().ObjectManager()->Space())->GetCamera();
}

void CameraController::Update()
{
  if (_camera == nullptr)
    return;
  Transform * transform = Owner().GetTransform();
  glm::vec2 camera_offset;
  if (_shakeDuration > 0)
  {
    if (_shakeTimer <= 0)
    {
      _shakeDir = glm::normalize(glm::vec2(rand(), rand()));
      _shakeTimer = 1 / _shakeFrequency;
    }
    float multiplier = 1 - glm::abs(
      (1 / _shakeFrequency - _shakeTimer * 2) / (1 / _shakeFrequency));
    camera_offset = _shakeDir * multiplier;
  }
  _camera->SetPosition(transform->GetTranslation() + glm::vec3(camera_offset.x, camera_offset.y, 0));
}

Component * CreateCameraController(Json::Value value)
{
  return new CameraController();
}
/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file Error.h
\author Connor Deakin
\par E-mail: connor.deakin\@digipen.edu
\par Project: Graphics
\date 30/09/2016
\brief
  Contains the infterface for the Error class. This class is to be used for
  exception based error management.
*/
/*****************************************************************************/

#ifndef ERROR_H
#define ERROR_H

#include <string> // string
#include <vector> // vector

/*****************************************************************************/
/*!
\class Error
\brief
  The Error class is to be used for exception based error management. When
  creating an error class, you must supply the name of the file where the error
  occured and which function it occured in in order to print the error
  information when the Error is caught.
*/
/*****************************************************************************/
class Error
{
  public:
    Error(const char * file, const char * function);
    void Add(const char * info);
    friend std::ostream & operator<<(std::ostream & os, const Error & error);
  private:
    //! The name of the file in which an Error was thrown.
    std::string _file;
    //! The name of the function in which an Error was thrown.
    std::string _function;
    //! Contains a detailed description of what error occured.
    std::vector<std::string> _log;
};

#endif // !ERROR_H
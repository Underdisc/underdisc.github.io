/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file Graphic.cpp
\author Connor Deakin
\par E-mail: connor.deakin\@digipen.edu
\par Project: Graphics
\date 20/02/2017
\brief
  Contains the implementation of Graphic class. Look in the Graphic header file
  for more information.
*/
/*****************************************************************************/

#include "OpenGLError.h"

#include "Graphic.h"

///////////////////////////////////////////////////////////////////////////////
// BASE GRAPHIC                                                              //
///////////////////////////////////////////////////////////////////////////////

/*****************************************************************************/
/*!
\brief
  Does nothing. A Graphic type should never be created.
*/
/*****************************************************************************/
Graphic::Graphic()
{}

/*****************************************************************************/
/*!
\brief
  Virtual function for drawing a Graphic to the screen.
*/
/*****************************************************************************/
void Graphic::Draw() const
{}

/*****************************************************************************/
/*!
\brief
  Preps the Buffer for the Graphic with the given vertex and element arrays.

\param vertices
  A pointer to the array of vertices.
\param verticies_size
  The number of floats in the array of vertices.
\param indices
  A pointer to the array for the element buffer.
\param indices_size
  The number of unsigined ints in the indices array.
*/
/*****************************************************************************/
void Graphic::PrepBuffer(const GLfloat * vertices, unsigned verticies_size,
                         const GLuint * indices, unsigned indices_size)
{
  glGetError();
  glGenVertexArrays(1, &_vertexArray);
  glGenBuffers(1, &_vertexBuffer);
  glGenBuffers(1, &_elementBuffer);
  // vertex array
  glBindVertexArray(_vertexArray);
  // vertex buffer
  glBindBuffer(GL_ARRAY_BUFFER, _vertexBuffer);
  glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat) * verticies_size, 
               vertices, GL_STATIC_DRAW);
  // element buffer
  glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, _elementBuffer);
  glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(GLuint) * indices_size,
               indices, GL_STATIC_DRAW);
  // unbind
  glBindVertexArray(0);
  glBindBuffer(GL_ARRAY_BUFFER, 0);
  glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
  // error check
  GLenum error_code = glGetError();
  if (error_code) {
    OpenGLError error("Graphic.cpp", "PrepBuffer");
    error.Code(error_code);
    error.Add("Encountered while creating buffers.");
    throw(error);
  }
}

/*!
\brief Returns the ID for this Graphic's vertex array.
\return The ID for this Graphic's vertex array.
*/
GLint Graphic::VertexArray() const
{
  return _vertexArray;
}

/*!
\brief Returns the ID for this Graphic's vertex buffer.
\return The ID for this Graphic's vertex buffer.
*/
GLint Graphic::VertexBuffer() const
{
  return _vertexBuffer;
}

/*!
\brief Returns the ID for this Graphic's element buffer.
\return The ID for this Graphic's element buffer.
*/
GLint Graphic::ElementBuffer() const
{
  return _elementBuffer;
}

/*****************************************************************************/
/*!
\brief
  When the Graphic is no longer in use, it must be purged to delete the vertex
  buffers and vertex arrays.
*/
/*****************************************************************************/
void Graphic::Purge()
{
  // delete all buffers
  glDeleteBuffers(1, &_vertexBuffer);
  glDeleteBuffers(1, &_elementBuffer);
  glDeleteVertexArrays(1, &_vertexArray);
  // error check
  GLenum error_code = glGetError();
  if (error_code) {
    OpenGLError error("Graphic.cpp", "Purge");
    error.Code(error_code);
    error.Add("Problem encountered while deleting vertex buffers and array.");
    throw(error);
  }
}

///////////////////////////////////////////////////////////////////////////////
// GRAPHIC SCREEN                                                            //
///////////////////////////////////////////////////////////////////////////////

/*****************************************************************************/
/*!
\brief
  Creates and uploads the mesh used to cover the entire screen to the GPU.
*/
/*****************************************************************************/
GraphicScreen::GraphicScreen()
{
  // setting up opengl buffer
  GLfloat vertices[16] = { -1.0f,  1.0f,   0.0f, 1.0f,
                            1.0f,  1.0f,   1.0f, 1.0f,
                           -1.0f, -1.0f,   0.0f, 0.0f,
                            1.0f, -1.0f,   1.0f, 0.0f};
  GLuint indices[6] = { 0, 1, 2, 1, 2, 3 };
  PrepBuffer(vertices, 16, indices, 6);
}

/*****************************************************************************/
/*!
\brief
  Draws the screen graphic over the screen with the currently bound texture.
*/
/*****************************************************************************/
void GraphicScreen::Draw() const
{
  // draw
  glBindVertexArray(_vertexArray);
  glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
  glBindVertexArray(0);
  // error check
  GLenum error_code = glGetError();
  if (error_code) {
    OpenGLError error("Graphic.cpp", "GraphicScreen::Draw");
    error.Code(error_code);
    throw(error);
  }
}
/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#pragma once
/*****************************************************************************/
/*!
\file Flame.h
\author Gabe Miller
\par E-mail: g.miller\@digipen.edu
\par Project: Boat Game
\date 4/7/2017 4:19:24 PM
\brief
*/
/*****************************************************************************/

#ifndef Flame_H
#define Flame_H

#include "Component.h"
#include "Event.h"
#include "Emitter.h"


/*****************************************************************************/
/*!
\class Flame
\brief


\par
	Operations include:
	-

\deprecated
	-

\bug
	-
*/
/*****************************************************************************/
class Flame : public Component
{
public:
  Flame();
  ~Flame();
  void Init();
  void Update();
  void EarlyUpdate(Event * event_);
private:
  bool _exists; 
  Emitter * _emitter;
};

Component * CreateFlameComponent(Json::Value value);

#endif
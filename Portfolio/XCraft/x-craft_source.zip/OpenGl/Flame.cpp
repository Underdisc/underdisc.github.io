/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file Flame.cpp
\author Gabe Miller
\par E-mail: g.miller\@digipen.edu
\par Project: Boat Game
\date 4/7/2017 4:19:57 PM
\brief

\par
Functions Include:
-
*/
/*****************************************************************************/

#include "Flame.h"
#include "Object.h"
#include "Collider.h"
#include "EnemyHealth.h"
#include "Projectile.h"
#include "GameObjectManager.h"
#include "Space.h"
#include "Physics.h"
#include "TexturePool.h"
#include "ShaderPool.h"
#include "GraphicPool.h"

Flame::Flame() : Component("Flame")
{
}


void Flame::Init()
{
  Transform * _emitterTransform = new Transform();

  (**Owner().ObjectManager()->Space()).SubscribeCallback("FrameStart", std::bind(&Flame::EarlyUpdate, this, std::placeholders::_1), &Owner());
  _exists = true;
  Texture * water = TexturePool::Add("Resources/Visual/VFX/Particle/fire.png");                                           //      size
  _emitter = Emitter::createEmitter(BUBBLE, &(ShaderPool::Texture()), &(GraphicPool::Texture()), _emitterTransform, 500, 100.0f, 0.3f, 0.5f, 0.1f, 10, 5, 10, 1, 0, 359);
  _emitter->Init();
  _emitter->setTexture(water);
  _emitterTransform->ChangeParent(Owner().GetTransform());
  _emitterTransform->SetTranslation(glm::vec3(-1.1f, 0.47f, -10.0f));
  (**Owner().ObjectManager()->Space()).GetRenderer().Add(_emitter);
}

void Flame::EarlyUpdate(Event * event)
{
  Collider * collider = Owner().Find<Collider>();
  if (collider != nullptr && collider->Collided())
  {
    // send damage event
    for each(CollisionInfo info in collider->GetCollisionList())
    {
      CollisionInfo new_info = CollisionInfo(&Owner(), info.GetNormal(), info.GetContact(), info.GetPenetration());
      info.GetObject()->DispatchEvent(&EnemyDamaged(Owner().Find<Projectile>()->_damage, new_info));
    }
  }
}

void Flame::Update()
{

}

Flame::~Flame()
{

  if (_exists)
  {
    (**Owner().ObjectManager()->Space()).GetRenderer().Remove(_emitter);
    delete _emitter;
    (**Owner().ObjectManager()->Space()).UnsubscribeCallback("FrameStart", &Owner());
  }
}

Component * CreateFlameComponent(Json::Value value)
{
  return new Flame();
}
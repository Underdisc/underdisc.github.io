/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#include "Cheat.h"
#include "AudioEngine.h"
#include "SpaceManager.h"
#include "Space.h"
#include "StateFactory.h"
#include "GameObjectManager.h"
#include "Transform.h"
#include "Sprite.h"
#include "Graphics.h"
#include "InputManager.h"
#include "CollisionManager.h"
#include "BoxCollider.h"
#include "Physics.h"
#include "Camera.h"
#include "CharacterController.h"
#include "CameraController.h"
#include "CharacterHealth.h"
#include "TexturePool.h"

#define Pi 3.141592653589793238462643383279502884197169399f


namespace
{
  bool pressedUp = false;
  bool pause_live = false;

  Transform * PlayerTran;
  Transform * WaterTran;
  Transform * BuildingATran;
  Transform * BuildingBTran;
  Transform * DirtOneTran;
  Transform * instruction_tran;

  CameraController * controller;
  CharacterHealth * health;


  spaceID hud_overlay;
  spaceID pause_menu;


  bool p_down = false;
  bool p_pressed = false;
  bool p_live = false;
}


void LevelCheat::Allocate()
{
  hud_overlay = Global::SpaceManager::Add(HUD_OVERLAY, 30);

  // sound code

  audEngine.PlayEvent(audEngine.GetMusicEvent("LevelOne"));
  // end of sound code

  const Texture * PlayerTexture = TexturePool::Add("Resources/Visual/General/PLAYER BOAT.png");


  _objectManager.CreateArchetypeObjectAtPosition("water", glm::vec3(0, 0, -0.9));
  _objectManager.CreateArchetypeObjectAtPosition("Building B Object", glm::vec3(15, 1, 0));
  _objectManager.CreateArchetypeObjectAtPosition("Physics Object", glm::vec3(8, 8, 0));
  _objectManager.CreateArchetypeObjectAtPosition("line", glm::vec3(25, 1, 0));
  _objectManager.CreateArchetypeObjectAtPosition("move_here", glm::vec3(25, 1, 0));
  Object * player = _objectManager.CreateArchetypeObjectAtPosition("Player", glm::vec3(0, 0, 0));

  controller = player->Find<CameraController>();
  health = player->Find<CharacterHealth>();
  PlayerTran = player->GetTransform();

  // Initializing controller here so reticule draws over.
  controller->Init();
}

void LevelCheat::Load()
{


}

bool LevelCheat::Update()
{
  // SYSTEMS UPDATE FUNCTIONS
  ///////////////////////////////////

  if (PlayerTran->GetTranslation().x >= 25.0f)
  {
    Global::SpaceManager::RemoveAll();
    Global::SpaceManager::Add(LEVEL_ONE, 30);
  }

  if (TheInputManager::Instance()->IsKeyPressed(SDL_SCANCODE_ESCAPE))
  {
    Global::SpaceManager::PauseAll();
    Global::SpaceManager::Add(MENU_PAUSE, 30);
  }

  

  if (TheInputManager::Instance()->isKeyDown(SDL_SCANCODE_I))
  {
    Global::SpaceManager::RemoveAll();
    Global::SpaceManager::Add(WIN_SCREEN, 30);
  }

  if (TheInputManager::Instance()->isKeyDown(SDL_SCANCODE_L))
  {
    Global::SpaceManager::RemoveAll();
    Global::SpaceManager::Add(LOSE_SCREEN, 30);
  }
  


  // END OF INPUT CODE FOR LEVEL
  ///////////////////////////////////



  return true;
}

void LevelCheat::Free()
{
  
}



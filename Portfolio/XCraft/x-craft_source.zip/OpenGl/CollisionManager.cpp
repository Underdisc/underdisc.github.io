/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#include "CollisionManager.h"
#include "CollisionTable.h"
#include "Physics.h"
#include "Transform.h"
#include "Space.h"
#include "State.h"
#include "TileMap.h"

CollisionManager::CollisionManager(GameObjectManager * objectManager) :
  _objectManager(objectManager)
{}


void CollisionManager::Update()
{
  for (size_t i = 0; i < _colliders.size(); i++)
  {
    // Reset the collided tracker
    _colliders[i]->_collided = false;
    // Reset the collision list
    _colliders[i]->_collisionData.clear();
  }
  for (size_t i = 0; i < _colliders.size(); i++)
  {
    if (!_colliders[i]->Owner()._active)
      continue;
    if (_tileMaps)
    {
      for each(TileMap * tileMap in *_tileMaps)
      {
        if(tileMap->GetTileData()->collidable)
          _colliders[i]->TileCollision(tileMap);
      }
    }
    else
      _tileMaps = &(*_objectManager->Space())->GetCurrentState()->GetTileMaps();
    for (size_t j = i + 1; j < _colliders.size(); j++)
    {
      // Check that one of the objects has moved
      if (!_colliders[i]->Owner().GetTransform()->Moved() && !_colliders[j]->Owner().GetTransform()->Moved())
        continue;
      if (!_colliders[j]->Owner()._active)
        continue;
      ResolutionType res = (*collisionTables.begin()).second->GetResolutionType(_colliders[i]->_collisionGroup, _colliders[j]->_collisionGroup);
      if (res == Ignore)
        continue;
      Physics::MotionType motype = _colliders[i]->Owner().Find<Physics>()->GetMotionType();
      Physics::MotionType otherMotype = _colliders[j]->Owner().Find<Physics>()->GetMotionType();
      if (motype == Physics::Static)
      {
        if (otherMotype == Physics::Static)
          continue;
        bool collided = _colliders[j]->CheckCollision(_colliders[i]);
        if (collided)
        {
          _colliders[j]->_collided = true;
          _colliders[i]->_collided = true;
          if (res == Resolve)
          {
            Collider::ResolveCollision(&_colliders[j]->Owner(), &_colliders[i]->Owner());
          }
        }
      }
      bool collided = _colliders[i]->CheckCollision(_colliders[j]);
      if (collided)
      {
        _colliders[i]->_collided = true;
        _colliders[j]->_collided = true;
        if (res == Resolve)
        {
          Collider::ResolveCollision(&_colliders[i]->Owner(), &_colliders[j]->Owner());
        }
      }
    }

  }
}

void CollisionManager::AddCollider(Collider * newCollider)
{
   _colliders.push_back(newCollider);
}

void CollisionManager::RemoveCollider(Collider * collider)
{
  std::vector<Collider *>::iterator it;
  for (it = _colliders.begin(); it < _colliders.end(); it++)
  {
    if (*it == collider)
    {
      _colliders.erase(it);
      return;
    }
  }
}

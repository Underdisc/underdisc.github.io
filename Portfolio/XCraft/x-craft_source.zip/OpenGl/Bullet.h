/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#pragma once
/*****************************************************************************/
/*!
\file Bullet.h
\author Gabe Miller
\par E-mail: g.miller\@digipen.edu
\par Project: Boat Game
\date 4/7/2017 2:33:35 PM
\brief
*/
/*****************************************************************************/

#ifndef Bullet_H
#define Bullet_H

#include "Component.h"

/*****************************************************************************/
/*!
\class Bullet
\brief


\par
	Operations include:
	-

\deprecated
	-

\bug
	-
*/
/*****************************************************************************/
class Bullet : public Component
{
public:
  Bullet();
  void Update();

private:
};

Component * CreateBulletComponent(Json::Value value);

#endif
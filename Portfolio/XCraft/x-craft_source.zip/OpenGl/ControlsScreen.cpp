/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#include "ControlsScreen.h"

#include "SpaceManager.h"
#include "GameObjectManager.h"
#include "InputManager.h"
#include "AudioEngine.h"

#define BUTTONHALFWIDTH 1.45833334f

#define LEFTBOUND      -25.8f
#define RIGHTBOUND     -11.5f
#define TOPBOUND       -13.0f + BUTTONHALFWIDTH
#define BOTTOMBOUND    -13.0F - BUTTONHALFWIDTH

void ControlsScreen::Allocate()
{
  _objectManager.CreateArchetypeObjectAtPosition("menuArrow", glm::vec3(-10.3f, -13.0f, 1.0f));
  _objectManager.CreateArchetypeObjectAtPosition("controls", glm::vec3(0, 0, 0));
  _objectManager.CreateArchetypeObject("mouseCursor");
}

void ControlsScreen::Load()
{
}

bool ControlsScreen::Update()
{
  glm::vec2 mouse_loc(*TheInputManager::Instance()->getMousePosition());
  (**_space).ScreenToWorld(mouse_loc);

  if (TheInputManager::Instance()->IsKeyPressed(SDL_SCANCODE_RETURN) ||
      TheInputManager::Instance()->getButtonState(0, SDL_CONTROLLER_BUTTON_A) ||
    (mouse_loc.x > LEFTBOUND && mouse_loc.x < RIGHTBOUND &&
      mouse_loc.y < TOPBOUND && mouse_loc.y > BOTTOMBOUND &&
      TheInputManager::Instance()->isMousePressed(LEFT)))
  {
    // reactivating main menu render
    spaceID menu_space = Global::SpaceManager::SpaceUnderneath(_space);
    (**menu_space).GetRenderer().Activate();
    // going back to main menu
    audEngine.PlayEvent(audEngine.GetMusicEvent("MenuStart"));
    Global::SpaceManager::ResumeBeneath(_space);
    Global::SpaceManager::Remove(_space);
  }
  return true;
}

void ControlsScreen::Free()
{
}
/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#include "CollisionTable.h"
#include <json\json.h>
#include <iostream>
#include <dirent\dirent.h>
#include <fstream>

std::map<std::string, CollisionTable *> collisionTables;

CollisionTable::CollisionTable(Json::Value value)
{

  int collisionTypes = value.size();
  for (int i = 0; i < collisionTypes; i++)
  {
    _ids[value.getMemberNames().at(i)] = i;
    std::vector<ResolutionType> sub_table;
    for (int j = 0; j < collisionTypes; j++)
    {
      sub_table.push_back(Resolve);
    }
    _collisionTable.push_back(sub_table);
  }


  for each(std::string collisionType in value.getMemberNames())
  {
    for each(std::string name in value[collisionType].getMemberNames())
    {
      if (value[collisionType][name].asString() == "Ignore")
      {
        _collisionTable[_ids[collisionType]][_ids[name]] = Ignore;
        _collisionTable[_ids[name]][_ids[collisionType]] = Ignore;
      }
      if (value[collisionType][name].asString() == "Detect")
      {
        _collisionTable[_ids[collisionType]][_ids[name]] = Detect;
        _collisionTable[_ids[name]][_ids[collisionType]] = Detect;
      }
    }
  }
}

ResolutionType CollisionTable::GetResolutionType(const std::string & first, const std::string & second)
{
  return _collisionTable[_ids[first]][_ids[second]];
}

void CollisionTable::InitCollisionTables()
{
  std::string directory = "Resources/tables/";
  // Opens the directory
  DIR * tableDir = opendir(directory.c_str());
  // Contains info about the files in the directory.
  dirent * ent;
  while ((ent = readdir(tableDir)) != NULL)
  {
    // Check if the file has the .archetype extension.
    if (std::string(ent->d_name).find(".table") != std::string::npos)
    {
      Json::Reader reader;
      Json::Value value;
      std::ifstream inputFile;
      inputFile.open((directory + ent->d_name));
      bool success = reader.parse(inputFile, value);
      if (!success)
      {
        std::cout << reader.getFormattedErrorMessages() << std::endl;
        return;
      }

      collisionTables[*value.getMemberNames().begin()] = new CollisionTable(*value.begin());
    }
  }
}
/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file AudioEngine.cpp
\author Zach Dolph
\par E-mail: z.dolph@digipen.edu
\par Project: MechaEngine
\date 09/24/2016
\brief


\par
	Functions Include:
	-
*/
/*****************************************************************************/


#include "AudioEngine.h"
#include <fstream>
#include <string>
#include <iostream>
#include <json\json.h>



AudioEngine audEngine;

// This constructor creates the FMOD studio
// and Low Level systems
// Also sets the variables of course
Implementation::Implementation() 
{
	mpStudioSystem = NULL;
	AudioEngine::ErrorCheck(FMOD::Studio::System::create(&mpStudioSystem));

  #if RELEASE
    AudioEngine::ErrorCheck(mpStudioSystem->initialize(32, FMOD_STUDIO_INIT_NORMAL, FMOD_INIT_NORMAL, NULL));
  #endif // RELEASE
  #if _DEBUG
    AudioEngine::ErrorCheck(mpStudioSystem->initialize(32, FMOD_STUDIO_INIT_LIVEUPDATE, FMOD_INIT_PROFILE_ENABLE, NULL));
  #endif // _DEBUG
	

	mpSystem = NULL;
	AudioEngine::ErrorCheck(mpStudioSystem->getLowLevelSystem(&mpSystem));
}


// Deconstructor for the FMOD studio
// and low level systems
Implementation::~Implementation()
{
	AudioEngine::ErrorCheck(mpStudioSystem->unloadAll());
	AudioEngine::ErrorCheck(mpStudioSystem->release());
}

// Update for the systems
void Implementation::Update()
{
	std::vector<ChannelMap::iterator> pStoppedChannels;

	for (auto it = mChannels.begin(), itEnd = mChannels.end(); it != itEnd; ++it)
	{
		bool bIsPlaying = false;

		it->second->isPlaying(&bIsPlaying);

		if (!bIsPlaying)
		{
			pStoppedChannels.push_back(it);
		}
	}
	for (auto& it : pStoppedChannels)
	{
		mChannels.erase(it);
	}

	AudioEngine::ErrorCheck(mpStudioSystem->update());

}




Implementation* sgpImplementation = nullptr;

////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////


void AudioEngine::Init()
{
	// first create the implementation
	sgpImplementation = new Implementation;
  
}

void AudioEngine::InitBanks()
{
  std::ifstream configFile;
  configFile.open("Resources/audio/AudioConfig.txt");
  std::string filename;
  while (!configFile.eof())
  {
    std::getline(configFile, filename);
    if (configFile.eof())
      break;
    std::cout << ("Loading Bank: Resources/audio/" + filename) << std::endl;
    LoadBank("Resources/audio/" + filename, FMOD_STUDIO_LOAD_BANK_NORMAL);
  }
  configFile.close();
  configFile.open("Resources/audio/LevelMusic.txt");
  std::string eventname;
  Json::Reader reader;
  Json::Value value;
  bool parsingSuccessful = reader.parse(configFile, value);
  if (!parsingSuccessful)
  {
    std::cout << reader.getFormattedErrorMessages() << std::endl;
    return;
  }
  for each (std::string item_name in value.getMemberNames())
  {
    std::cout << "Assigning event: " << value[item_name].asString() << " to level name: " << item_name << std::endl;
    _musicMap[item_name] = value[item_name].asString();
  }
}

void AudioEngine::Update()
{
	sgpImplementation->Update();
}


void AudioEngine::LoadBank(const std::string& strBankName, FMOD_STUDIO_LOAD_BANK_FLAGS flags)
{
	auto foundIt = sgpImplementation->mBanks.find(strBankName);

	if(foundIt != sgpImplementation->mBanks.end())
	{
		return;
	}

	FMOD::Studio::Bank* pBank;

	AudioEngine::ErrorCheck(sgpImplementation->mpStudioSystem->loadBankFile(strBankName.c_str(), flags, &pBank));

	if (pBank)
	{
		sgpImplementation->mBanks[strBankName] = pBank;
	}
}


void AudioEngine::LoadSound(const std::string& strSoundName, bool b3d, bool bLooping, bool bStream)
{
	auto foundIt = sgpImplementation->mSounds.find(strSoundName);

	if (foundIt != sgpImplementation->mSounds.end())
		return;


	FMOD_MODE eMode = FMOD_DEFAULT;


	eMode |= b3d ? FMOD_3D : FMOD_2D;
	eMode |= bLooping ? FMOD_LOOP_NORMAL : FMOD_LOOP_OFF;
	eMode |= bStream ? FMOD_CREATESTREAM : FMOD_CREATECOMPRESSEDSAMPLE;

	FMOD::Sound* pSound = nullptr;

	AudioEngine::ErrorCheck(sgpImplementation->mpSystem->createSound(strSoundName.c_str(), eMode, nullptr, &pSound));

	if (pSound)
	{
		sgpImplementation->mSounds[strSoundName] = pSound;
	}
}

void AudioEngine::UnloadSound(const std::string& strSoundName)
{
	auto foundIt = sgpImplementation->mSounds.find(strSoundName);

	if (foundIt == sgpImplementation->mSounds.end())
		return;

	AudioEngine::ErrorCheck(foundIt->second->release());
	sgpImplementation->mSounds.erase(foundIt);
}

int AudioEngine::PlaySound(const std::string& strSoundName, const glm::vec3 vPos, float fVolumedB)
{
	int channelId = sgpImplementation->mnNextChannelID++;
	auto foundIt = sgpImplementation->mSounds.find(strSoundName);

	if (foundIt == sgpImplementation->mSounds.end())
	{
		LoadSound(strSoundName);

		foundIt = sgpImplementation->mSounds.find(strSoundName);

		if (foundIt == sgpImplementation->mSounds.end())
		{
			return channelId;
		}
	}

	FMOD::Channel* pChannel = nullptr;
	AudioEngine::ErrorCheck(sgpImplementation->mpSystem->playSound(foundIt->second, nullptr, true, &pChannel));

	if (pChannel)
	{
		FMOD_MODE currMode;
		foundIt->second->getMode(&currMode);
		if (currMode & FMOD_3D)
		{
			FMOD_VECTOR position = VectorToFmod(vPos);
			AudioEngine::ErrorCheck(pChannel->set3DAttributes(&position, nullptr));
		}

		AudioEngine::ErrorCheck(pChannel->setVolume(dbToVolume(fVolumedB)));
		AudioEngine::ErrorCheck(pChannel->setPaused(false));
		sgpImplementation->mChannels[channelId] = pChannel;
	}

	return channelId;
}


FMOD::Studio::EventDescription* pEventDescription;



void AudioEngine::LoadEvent(const std::string& strEventName)
{
	auto foundIt = sgpImplementation->mEvents.find(strEventName);

	if (foundIt != sgpImplementation->mEvents.end())
	{
		return;
	}

	pEventDescription = NULL;

	AudioEngine::ErrorCheck(sgpImplementation->mpStudioSystem->getEvent(strEventName.c_str(), &pEventDescription));

	if (pEventDescription)
	{
		FMOD::Studio::EventInstance* pEventInstance = NULL;

		AudioEngine::ErrorCheck(pEventDescription->createInstance(&pEventInstance));

		if (pEventInstance)
		{
			sgpImplementation->mEvents[strEventName] = pEventInstance;
		}
	}

}

void AudioEngine::PlayEvent(const std::string& strEventName)
{
	auto foundIt = sgpImplementation->mEvents.find(strEventName);

	if (foundIt == sgpImplementation->mEvents.end()) 
	{
		LoadEvent(strEventName);

		foundIt = sgpImplementation->mEvents.find(strEventName);

		if (foundIt == sgpImplementation->mEvents.end())
		{
			return;
		}
			
	}

	if (!IsEventPlaying(strEventName))
	{
		foundIt->second->start();
	}
	else
	{
		FMOD::Studio::EventInstance* pEventInstance = NULL;

		AudioEngine::ErrorCheck(pEventDescription->createInstance(&pEventInstance));

		pEventInstance->start();
	}
	
}

void AudioEngine::StopEvent(const std::string& strEventName, bool bImmediate)
{
	auto foundIt = sgpImplementation->mEvents.find(strEventName);

	if (foundIt == sgpImplementation->mEvents.end())
	{
		return;
	}

	FMOD_STUDIO_STOP_MODE eMode;

	eMode = bImmediate ? FMOD_STUDIO_STOP_IMMEDIATE : FMOD_STUDIO_STOP_ALLOWFADEOUT;

	AudioEngine::ErrorCheck(foundIt->second->stop(eMode));
}

void AudioEngine::GetEventParameter(const std::string& strEventName, const std::string& strEventParameter, float* parameter)
{
	auto foundIt = sgpImplementation->mEvents.find(strEventName);

	if (foundIt == sgpImplementation->mEvents.end())
	{
		return;
	}

	FMOD::Studio::ParameterInstance* pParameter = NULL;

	AudioEngine::ErrorCheck(foundIt->second->getParameter(strEventParameter.c_str(), &pParameter));

	AudioEngine::ErrorCheck(pParameter->getValue(parameter));
}

void AudioEngine::SetEventParameter(const std::string& strEventName, const std::string& strEventParameter, float fValue)
{
	auto foundIt = sgpImplementation->mEvents.find(strEventName);
	if (foundIt == sgpImplementation->mEvents.end())
	{
		return;
	}

	FMOD::Studio::ParameterInstance* pParameter = NULL;

	AudioEngine::ErrorCheck(foundIt->second->getParameter(strEventParameter.c_str(), &pParameter));

	AudioEngine::ErrorCheck(pParameter->setValue(fValue));
}

void AudioEngine::SetChannel3dPosition(int nChannelID, const glm::vec3& vPosition)
{
	auto foundIt = sgpImplementation->mChannels.find(nChannelID);

	if (foundIt == sgpImplementation->mChannels.end())
		return;

	FMOD_VECTOR position = VectorToFmod(vPosition);

	AudioEngine::ErrorCheck(foundIt->second->set3DAttributes(&position, NULL));
}

void AudioEngine::SetChannelVolume(int nChannelID, float fVolumedB)
{
	auto foundIt = sgpImplementation->mChannels.find(nChannelID);
	if (foundIt == sgpImplementation->mChannels.end())
		return;

	AudioEngine::ErrorCheck(foundIt->second->setVolume(dbToVolume(fVolumedB)));
}


bool AudioEngine::IsEventPlaying(const std::string& strEventName) const
{
	auto foundIt = sgpImplementation->mEvents.find(strEventName);

	if (foundIt == sgpImplementation->mEvents.end())
	{
		return false;
	}

	FMOD_STUDIO_PLAYBACK_STATE* state = NULL;

	if (foundIt->second->getPlaybackState(state) == FMOD_STUDIO_PLAYBACK_PLAYING) 
	{
		return true;
	}

	return false;
}

std::string AudioEngine::GetMusicEvent(std::string levelName)
{
  return _musicMap[levelName];
}

float AudioEngine::dbToVolume(float db)
{
	return powf(10.0f, 0.05f * db);
}

float AudioEngine::VolumeTodb(float volume)
{
	return 20.0f * log10f(volume);
}

FMOD_VECTOR AudioEngine::VectorToFmod(const glm::vec3& vPosition)
{
	FMOD_VECTOR fVec;

	fVec.x = vPosition.x;
	fVec.y = vPosition.y;
	fVec.z = vPosition.z;

	return fVec;
}

void AudioEngine::ShutDown()
{
	delete sgpImplementation;
}

int AudioEngine::ErrorCheck(FMOD_RESULT result)
{
	if (result != FMOD_OK) 
	{
		std::cout << "FMOD ERROR " << result << std::endl;
		return 1;
	}

	return 0;
}

void AudioEngine::PauseAllChannels()
{
  FMOD::ChannelGroup* masterGroup = NULL;

  sgpImplementation->mpSystem->getMasterChannelGroup(&masterGroup);

  if (masterGroup)
  {
    bool paused;
    masterGroup->getPaused(&paused); //store our pause state in paused.
    masterGroup->setPaused(!paused); //flip the pause bool.
  }
}


void AudioEngine::PlayAllChannels()
{
  //ONLY CALL THIS IF THEY ARE PAUSED ALREADY

  FMOD::ChannelGroup* masterGroup = NULL;

  sgpImplementation->mpSystem->getMasterChannelGroup(&masterGroup);

  if (masterGroup)
  {
    bool paused;
    masterGroup->getPaused(&paused); //store our pause state in paused.
    masterGroup->setPaused(!paused); //flip the pause bool.
  }
}

void AudioEngine::SetVolumeAllChannels(float volume)
{
  // Pass in a float. The default volume is 1.0f
  // 0.5f would be half volume, 2.0f would be double the volume

  FMOD::ChannelGroup* masterGroup = NULL;

  sgpImplementation->mpSystem->getMasterChannelGroup(&masterGroup);

  if (masterGroup)
  {
    masterGroup->setVolume(volume);
  }
}

float AudioEngine::GetVolumeAllChannels()
{
  FMOD::ChannelGroup* masterGroup = NULL;

  sgpImplementation->mpSystem->getMasterChannelGroup(&masterGroup);

  if (masterGroup)
  {
    float volume;
    masterGroup->getVolume(&volume);
    return volume;
  }
  else
    return 1.0f;
}

void AudioEngine::StopAllChannels()
{
  FMOD::ChannelGroup* masterGroup = NULL;

  sgpImplementation->mpSystem->getMasterChannelGroup(&masterGroup);

  if (masterGroup)
  {
    masterGroup->stop();
  }
}


void AudioEngine::Set3dListenerAndOrientation(const glm::vec3& vPos, float fVolumedB)
{

}

void AudioEngine::StopChannel(int nChannelID)
{

}

void AudioEngine::SetBusGroupVolume(const char* busName, float volume)
{

  FMOD::Studio::Bus* pBus = nullptr;

  sgpImplementation->mpStudioSystem->getBus(busName, &pBus);

  pBus->setVolume(volume);

}

float AudioEngine::GetBusGroupVolume(const char* busName)
{
  FMOD::Studio::Bus* pBus = nullptr;

  float volume = 0.0f;

  sgpImplementation->mpStudioSystem->getBus(busName, &pBus);

  pBus->getVolume(&volume);

  return volume;
}




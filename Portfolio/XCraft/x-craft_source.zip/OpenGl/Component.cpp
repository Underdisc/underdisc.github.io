/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file Component.cpp
\author Connor Deakin
\par E-mail: connortdeakin\@gmail.com
\par Project: Mecha
\date 11/09/2016
\brief
  Contains the implementation for the base Component class. There is almost
  no implementation in this file except for general Component functions.

\par
    Functions Include:
    - Component constructor
    - type
    - update
    - owner
    - set_owner
*/
/*****************************************************************************/

#include "Component.h" // Component
#include "Physics.h" // Creator Function
#include "Collider.h" // Creator Function
#include "CharacterController.h"
#include "Sprite.h"
#include "Transform.h"
#include "Enemy.h"
#include "DestroyOnContact.h"
#include "BoatShoot.h"
#include "TimedDestroy.h"
#include "LevelSwitcher.h"
#include "CharacterHealth.h"
#include "Projectile.h"
#include "CameraController.h"
#include "SoundEmitter.h"
#include "AdaptiveMusic.h"
#include "Camera.h"
#include "MenuSystem.h"
#include "GunnerInventory.h"
#include "EnergyController.h"
#include "BreakableWall.h"
#include "EnemyHealth.h"
#include "Mine.h"
#include "Animation.h"
#include "Bullet.h"
#include "Flame.h"
#include "Line.h"
#include "Turret.h"
#include "MenuCursor.h"
#include "Dialogue.h"

#include <string> // std::string

/*****************************************************************************/
/*!
\brief
  The constructor for the base Component class. The type will get set here, but
  the _owner pointer will be set to a nullptr. The _owner will be set when
  the Component is added to an Object.

\param type
  The type of the Component in string form.

*/
/*****************************************************************************/
Component::Component(std::string type) : _type(type), _owner(nullptr) {}


/*****************************************************************************/
/*!
\brief
  This is used to update a Component. This should be overloaded by most if not
  all custom Components.
*/
/*****************************************************************************/
void Component::Update() {}

/*****************************************************************************/
/*!
\brief
  Use this to get the type string of a Component. The string data is kept as
  private in the class to prevent overwriting of that data.

\return The type of the Component in string form.
*/
/*****************************************************************************/
std::string Component::Type()
{
  return _type;
}

/*****************************************************************************/
/*!
\brief
  Use this to get a pointer to the Object that owns the Component.

\return A pointer to the Object that this Component is a part of. If the
  Component does not currently have a owner, a nullptr will be returned.
*/
/*****************************************************************************/
Object & Component::Owner()
{
  return (*_owner);
}

/*****************************************************************************/
/*!
\brief
  This function will only be used by the Object class to set the owner of
  of Component.

\param new_owner
  A pointer to the Object that this Component is meant to be a part of.
*/
/*****************************************************************************/
void Component::SetOwner(Object * new_owner)
{
  _owner = new_owner;
}

/*Gabe's Code*/
// Initialize the creator array with the creator functions
std::map<std::string, Component::componentFn*> Component::_componentCreators = std::map<std::string, componentFn*>(
{ {"Physics", CreatePhysicsComponent} ,
  {"Collider", CreateColliderComponent} ,
  {"CharacterController", CreateCharacterControllerComponent} ,
  {"Enemy", CreateEnemyComponent} ,
  {"DestroyOnContact", CreateDestroyOnContact} ,
  {"BoatShoot", CreateBoatShootComponent} ,
  {"TimedDestroy", CreateTimedDestroyComponent} ,
  {"LevelSwitcher", CreateLevelSwitcherComponent} ,
  {"CharacterHealth", CreateCharacterHealthComponent} ,
  {"CameraController", CreateCameraController } ,
  {"SoundEmitter", CreateSoundEmitterComponent } ,
  {"AdaptiveMusic",  CreateAdaptiveMusicComponent} ,
  {"MenuSystem", CreateMenuSystemComponent } ,
  {"EnergyController", CreateEnergyControllerComponent} ,
  {"BreakableWall", CreateBreakableWallComp } ,
  {"EnemyHealth", CreateEnemyHealthComponent } ,
  {"GunnerInventory", CreateGunnerInventoryComponent} ,
  {"Mine", CreateMineComponent },
  {"Animation", CreateAnimationComponent},
  {"Bullet", CreateBulletComponent},
  {"Flame", CreateFlameComponent},
  {"Line", CreateLineComponent},
  {"Turret", CreateTurretComponent},
  {"MenuCursor", CreateMenuCursorComponent},
  {"Dialogue", CreateDialogueComponent}
  //{"Projectile", CreateProjectileComponent}
});

std::map<std::string, std::vector<std::string>> Component::_dependencies =
{
  { "Sprite",{ "Transform" } },
  { "Physics",{ "Transform" } },
  { "Collider",{ "Physics" } },
  { "CharacterController", { "Collider" } },
  { "LevelSwitcher", { "Collider" } }
};
/*****************************************************************************/
/*!
\brief
  This function gets the component creator function for the specified component type.

\param type
  This is a string which has the name of the component type you want to create.

\return
  This returns a function which takes no arguments, and returns a component.
  The component it returns is a new component which is created after the function runs.
*/
/*****************************************************************************/

Component::componentFn *Component::GetComponentCreator(std::string type)
{
    return Component::_componentCreators.at(type);
}

Component::Component(const Component & other, Object * owner)
{
  _type = other._type;
  SetOwner(owner);
}


void Component::Copy(const Component & other) {}

std::vector<std::string> Component::GetDependencies(std::string type)
{
  auto dependencies = Component::_dependencies.find(type);
  if (dependencies != _dependencies.end())
    return (*dependencies).second;
  else
    return std::vector<std::string>();
}
/*End Gabe's Code*/
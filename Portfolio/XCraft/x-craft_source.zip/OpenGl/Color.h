/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#pragma once
#include <glm\glm.hpp>

glm::vec3 HSVToRGB(glm::vec3 color);
glm::vec3 RGBToHSV(glm::vec3 color);
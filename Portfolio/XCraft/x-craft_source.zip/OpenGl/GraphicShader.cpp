/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file GraphicShader.cpp
\author Connor Deakin
\par E-mail: connor.deakin\@digipen.edu
\par Project: Graphics
\date 07/03/2017
\brief
  Contains the implementation of the GraphicShader.
*/
/*****************************************************************************/

#include "OpenGLError.h"

#include "GraphicShader.h"

/*****************************************************************************/
/*!
\brief
  Creates a graphic shader, finds the attributes and uniforms within the
  graphic shader, and enables the shader's position attribute with the provided
  graphic.

\param vert_file
  The Shader's vertex file.
\param frag_file
  The Shader's fragment file.
\param graphic
  The graphic that will be rendered while this shader is in use.
*/
/*****************************************************************************/
GraphicShader::GraphicShader(const std::string & vert_file, 
                             const std::string & frag_file, 
                             const Graphic & graphic) :
  Shader(vert_file, frag_file)
{
  // getting locations
  Use();
  _position_A = glGetAttribLocation(ID(), "position");
  _transformation_U = glGetUniformLocation(ID(), "transformation");
  _color_U = glGetUniformLocation(ID(), "in_color");
  // check locations
  CHECKATTRIBUTE(_position_A, "position",
    _vertexFile.c_str(), _fragmentFile.c_str());
  CHECKATTRIBUTE(_transformation_U, "transformation",
    _vertexFile.c_str(), _fragmentFile.c_str());
  CHECKUNIFORM(_color_U, "in_color", 
    _vertexFile.c_str(), _fragmentFile.c_str());
  // error check
  GLenum error_code = glGetError();
  if (error_code) {
    OpenGLError error("GraphicShader.cpp", "GraphicShader()");
    error.Code(error_code);
    error.Add("Encountered while finding attribute and uniform locations.");
    throw(error);
  }
  // prepare position attribute
  glBindVertexArray(graphic.VertexArray());
  glBindBuffer(GL_ARRAY_BUFFER, graphic.VertexBuffer());
  glVertexAttribPointer(_position_A, 3, GL_FLOAT,
                        GL_FALSE, 3 * sizeof(GLfloat), 0);
  glEnableVertexAttribArray(_position_A);
  glBindVertexArray(0);
  glBindBuffer(GL_ARRAY_BUFFER, 0);

  // error check
  error_code = glGetError();
  if (error_code) {
    OpenGLError error("GraphicShader.cpp", "GraphicShader()");
    error.Code(error_code);
    error.Add("Encountered while setting up the postion attribute pointer.");
    throw(error);
  }
}

/*!
\brief Gets the location of the position attribute.
\return The location of the position attribute.
*/
GLint GraphicShader::PositionA() const
{
  return _position_A;
}

/*!
\brief Gets the location of the tranformation uniform.
\return The location of the tranformation uniform.
*/
GLint GraphicShader::TransformationU() const
{
  return _transformation_U;
}

/*!
\brief Gets the location of the in_color uniform.
\return The location of the in_color uniform.
*/
GLint GraphicShader::ColorU() const
{
  return _color_U;
}
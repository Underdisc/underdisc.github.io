/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#pragma once
/*****************************************************************************/
/*!
\file EnergyController.h
\author Gabe Miller
\par E-mail: g.miller\@digipen.edu
\par Project: Boat Game
\date 3/16/2017 11:24:01 AM
\brief
*/
/*****************************************************************************/

#ifndef EnergyController_H
#define EnergyController_H

#include "Component.h"
#include "spaceID.h"

/*****************************************************************************/
/*!
\class EnergyController
\brief


\par
	Operations include:
	-

\deprecated
	-

\bug
	-
*/
/*****************************************************************************/
class EnergyController : public Component
{
public:
  enum EnergyType
  {
    ENGINE = 0,
    HANDLING,
    SHIELDS,
    WEAPONS
  };
  EnergyController();
  void Update();
  int GetEnergyLevel(EnergyType energy);
  void SetHUD(spaceID hud);
private:
  static int _energyValues[4];
  static int _currEnergy;
  static int _storedEnergy;
  float _energyLevel;
  float _shieldLevel;
  spaceID _HUD;
  Object * _pipSprites[16] = { NULL };
  Object * _energySprites[10] = { NULL };
  Object * _highlight;
};

Component * CreateEnergyControllerComponent(Json::Value value);

#endif
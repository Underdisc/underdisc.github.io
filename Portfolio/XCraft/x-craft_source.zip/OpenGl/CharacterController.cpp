/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file CharacterController.cpp
\author yourname
\par E-mail: youremail
\par Project: Boat Game
\date 10/21/2016 8:02:27 PM
\brief

\par
Functions Include:
-
*/
/*****************************************************************************/

#include "CharacterController.h"
#include <glm/glm.hpp>
#include <glm/glm/gtx/projection.hpp>
#include "GameObjectManager.h"
#include <iostream> // debug
#include "ArchetypeManager.h"
#include "AudioEngine.h"
#include "SpaceManager.h"
#include "State.h"
#include "Physics.h"
#include "Time.h"
#include "EnergyController.h"
#include "TexturePool.h"
#include "ShaderPool.h"
#include "GraphicPool.h"
#include "Emitter.h"

#include "CharacterHealth.h"
#include <glm/gtc/constants.hpp>

#define MAX_HEALTH 3
#define PARTICLEATSPEED 5.0f

namespace
{
  float time = 0.0f;
  bool calvinbug = false;
}

bool CharacterController::_autoplay = false;

void CharacterController::Update()
{
  Physics * physicsComponent = Owner().Find<Physics>();
  Transform * transform = Owner().GetTransform();
  float scalar = 3;
  float maxTurnAngle = 60.0f;           //This is the max rotation angle of the rudder
  float turnSpeed = 70.0f;             //This is the rotation speed of the rudder
  float turningAcceleraton = 1.0f;      //This is how much forward acceleration is applied when turning
  float maxTurnAngleSpeedFactor = 3.0f; //This adjusts how much the forward speed decreases the turning
  float forwardForce = 6.0f;            //The forward engine force of boat (base value)
  float sidewaysDrag = 0.01f;            //Controls how fast the boat slows down any sideways motion. 1.0 = 100% drag.

  float speedEnergyScalar = 1.0f;       //The amount that speed is increased based on energy level
  float turnSpeedEnergyScalar = 1.3f;    //The amount that turning speed is increased based on energy level
  float maxRudderAngleEnergyScalar = 0.3f;

  //Getting energy levels
  int engineEnergy = Owner().Find<EnergyController>()->GetEnergyLevel(EnergyController::EnergyType::ENGINE);
  int handlingEnergy = Owner().Find<EnergyController>()->GetEnergyLevel(EnergyController::EnergyType::HANDLING);

  //Adjusting boat physics settings based on energy levels
  forwardForce *= (speedEnergyScalar * engineEnergy);
  maxTurnAngle *= (maxRudderAngleEnergyScalar * handlingEnergy);
  turnSpeed *= (turnSpeedEnergyScalar * handlingEnergy);

  //Adjusting values so that zero energy level = a value of zero on the forces, angles, and speeds
  if (engineEnergy == 0)
  {
	  forwardForce = 0.0f;
  }
  
  if (handlingEnergy == 0)
  {
	  maxTurnAngle = 0.0f;
	  turnSpeed = 0.0f;
	  turningAcceleraton = 0.0f;
  }


  Collider * collider = Owner().Find<Collider>();
  if (collider->Collided())
  {
    for each (CollisionInfo info in collider->GetCollisionList())
    {
      if (info.GetObject()->Find<Collider>()->GetCollisionGroup() == "Tile" && calvinbug)
      {
        calvinbug = false;
        time = 0.0f;
        _speedSetting = 0;
      }
    }
  }

  else if (!_playedEngine)
  {
    audEngine.PlayEvent(_engineEvent);
    _playedEngine = true;
  }

  if (InputManager::Instance()->isKeyDown(SDL_SCANCODE_LCTRL) && InputManager::Instance()->isKeyDown(SDL_SCANCODE_A))
  {
    if (!autoplaykeypressed)
      _autoplay = !_autoplay;
    autoplaykeypressed = true;
  }
  else
    autoplaykeypressed = false;
   
  physicsComponent->SetAngularVelocity(0);

  //Getting forward direction
  float rotation = transform->GetRotation();
  glm::vec3 forwardVec = glm::vec3(glm::cos(rotation), glm::sin(rotation), 0);
  glm::vec3 sidewaysVec = glm::vec3(-forwardVec.y, forwardVec.x, 0.0f);

  //Calculating forward speed
  glm::vec2 curVel = physicsComponent->GetVelocity();
  float forwardSpeed = glm::length(glm::proj(curVel, glm::vec2(forwardVec.x, forwardVec.y)));
  float sidewaysSpeed = glm::length(glm::proj(curVel, glm::vec2(sidewaysVec.x, sidewaysVec.y)));
  float forwardVecPositivity = glm::dot(curVel, glm::vec2(forwardVec.x, forwardVec.y));
  float sidewaysVecPositivity = glm::dot(curVel, glm::vec2(sidewaysVec.x, sidewaysVec.y));

  if (forwardVecPositivity < 0)
  {
	  forwardSpeed = -forwardSpeed;
  }
  if (sidewaysVecPositivity < 0)
  {
	  sidewaysSpeed = -sidewaysSpeed;
  }

  glm::vec3 sidewaysDragVec = sidewaysVec * (sidewaysSpeed * sidewaysDrag);

  //Getting current inputs & speed positivity
  rudderInput = LRInput();
  throttlePositivity = FBInput();
  forwardSpeedPositivity = 0;


  //Getting the positivity of the current speed
  if (forwardSpeed < 0)
  {
	  forwardSpeedPositivity = -1;
  }
  else if (forwardSpeed > 0)
  {
	  forwardSpeedPositivity = 1;
  }

  //If ship is turning at all, then adjust rudder angle based on speed, max angle, and input
  if (!StateFactory::Active(DRIVER_INVENTORY) && rudderInput != 0)
  {
	  //Calculating rudder angle based on input, then clamping it based on speed
	  float currMaxAngle = (maxTurnAngle - (glm::abs(forwardSpeed) * maxTurnAngleSpeedFactor));

	  //Making sure curMaxAngle does not go negative. Not using abs here because when this value goes negative 
	  //it should actually be 0.
	  currMaxAngle = glm::clamp(maxTurnAngle, 0.0f, maxTurnAngle);

	  //Adjusting rudder angle and clamping it to min and max
	  _rudderAngle += turnSpeed * -rudderInput * Time::DT();
	  _rudderAngle = glm::clamp(_rudderAngle, -currMaxAngle, currMaxAngle);

	  //Accelerating boat when it is turning
	  physicsComponent->ApplyForce(forwardVec * turningAcceleraton * physicsComponent->GetMass());
  }
  //If input is not telling ship to turn, auto move the rudder back to center
  else
  {
	  float autoTurnSpeed = turnSpeed * Time::DT();

	  if (glm::abs(_rudderAngle) < autoTurnSpeed)
	  {
		  _rudderAngle = 0.0f;
	  }
	  else if (_rudderAngle > 0.0f)
	  {
		  _rudderAngle -= autoTurnSpeed;
	  }
	  else if (_rudderAngle < 0.0f)
	  {
		  _rudderAngle += autoTurnSpeed;
	  }
  }

  physicsComponent->SetVelocity(glm::vec2(curVel.x - sidewaysDragVec.x, curVel.y - sidewaysDragVec.y));
  physicsComponent->SetAngularVelocity(_rudderAngle / 45);
  physicsComponent->ApplyForce(forwardVec *  physicsComponent->GetMass()  * (forwardForce * throttlePositivity));

  audEngine.SetEventParameter(_engineEvent, "Engine Speed", (glm::abs(throttlePositivity) * 50.0f));
  //std::cout << transform->GetTranslation().x << ", " << transform->GetTranslation().y << std::endl;

  if (glm::length(physicsComponent->GetVelocity()) < PARTICLEATSPEED) {
    _leftEmitter->_stopSpawing = true;
    _rightEmitter->_stopSpawing = true;
  }
  else {
    _leftEmitter->_stopSpawing = false;
    _rightEmitter->_stopSpawing = false;
  }
}


void CharacterController::SetHUD(spaceID HUD)
{
  _HUD = HUD;
}

CharacterController::CharacterController(std::string engineEvent, SDL_Scancode upKey, SDL_Scancode downKey, SDL_Scancode leftKey, SDL_Scancode rightKey) :
  Component("CharacterController"),
  _speedSetting(0),
  _upKey(upKey),
  _downKey(downKey),
  _leftKey(leftKey),
  _rightKey(rightKey),
  _upKeyWasDown(false),
  _downKeyWasDown(false),
  _engineEvent("event:/SFX/enginesound")
{
}

CharacterController::~CharacterController()
{
  if(_playedEngine)
    audEngine.StopEvent(_engineEvent);
  delete _leftEmitter;
  delete _rightEmitter;
}

void CharacterController::Init()
{

  _HUD = Owner().Find<CharacterHealth>()->GetHUD();

  _leftEmitterTransform = new Transform();
  _rightEmitterTransform = new Transform();

  Texture * water = TexturePool::Add("Resources/Visual/VFX/Particle/water.png");                                           //              size
  _leftEmitter = Emitter::createEmitter(BUBBLE, &(ShaderPool::Texture()), &(GraphicPool::Texture()), _leftEmitterTransform, 500, 200.0f, 0.17f, 0.25f, 0.25f, 10, 5, 10, 1, 0, 360);
  _leftEmitter->Init();
  _leftEmitter->setTexture(water);
  _leftEmitterTransform->ChangeParent(Owner().GetTransform());
  _leftEmitterTransform->SetTranslation(glm::vec3(-1.1f, 0.47f, -10.0f));
  (**Owner().ObjectManager()->Space()).GetRenderer().Add(_leftEmitter);


  _rightEmitter = Emitter::createEmitter(BUBBLE, &(ShaderPool::Texture()), &(GraphicPool::Texture()), _rightEmitterTransform, 500, 200.0f, 0.17f, 0.25f, 0.25f, 10, 5, 10, 1, 0, 360);
  _rightEmitter->Init();
  _rightEmitter->setTexture(water);
  _rightEmitterTransform->ChangeParent(Owner().GetTransform());
  _rightEmitterTransform->SetTranslation(glm::vec3(-1.1f, -0.47f, -10.0f));
  (**Owner().ObjectManager()->Space()).GetRenderer().Add(_rightEmitter);


}

int CharacterController::LRInput()
{
  _time += Time::DT();
  if (!_autoplay)
  {
    if (TheInputManager::Instance()->isKeyDown(_leftKey))
    {
      return -1;
    }
    else if (TheInputManager::Instance()->isKeyDown(_rightKey))
    {
      return 1;
    }
  }
  else
  {
    static int prev;
    if (_time > 0.5f)
    {
      int randomval = rand() % 100 + 1;
      if (randomval < 20)
        prev = -1;
      else if (randomval < 40)
        prev = 1;
      else
        prev = 0;
    }
    return prev;
  }
  return 0;
}

int CharacterController::FBInput()
{
  //Getting the positivity of the current throttle
  if (!_autoplay)
  {
    if (TheInputManager::Instance()->isKeyDown(_upKey))
    {
      return 1;
    }
    else if (TheInputManager::Instance()->isKeyDown(_downKey))
    {
      return -1;
    }
  }
  else
  {
    static int prev;
    if (_time > 0.5f)
    {
      _time = 0;
      int randomval = rand() % 100 + 1;
      if (randomval < 5)
        prev = -1;
      else if (randomval < 15)
        prev = 0;
      else
        prev = 1;
    }
    return prev;
  }
  return 0;
}

Component * CreateCharacterControllerComponent(Json::Value value)
{  
  Component * newComponent = new CharacterController(value["engineSound"].asString());
  return newComponent;
}

int CharacterController::GetSpeedSetting()
{
  if (_speedSetting < 0)
  {
    return -_speedSetting;
  }
  
  return _speedSetting;
}
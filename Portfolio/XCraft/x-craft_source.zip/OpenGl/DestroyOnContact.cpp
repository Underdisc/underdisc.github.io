/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file DestroyOnContact.cpp
\author yourname
\par E-mail: youremail
\par Project: Boat Game
\date 11/2/2016 1:03:12 PM
\brief

\par
Functions Include:
-
*/
/*****************************************************************************/

#include "DestroyOnContact.h"
#include "Collider.h"
#include "Object.h"
#include "GameObjectManager.h"
#include <iostream>

#include "Enemy.h"
#include "Projectile.h"

void DestroyOnContact::Update()
{
  Collider * collider = Owner().Find<Collider>();
  if (collider->Collided())
  {
    Owner().ObjectManager()->DeleteObject(&Owner());
  }
}

DestroyOnContact::DestroyOnContact() : Component("DestroyOnContact")
{

}

Component * CreateDestroyOnContact(Json::Value value)
{
  return new DestroyOnContact();
}
/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#pragma once
/*****************************************************************************/
/*!
\file AdaptiveMusic.h
\author Gabe Miller
\par E-mail: g.miller\@digipen.edu
\par Project: Boat Game
\date 2/18/2017 3:55:55 PM
\brief
*/
/*****************************************************************************/

#ifndef AdaptiveMusic_H
#define AdaptiveMusic_H

#include "Component.h"

/*****************************************************************************/
/*!
\class AdaptiveMusic
\brief


\par
	Operations include:
	-

\deprecated
	-

\bug
	-
*/
/*****************************************************************************/
class AdaptiveMusic : public Component
{
public:
  AdaptiveMusic(std::string song, std::string param);
  void Update();
  void Init();
  static bool track;
private:
  std::string _song;
  std::string _param;
  float _combatStatus;
};

Component * CreateAdaptiveMusicComponent(Json::Value value);
#endif
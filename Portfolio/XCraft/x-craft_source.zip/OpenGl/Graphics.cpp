/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file Graphics.cpp
\author Connor Deakin
\par E-mail: connor.deakin@digipen.edu
\par Project: Mecha
\date 07/10/2016
\brief
  Contains the implementation of the functions in the Graphics namespace. Most
  of these functions consist purely of OpenGL calls.

\par
    Functions Include:
    - Graphics::SetClearColor
    - Graphics::BlendMode
    - Graphics::Clear
*/
/*****************************************************************************/

#include <GL\glew.h> // OpenGL

#include "Graphics.h" // Graphics

/*****************************************************************************/
/*!
\brief
  This will put openGL in one of many Blend modes. Blending is to be used for
  combining alpha values together. For example, if you want something to seem
  like it is under a window, you would want to blend the window over the objects
  behind it.
*/
/*****************************************************************************/
void Graphics::BlendMode()
{
  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
}

/*****************************************************************************/
/*!
\brief
  Enables OpenGL depth testing.
*/
/*****************************************************************************/
void Graphics::DepthMode()
{
  glEnable(GL_DEPTH_TEST);
}

/*****************************************************************************/
/*!
\brief
This will set what RGB color value is used when the screen is cleared.

\param red
  The red component of the RGB value.
\param green
  The green component of the RGB value.
\param blue
  The blue component of the RGB value.
\param alpha
  The alpha component of the RGB value.
*/
/*****************************************************************************/
void Graphics::SetClearColor(float red, float green, float blue, float alpha)
{
  glClearColor(red, green, blue, alpha);
}

/*****************************************************************************/
/*!
\brief
  Clears the screen of all graphics using the current clear color. Look at
  SetClearColor to change this color. This will also clear the depth buffer,
  no matter whether it is enabled or not.
*/
/*****************************************************************************/
void Graphics::Clear()
{
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}
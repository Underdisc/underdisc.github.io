/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file Emiter.h
\author Sukanya Ratanotayanon
\par E-mail: sukanya_r@sci.tu.ac.th
\par Project: Boat Game
\date 2/13/2017 12:13:56 PM
\brief
*/
/*****************************************************************************/

#ifndef EMITTER_H
#define EMITTER_H

#include "Particle.h"
#include "CircleGraphic.h"
#include "GraphicShader.h"
#include "Shader.h"
#include "Texture.h"

/*****************************************************************************/
/*!
\class Emiter
\brief


\par
	Operations include:
	-

\deprecated
	-

\bug
	-
*/
/*****************************************************************************/
enum EmitterType {
  BUBBLE,
  CIRCLE_RING
};
class Emitter 
{
public:
  Emitter(const Shader * shader, const Graphic *graphic, Transform * transform, int totalParticle = 150,
    float emissionRate = 0.2f, float defaultSize = 0.7, float defaultSpeed = 0.7, float defaultLife = 0.6,
    int sizeScale = 10, int speedScale = 10, int lifeScale = 10, int shootAmount = 1, int startDegree = 0,
    int endDegree = 360);
  virtual ~Emitter();
  virtual void Update(const glm::mat4 & world_to_ndc);
  bool IsRunout();
  bool IsActive();
  void SetActive(bool active);
  void Init();
  Transform * GetTransform();
  void setTexture(Texture *tex) {
    _texture = tex;
  }
  static Emitter* createEmitter(EmitterType type, const Shader * shader, const Graphic *graphic,
    Transform * transform, int totalParticle = 150,
    float emissionRate = 0.2f, float defaultSize = 0.3, float defaultSpeed = 0.7, float defaultLife = 0.4,
    int sizeScale = 5, int speedScale = 5, int lifeScale = 10,  int shootAmount = 20, int startDegree = 0,
    int endDegree = 360);
  bool _stopSpawing;
protected:
  /** Not sure if this should be a sprite
  * Also, the shaderID and graphicID should be with the emiter when we have it
  */
  //! The ID of the shader that is to be used for drawing the sprite.
  const Shader *_shader;
  //! The ID of the graphic that is to be used for drawing the sprite.
  const Graphic *_graphic;
  Particle ** _particlePool;
  float _emisionRate;
  float _defaultSize;
  int _sizeScale;
  float _defaultSpeed;
  int _speedScale;
  bool _active;
  int _totalParticle;
  int _particleIndex;
  float _defaultLife;
  int _lifeScale;
  float _timeCount;
  int _shootAmount;
  glm::vec4 _color;
  int _startDegree;
  int _endDegree;

  Texture * _texture;
  Transform * _transform;
  void clearParticlePool();
  void shootParticle();
  void shootParticle(int number);
  void drawParticle(Particle *p, const glm::mat4 & world_to_ndc);
  virtual void updateParticles(float deltaTime);
  

};

class RingEmitter :public Emitter {
private:
  bool _willMove = false;
public:
  RingEmitter(const Shader *shader, const Graphic *graphic, Transform * transform, int totalParticle = 150,
    float emissionRate = 0.2f, float defaultSize = 0.3, float defaultSpeed = 0.7, float defaultLife = 0.4,
    int sizeScale = 5, int speedScale = 5, int lifeScale = 10, int shootAmount = 20, int startDegree = 0,
    int endDegree = 360);
  virtual ~RingEmitter();
  virtual void updateParticles(float deltaTime);
  void setWillMove(bool move);
};


#endif //! EMITTER_H
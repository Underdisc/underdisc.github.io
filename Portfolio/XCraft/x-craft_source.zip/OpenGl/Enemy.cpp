/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file Enemy.cpp
\author yourname
\par E-mail: youremail
\par Project: Boat Game
\date 10/31/2016 6:23:39 PM
\brief

\par
Functions Include:
-
*/
/*****************************************************************************/

#include "Enemy.h"
#include "Object.h"
#include "GameObjectManager.h"
#include "Transform.h"
#include "Physics.h"
//#include "GameStateManager.h"
#include "PhysicsDemo.h"
#include "Vec2Math.h"
#include "AudioEngine.h"

int Enemy::_activated = 0;



Enemy::Enemy() : _dist(15), Component("Enemy")
{
}

Enemy::~Enemy()
{
  if (_triggered)
    _activated -= 1;
}

void Enemy::Init()
{
  // *** SUBSCRIBING AN EVENT *** //
  // This is how to use subscribe callback. The ID can be any arbitrary string,
  // however, I recommend storing the ID of the event you are using to reduce error.
  // std::bind is used because we are creating a function object, rather than using a function pointer.
  // std::placeholders::_1 tels it that there is 1 argument, and that argument will be passed in later.
  // Unless somebody has a better option, this is the syntax we have to use.
  Owner().SubscribeCallback(EnemyDamaged::ID, std::bind(&Enemy::Damaged, this, std::placeholders::_1));
  Owner().SubscribeCallback(EnemyDamaged::DeathID, std::bind(&Enemy::Dead, this, std::placeholders::_1));
  _player = Owner().ObjectManager()->FindObjectByName("Player");
}


void Enemy::Update()
{
  /*
  Collider * collider = Owner().Find<Collider>();
  for each (CollisionInfo info in collider->GetCollisionList())
  {
    if (info.GetObject()->Find<Collider>()->GetCollisionGroup() == "Bullet")
    {
      // *** DISPATCHING AN EVENT *** //
      // Note that you can and should use a static allocated event, because the event should not be used
      // after it exits this scope. Keep that in mind when writing your event callbacks.
      // Note that changing the number in this event changes the damage done to enemies.
      Owner().DispatchEvent(&EnemyDamaged(2));
    }
  }
  */

  //_player = Owner().ObjectManager->FindObjectByName("Player");

  if (_player != nullptr)
  {

    Transform * playerTransform = _player->GetTransform();
    Transform * selfTransform = Owner().GetTransform();
    if (_triggered)
    {
      Physics * selfPhysics = Owner().Find<Physics>();
      glm::vec3 toPlayer = playerTransform->GetTranslation() - selfTransform->GetTranslation();
      selfPhysics->ApplyForce(glm::normalize(glm::vec2(toPlayer.x, toPlayer.y)) * selfPhysics->GetMass() * 5.0f);

    }
    else
    {
      if (Math::DistanceSquared(playerTransform->GetTranslation(), selfTransform->GetTranslation()) <= _dist * _dist)
      {
        _triggered = true;
        _activated += 1;
      }
    }
  
  }
  else
  {
    _player = Owner().ObjectManager()->FindObjectByName("Player");
  }
}

// *** EVENT CALLBACK FUNCTION *** //
void Enemy::Damaged(Event * damagedEvent)
{
  EnemyDamaged * _event = static_cast<EnemyDamaged *>(damagedEvent);

  // Generic responses to this event
  if (_triggered == false)
  {
    _activated += 1;
    _triggered = true;
  }

  if (_event->collisionInfo.GetObject()->Find<Collider>()->GetCollisionGroup() != "Flame")
  {
    Physics * selfPhysics = Owner().Find<Physics>();
    selfPhysics->ApplyForce(_event->collisionInfo.GetNormal() * selfPhysics->GetMass() * 700.0f);
  }
}

void Enemy::Dead(Event * deadEvent)
  {
    Owner().ObjectManager()->CreateArchetypeObjectAtPosition("explosion", Owner().GetTransform()->GetTranslation());
    audEngine.PlayEvent("event:/SFX/enemyexplosion");
}

int Enemy::GetActivated()
{
  return _activated;
}

Component * CreateEnemyComponent(Json::Value value)
{
  return new Enemy();
}


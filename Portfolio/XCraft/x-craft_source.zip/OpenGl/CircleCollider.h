/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file CircleCollider.h
\author Gabe Miller
\par E-mail: g.miller\@digipen.edu
\par Project: Boat Game
\date 10/6/2016 6:33:20 PM
\brief
	The circle collider interface file.
*/
/*****************************************************************************/
#pragma once

#ifndef CircleCollider_H
#define CircleCollider_H

#include "Component.h"
#include "Collider.h"

/*****************************************************************************/
/*!
\class CircleCollider
\brief
	Basic circle collider component. Must have a physics component to use this.

\par
	Operations include:
	- Constructor
	- Get the radius
	- Check for collision with another object.

\deprecated
	-

\bug
	-
*/
/*****************************************************************************/
class CircleCollider : public Collider
{
public:
	CircleCollider(float radius, std::string collisionGroup = "Default Group");
  float GetRadius();
  void SetRadius(float radius);
  glm::vec2 * GeneratePoints(int * size);
private:
	float _radius;
	bool CheckCollision(Collider * other);
};


#endif
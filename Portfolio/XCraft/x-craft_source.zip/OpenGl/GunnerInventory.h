/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#ifndef GUNNER_INVENTORY_H
#define GUNNER_INVENTORY_H

#include "Component.h"
#include "spaceID.h"
#include "Transform.h"
#include "StateFactory.h"


class GunnerInventory : public Component
{
public:
  enum GunType
  {
    FLAMETHROWER = 0,
    MACHINEGUN,
    RAILGUN
  };

  GunnerInventory();
  void Update();
  void SetHUD(spaceID hud);

private:
  Object* _highlight;
  int _weaponChosen;
  int _modularSlot;
  int _bottomSelected;
  spaceID _HUD;
  std::vector<std::string> _gunIndex;
  std::vector<Object*> _gunObjs;
  Transform * zeroGun;
  Transform * oneGun;
  Transform * twoGun;
  Transform * threeGun;
  Transform * fourGun;
  Object * player;
  State* _levelone;
};

Component * CreateGunnerInventoryComponent(Json::Value value);

#endif // GUNNER_INVENTORY_H
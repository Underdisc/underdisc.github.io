/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file GraphicSprite.cpp
\author Connor Deakin
\par E-mail: connor.deakin\@digipen.edu
\par Project: Graphics
\date 07/03/2017
\brief
  Contains the implementation of the GraphicSprite.
*/
/*****************************************************************************/

#include <GLM/glm/gtc/type_ptr.hpp>

#include "OpenGLError.h"
#include "GraphicPool.h"

#include "GraphicSprite.h"

/*****************************************************************************/
/*!
\brief
  Creates a GraphicSprite with a white color.

\param shader
  The shader used to render the Graphic.
*/
/*****************************************************************************/
GraphicSprite::GraphicSprite(const GraphicShader * shader) :
Sprite(GRAPHIC), _shader(shader)
{}

/*****************************************************************************/
/*!
\brief
  Draws the GraphicSprite with it's current color.
*/
/*****************************************************************************/
void GraphicSprite::Draw(const glm::mat4 & transformation) const
{
  _shader->Use();
  // setting uniforms
  glUniformMatrix4fv(_shader->TransformationU(), 1, GL_FALSE, 
                     glm::value_ptr(transformation));
  glUniform4fv(_shader->ColorU(), 1, glm::value_ptr(_color));
  GLenum error_code = glGetError();
  if (error_code) {
    OpenGLError error("GraphicSprite.cpp", "Draw");
    error.Code(error_code);
    error.Add("Encountered while setting the GraphicShader's color uniform.");
    throw(error);
  }
  // drawing
  GraphicPool::Default().Draw();
}


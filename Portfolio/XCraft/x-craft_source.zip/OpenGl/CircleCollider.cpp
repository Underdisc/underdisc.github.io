/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file CircleCollider.cpp
\author Gabe Miller
\par E-mail: g.miller\@digipen.edu
\par Project: Boat Game
\date 10/6/2016 6:35:41 PM
\brief

\par
Functions Include:
	- Constructor
	- CheckCollision
	- GetRadius
*/
/*****************************************************************************/

#include "CircleCollider.h"
#include "Object.h"
#include "BoxCollider.h"

#include <glm/glm.hpp>

#include <glm\gtc\constants.hpp>


/*****************************************************************************/
/*!
\brief
	Constructor for the circle collider class. Currently only sets radius,
	as well as calling the constructor for the base class to set the collider
	type.

\param radius
	The radius of the circle collider.
*/
/*****************************************************************************/
CircleCollider::CircleCollider(float radius, std::string collisionGroup) : 
	Collider(Collider::Circle, collisionGroup), _radius(radius)
{

}

/*****************************************************************************/
/*!
\brief
	Check collision for circle colliders. This is called in the update function
	of the base class every frame, and determines which collision function to call.

\param other
	This is the other object that the class checks collision with.

\return
	Returns true if a collision happened, or false if it did not.
*/
/*****************************************************************************/
bool CircleCollider::CheckCollision(Collider * otherCollider)
{
  // Case: Circle collider
	if (otherCollider->Type() == Circle)
		return StaticCircleToStaticCircle(this, static_cast<CircleCollider *>(otherCollider));
  if (otherCollider->Type() == Box)
    return StaticBoxtoStaticCircle(static_cast<BoxCollider *>(otherCollider), this);

	return false;
}

glm::vec2 * CircleCollider::GeneratePoints(int * size)
{
  *size = 8;
  glm::vec2 * points = new glm::vec2[8];
  for (int i = 0; i < 8; i++)
  {
    points[i] = glm::vec2( cos(glm::quarter_pi<float>() * i), sin(glm::quarter_pi<float>() * i) ) * _radius;
  }
  return points;
}

/*****************************************************************************/
/*!
\brief
	Gets the radius of the circle collider.

\return
	Returns the radius as a float.
*/
/*****************************************************************************/
float CircleCollider::GetRadius()
{
	return _radius;
}


void CircleCollider::SetRadius(float radius)
{
  _radius = radius;
}
/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#ifndef AUDIO_ENGINE_H
#define AUDIO_ENGINE_H

#include <FMOD\fmod.hpp>
#include <FMOD\fmod_studio.hpp>
#include <string>
#include <map>
#include <vector>
#include <math.h>
#include <iostream>
#include <glm\glm\vec3.hpp>


// Need this until we create a vector class
// Used for placing sounds in the space
struct Vector3
{
	float x;
	float y;
	float z;
};


// Implmentation struct is going to most of the calls to the FMOD API
// Seperating the calls from the audio engine prevents annoying bugs
// This also will contain a map with all the sounds and events
struct Implementation
{
	Implementation();
	~Implementation();

	void Update();



	FMOD::Studio::System* mpStudioSystem;
	FMOD::System* mpSystem;

	int mnNextChannelID;

	// typedef some stuff to save typing
	// also helps with readability of course
	typedef std::map<std::string, FMOD::Sound*> SoundMap;
	typedef std::map<int, FMOD::Channel*> ChannelMap;
	typedef std::map<std::string,FMOD::Studio::EventInstance*> EventMap;
	typedef std::map<std::string, FMOD::Studio::Bank*> BankMap;

	BankMap mBanks;
	EventMap mEvents;
	SoundMap mSounds;
	ChannelMap mChannels;

};


class AudioEngine
{
public:


	static void Init();
	static void Update();
	static void ShutDown();
	static int ErrorCheck(FMOD_RESULT result);


  void InitBanks();
	void LoadBank(const std::string& strBankName, FMOD_STUDIO_LOAD_BANK_FLAGS flags);
	void LoadEvent(const std::string& strEventName);
	void LoadSound(const std::string& strSoundName, bool b3d = true, bool bLooping = false, bool bStream = false);
	void UnloadSound(const std::string& strSoundName);
	void Set3dListenerAndOrientation(const glm::vec3& vPos = glm::vec3{ 0, 0, 0 }, float fVolumedB = 0.0f);
	int PlaySound(const std::string& strSoundName, const glm::vec3 vPos = glm::vec3{ 0, 0, 0 }, float fVolumedB = 0.0f);
	void PlayEvent(const std::string& strEventName);
	void StopChannel(int nChannelID);
  void StopAllChannels();
	void StopEvent(const std::string& strEventName, bool bImmediate = false);
	void GetEventParameter(const std::string& strEventName, const std::string& strEventParameter, float* parameter);
	void SetEventParameter(const std::string& strEventName, const std::string& strEventParameter, float fValue);
	void PauseAllChannels();
  //ONLY CALL PlayAllChannels IF THEY ARE PAUSED ALREADY
  void PlayAllChannels();
  // Pass in a float. The default volume is 1.0f
  // 0.5f would be half volume, 2.0f would be double the volume
  void SetVolumeAllChannels(float volume);
  float GetVolumeAllChannels();
	void SetChannel3dPosition(int nChannelID, const glm::vec3& vPosition);
	void SetChannelVolume(int nChannelID, float fVolumedB);
	bool IsEventPlaying(const std::string& strEventName) const;
	float dbToVolume(float db);
	float VolumeTodb(float volume);
  void SetBusGroupVolume(const char* busName, float volume);
  float GetBusGroupVolume(const char* busName);
	FMOD_VECTOR VectorToFmod(const glm::vec3& vPosition);
  std::string GetMusicEvent(std::string levelName);

private:
  std::map<std::string, std::string> _musicMap;
	
};


extern AudioEngine audEngine;

#endif

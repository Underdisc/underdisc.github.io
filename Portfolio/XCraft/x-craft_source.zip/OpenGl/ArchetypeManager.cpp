/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file ArchetypeManager.cpp
\author Gabe Miller
\par E-mail: g.miller\@digipen.edu
\par Project: Boat Game
\date 10/14/2016
\brief
  Contains implementation for the archetype manager class

\par
    Functions Include:
    -InitArchetypes
    -CreateArchetypeObject
*/
/*****************************************************************************/
#include "ArchetypeManager.h"
#include "Component.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <typeinfo>
#include <dirent\dirent.h>
#include "Transform.h"

#include "JsonLevelReader.h"

ArchetypeManager archetypeManager = ArchetypeManager();

/*****************************************************************************/
/*!
\brief
  Loads in all the archetypes from the resources files, and stores them as objects.
*/
/*****************************************************************************/
void ArchetypeManager::InitArchetypes()
{
  // This is the archetype directory, in the future this could be
  // read from file as well.
  std::string directory = "Resources/archetypes/";
  // Opens the directory
  DIR * archetypeDir = opendir(directory.c_str());
  // Contains info about the files in the directory.
  dirent * ent;
  while ((ent = readdir(archetypeDir)) != NULL)
  {
    // Check if the file has the .archetype extension.
    if (std::string(ent->d_name).find(".archetype") != std::string::npos)
    {
      // This is a json file with a single archetype.
      std::ifstream inputFile;
      inputFile.open((directory + ent->d_name));
      Json::Reader reader;
      Json::Value value;
      bool parsingSuccessful = reader.parse(inputFile, value);
      // Check to make sure the file was read correctly.
      if (!parsingSuccessful)
      {
        std::cout << "parsing failed";
        std::cout << reader.getFormattedErrorMessages();
        continue;
      }
      // Get the name of the new archetype from the file.
      std::string archetypeName = *value.getMemberNames().begin();
      // Print out info message
      std::cout << "Making new archetype object named: " << archetypeName << std::endl;
      for each (std::string component in value[archetypeName].getMemberNames())
      {
        std::cout << "Adding component: " << component <<
          " to archetype object: " << archetypeName << std::endl;
        try
        {
          // Checking for dependcies
          JsonLevelReader::CheckDependencies(value[archetypeName]);
          JsonLevelReader::ValidateComponents(value[archetypeName]);
        }
        catch (const DependencyError error)
        {
          std::cout << "Component: " << component << 
            " missing dependency: " << error.dependencyName << std::endl;
          value[archetypeName].removeMember(component);
        }
      }
      // Place the new archetype object in the array of archetype objects, note that this is
      // making a copy, since the array contains objects, not object pointers.
      archetypeManager._archetypeObjects.emplace(archetypeName, value);
    }
  }
}

/*****************************************************************************/
/*!
\brief
  Creates a new copy of the archetype with the given name, and adds it to
  the game object list.

\param archetype
  The name of the archetype you are trying to find.

\return
  Returns a pointer to the new object, or returns nullptr if the archetype
  name was invalid.
*/
/*****************************************************************************/
Object *ArchetypeManager::CreateArchetypeObject(std::string archetype, GameObjectManager * objManager)
{
  std::cout << "Making object from archetype: " << archetype << std::endl;
  Object * newObject = nullptr;
  try
  {
    Json::Value value = _archetypeObjects.at(archetype);
    std::string objectName = *value.getMemberNames().begin();

    newObject = JsonLevelReader::BuildObject(value[objectName], objectName, objManager);
    //newObject->objManager = objManager;
    //newObject->Init();
  }
  catch (std::out_of_range)
  {
    std::cout << "Error - archetype: " << archetype << "not found" << std::endl;
  }
  return newObject;
}

Object *ArchetypeManager::CreateArchetypeObjectAtPosition(std::string archetype, GameObjectManager * objManager, glm::vec3 position)
{
  Object * newObject = CreateArchetypeObject(archetype, objManager);
  if (newObject == nullptr)
    return newObject;
  newObject->GetTransform()->SetTranslation(position);
  return newObject;
}


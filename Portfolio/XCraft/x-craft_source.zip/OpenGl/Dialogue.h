#pragma once
/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file Dialogue.h
\author Gabe Miller
\par E-mail: g.miller\@digipen.edu
\par Project: Boat Game
\date 4/19/2017 1:26:18 PM
\brief
*/
/*****************************************************************************/

#ifndef Dialogue_H
#define Dialogue_H

#include "Component.h"
#include "Renderer.h"

/*****************************************************************************/
/*!
\class Dialogue
\brief


\par
	Operations include:
	-

\deprecated
	-

\bug
	-
*/
/*****************************************************************************/
class Dialogue : public Component
{
public:
  Dialogue();
  void Init();
  void Update();

private:
  Renderer * _spaceRenderer;
  Object * _picture1;
  Object * _picture2;
  float _time;
  int stage;
  Object * _text;
};

Component * CreateDialogueComponent(Json::Value value);
#endif
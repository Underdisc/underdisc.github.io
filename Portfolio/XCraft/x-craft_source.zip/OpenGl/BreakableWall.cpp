/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file BreakableWall.cpp
\author Jonathan Williams
\par E-mail: jonathan.w@digipen.edu
\par Project: Boat Game
\date 3/13/2017 4:40:00 PM
\brief

\par
Functions Include:
-
*/
/*****************************************************************************/

#include "BreakableWall.h"
#include "Object.h"
#include "AudioEngine.h"
#include "Renderer.h"
#include "GameObjectManager.h"
#include "Space.h"
#include "TexturePool.h"
#include "SpritePool.h"
#include "ShaderPool.h"

BreakableWall::BreakableWall() : Component("BreakableWall")
{

}

void BreakableWall::Init()
{

  Owner().SubscribeCallback(EnemyDamaged::ID, std::bind(&BreakableWall::Damaged, this, std::placeholders::_1));
  Owner().SubscribeCallback(EnemyDamaged::DeathID, std::bind(&BreakableWall::Dead, this, std::placeholders::_1));
}

void BreakableWall::Update()
{

}

void BreakableWall::Damaged(Event * damagedEvent)
{
  EnemyDamaged * event = reinterpret_cast<EnemyDamaged *>(damagedEvent);
  audEngine.PlayEvent("event:/SFX/collision");
  if (Owner().Find<EnemyHealth>()->GetHealth() > 0)
  {
    Renderer * renderer = &(**Owner().ObjectManager()->Space()).GetRenderer();
    renderer->Remove(Owner().GetSprite(), Owner().GetTransform());
    std::string texture;
    switch (Owner().Find<EnemyHealth>()->GetHealth() / 3)
    {
    case 2:
      texture = "Resources/Visual/Environment/WoodBox2.png";
      break;
    case 1:
      texture = "Resources/Visual/Environment/WoodBox3.png";
      break;
    case 0:
      texture = "Resources/Visual/Environment/WoodBox4.png";
      break;
    default:
      texture = "Resources/Visual/Environment/WoodBox4.png";
      break;
    }
    Owner().SetSprite(reinterpret_cast<Sprite *>(SpritePool::AddTexture(&ShaderPool::Texture(), TexturePool::Add(texture))));
    renderer->Add(Owner().GetSprite(), Owner().GetTransform());
  }
}

void BreakableWall::Dead(Event * deadEvent)
{
}

Component* CreateBreakableWallComp(Json::Value value_)
{
	return new BreakableWall();
}

/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#pragma once
#include "Collider.h"
#include <vector>

class GameObjectManager;

class CollisionManager
{
public:
  CollisionManager(GameObjectManager * objectManager);
  void Update();
  void AddCollider(Collider * newCollider);
  void RemoveCollider(Collider * collider);
private:
  std::vector<Collider *> _colliders;
  GameObjectManager * _objectManager;
  const std::vector<TileMap *> * _tileMaps;
};
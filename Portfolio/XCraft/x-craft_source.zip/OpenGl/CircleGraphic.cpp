/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file CircleGraphic.cpp
\author Sukanya Ratanotayanon
\par E-mail: sratanot@sci.tu.ac.th
\par Project: Boat Game
\date 3/10/2017 3:20:29 PM
\brief

\par
Functions Include:
-
*/
/*****************************************************************************/
#include "OpenGLError.h"
#include "CircleGraphic.h"
#include <vector>

#define PI 3.14159265f
//*******!!!! Really should be a chile of graphic ------------

CircleGraphic::CircleGraphic()
{

  // mesh values (vertex)
  int sliceNo = 180;
  int stepNo = 360 / 180; //Make sure that the result is an integer
  std::vector<GLfloat> vertices;
  std::vector<GLuint> elements;

  //Add the vertex (0,0,0) as the center of the circle
  for (unsigned i = 0; i < 3; i++) {
    vertices.push_back(0);
  }
  //Generating 180 points on the circumference. 
  for (unsigned i = 0; i < 360; i += stepNo) {
    float radDegree = i *PI / 180;
    float x = cos(radDegree);
    float y = sin(radDegree);
    vertices.push_back(x);
    vertices.push_back(y);
    vertices.push_back(0);
  }
  //Generating edges for the triangle slices 
   //Assume the center is at 0,0,0 and the _verts at 0,1,2 is the x, y, z of the center
  int center = 0;
  int previousPoint = 1;
  for (unsigned currentPoint = 2; currentPoint < sliceNo; currentPoint++) {
    elements.push_back(center);
    elements.push_back(currentPoint);
    elements.push_back(previousPoint);
    previousPoint = currentPoint;
  }
  elements.push_back(center);
  elements.push_back(previousPoint);
  elements.push_back(1);

  _elementSize = elements.size();

  //------------- extracted method from here -------------------
  PrepBuffer(vertices.data(), vertices.size(), elements.data(), elements.size());
  

}

/*****************************************************************************/
/*!
\brief
Draws the graphic to screen using the shader specified in the constructor.
*/
/*****************************************************************************/
void CircleGraphic::Draw() const
{
  // draw
  glBindVertexArray(_vertexArray);
  glDrawElements(GL_TRIANGLES, _elementSize, GL_UNSIGNED_INT, 0);
  glBindVertexArray(0);
  // error check
  GLenum error_code = glGetError();
  if (error_code) {
    OpenGLError error("Graphic.cpp", "Draw");
    error.Code(error_code);
    throw(error);
  }
}




/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#include "DialogueOverlay.h"

void DialogueOverlay::Allocate()
{
  _objectManager.CreateArchetypeObjectAtPosition("dialogue", glm::vec3(0, -10, 0));
}

void DialogueOverlay::Load()
{

}
bool DialogueOverlay::Update()
{
  return true;
}
/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file DriverInventoryComp.h
\author Zach Dolph
\par E-mail: z.dolph\@digipen.edu
\par Project: Boat Game
\date 02/24/2017
\brief
*/
/*****************************************************************************/

#ifndef DRIVER_INV_COMP_H
#define DRIVER_INV_COMP_H

#include "Component.h"
#include "Transform.h"
#include "spaceID.h"

/*****************************************************************************/
/*!
\class DriverInventoryComp
\brief
Component for 

\par
Operations include:
-

\deprecated
-

\bug
- 
*/
/*****************************************************************************/
class DriverInventoryComp : public Component
{
public:
  DriverInventoryComp();
  void Update();
  void OpenInventory();
  void CloseInventory();
  void SetSpace(spaceID driverInv);
  spaceID GetSpace();
  void Init();
private:
  int _lightone;
  int _lighttwo;
  int _lightthree;
  int _lightfour;
  int _buttonPosition;
  spaceID _driverInv;
  Transform * menuSelecTran;
  std::vector<Object*> _lightsVec;
  std::vector<Object*> _pipGlassVec;
};

Component * CreateDriverInventorySystem(Json::Value value);

#endif

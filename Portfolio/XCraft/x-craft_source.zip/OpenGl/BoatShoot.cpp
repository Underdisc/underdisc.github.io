/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file BoatShoot.cpp
\author yourname
\par E-mail: youremail
\par Project: Boat Game
\date 11/18/2016 4:31:33 PM
\brief

\par
Functions Include:
-
*/
/*****************************************************************************/

#include "BoatShoot.h"
#include "SoundEmitter.h"
#include "ArchetypeManager.h"
#include "InputManager.h"
#include "Time.h"
#include "Physics.h"
#include "Space.h"

#include "Line.h"

#include <glm\gtc\constants.hpp>

#include "Projectile.h"

#include "Vec2Math.h"

#include "EnergyController.h"
#include "Context.h"

namespace
{
  bool playedShoot = false;
}

bool BoatShoot::_autoplay = false;

// Location of guns,  Offset   , Direction
static const std::vector< std::pair<glm::vec2, float> > gunPositions
{
  { glm::vec2(0.175,   0.3),  glm::half_pi<float>()   },
  { glm::vec2(-0.75,   0.4),  glm::half_pi<float>()   },
  { glm::vec2(0.175,   -0.3), -glm::half_pi<float>()  },
  { glm::vec2(-0.75,   -0.4), -glm::half_pi<float>()  }
};

// Makes the locations of the guns spacial on the num pad
static int indicies[] =  { 4, 1, 6, 3 };

BoatShoot::BoatShoot(std::string shootEvent) :
  Component("BoatShoot"),
  _cooldown(0.0f),
  _shootEvent(shootEvent),
  _currentGun(0),
  _gunSelected(0)
{
}

void BoatShoot::Init()
{
  //_indicator = Owner().ObjectManager()->CreateObject("Indicator");
  //_indicator->SetSprite()
  Context::HideCursor(true);
  if (_reticule == nullptr)
  {
    _reticule = Owner().ObjectManager()->CreateArchetypeObject("Reticule");
    _cursor = Owner().ObjectManager()->CreateArchetypeObject("Cursor");
    _line1 = Owner().ObjectManager()->CreateArchetypeObject("debugLine");
    _line1->Find<Line>()->width = 0.05;
    _line2 = Owner().ObjectManager()->CreateArchetypeObject("debugLine");
    _line2->Find<Line>()->width = 0.05;
  }

  if (_gunObjects.empty())
  {
    for (int i = 0; i < gunPositions.size(); i++)
    {
      Object * swivel = Owner().ObjectManager()->CreateObject("swivel");
      Owner().AddChild(swivel);
      swivel->GetTransform()->Translation() = glm::vec3(gunPositions[i].first, 0.1f);
      swivel->GetTransform()->Rotation() = gunPositions[i].second;
      _swivels.push_back(swivel);
      Object * gun = Owner().ObjectManager()->CreateArchetypeObjectAtPosition("machineGun", glm::vec3(0.15f, 0, 0.1f));
      gun->GetTransform()->Scale() = gun->GetTransform()->GetScale() * 0.5f;
      swivel->AddChild(gun);
      _gunObjects.push_back(gun);
    }

    for (int i = 0; i < 4; i++)
      _guns.push_back(Gun(6.0f, 1, "Bullet"));
  }

  
}

SDL_Scancode NumToScancode(int i)
{
  switch (i)
  {
  case 0:
    return SDL_SCANCODE_KP_0;
  case 1:
    return SDL_SCANCODE_KP_1;
  case 2:
    return SDL_SCANCODE_KP_2;
  case 3:
    return SDL_SCANCODE_KP_3;
  case 4:
    return SDL_SCANCODE_KP_4;
  case 5:
    return SDL_SCANCODE_KP_5;
  case 6:
    return SDL_SCANCODE_KP_6;
  case 7:
    return SDL_SCANCODE_KP_7;
  case 8:
    return SDL_SCANCODE_KP_8;
  case 9:
    return SDL_SCANCODE_KP_9;
  default:
    return SDL_SCANCODE_KP_0;
  }
}

void BoatShoot::Update()
{
  if (InputManager::Instance()->isKeyDown(SDL_SCANCODE_LCTRL) && InputManager::Instance()->isKeyDown(SDL_SCANCODE_A))
  {
    if (!autoplaykeypressed)
      _autoplay = !_autoplay;
    autoplaykeypressed = true;
  }
  else
    autoplaykeypressed = false;

  _time += Time::DT();
  if (_autoplay)
  {
    if (_time > 0.5f)
    {
      _time = 0;
      int randomval = rand() % 4;
      _currentGun = randomval;
    }
  }

  Transform * transform = Owner().GetTransform();
  // Get data about the mouse transform and move reticule

  glm::vec2 mouseTransform = *InputManager::Instance()->getMousePosition();
  (**Owner().ObjectManager()->Space()).ScreenToWorld(mouseTransform);

  if (TheInputManager::Instance()->getButtonState(1, 4))
  {
    _gunSelected -= 1;
  }

  if (TheInputManager::Instance()->getButtonState(1, 5))
  {
    _gunSelected += 1;
  }

  if (_gunSelected > 4)
  {
    _gunSelected = 0;
  }

  if (_gunSelected < 0)
  {
    _gunSelected = 4;
  }

  glm::vec2 gunToReticule;

  for (size_t i = 0; i < _gunObjects.size(); i++)
  {
    if (InputManager::Instance()->IsKeyPressed(NumToScancode(indicies[i])))
    {
      _currentGun = i;
      std::cout << _currentGun << std::endl;
    }
  }

  for (size_t i = 0; i < _gunObjects.size(); i++)
  {
    Transform * gunTransform = _gunObjects[i]->GetTransform();
    /*
    glm::vec2 pos = gunPositions[i].first;
    Physics * boatPhys = Owner().Find<Physics>();
    float rot = transform->GetRotation() + boatPhys->GetAngularVelocity() * Time::DT();
    gunTransform->Translation() = transform->GetTranslation() + glm::vec3(Math::RotateVector(pos, rot), 0) + glm::vec3(boatPhys->GetVelocity().x, boatPhys->GetVelocity().y, 0.1) * Time::DT();
    gunTransform->Rotation() = gunPositions[i].second + rot;
    */
    if (_currentGun == i)
    {
      /* Moving the cursors around. */
      _reticule->GetTransform()->Translation() = glm::vec3(mouseTransform.x, mouseTransform.y, 1);
      _cursor->GetTransform()->Translation() = glm::vec3(mouseTransform.x, mouseTransform.y, 1);

      float rot = Owner().GetTransform()->Rotation() + gunPositions[i].second;
      glm::vec3 pos = _swivels[i]->GetTransform()->GetAbsoluteTranslation();
      _line1->Find<Line>()->start = pos ;
      _line1->Find<Line>()->end = pos + glm::vec3(glm::cos(rot + glm::quarter_pi<float>() / 2), glm::sin(rot + glm::quarter_pi<float>() / 2), 0) * 10.0f;
      _line2->Find<Line>()->start = pos ;
      _line2->Find<Line>()->end = pos + glm::vec3(glm::cos(rot - glm::quarter_pi<float>() / 2), glm::sin(rot - glm::quarter_pi<float>() / 2), 0) * 10.0f;

      // Get the direction the gun is facing
      float facingAngle = gunPositions[i].second + Owner().GetTransform()->Rotation();
      glm::vec3 gunPosition = _swivels[i]->GetTransform()->GetAbsoluteTranslation();
      // Make vectors for the gun facing direction, and the vector between the gun and the reticule.
      glm::vec2 facingDirection = glm::vec2(glm::cos(facingAngle), glm::sin(facingAngle));
      gunToReticule = mouseTransform - glm::vec2(gunPosition.x, gunPosition.y);
      // Store the length of the reticule before normalizing it.
      float reticuleDistance = glm::length(gunToReticule);
      if (reticuleDistance > 0)
      {
        gunToReticule = gunToReticule / reticuleDistance;
      }
      // Get the angle between where the gun is facing, and where it is aiming
      float reticuleAngle = Math::AngleBetweenFast(facingDirection, gunToReticule);
     
      // If the reticule angle is within the correct angle, skip the next steps.
      if (reticuleAngle < glm::quarter_pi<float>() / 2)
      {
        // If the reticule is closer to the gun than 1 unit
        if (reticuleDistance <= 2)
        {
          _reticule->GetTransform()->Translation() = gunPosition + glm::vec3(gunToReticule.x, gunToReticule.y, 0) * 2.0f;
        }
        float leftRightDotP = glm::sign(glm::dot(Math::RotateVector(facingDirection, glm::radians(90.0f)), gunToReticule));
        _swivels[i]->GetTransform()->Rotation() = reticuleAngle * leftRightDotP + gunPositions[i].second;
        continue;
      }

      // If it is outside, determine where it should be.
      // Get the dot product between the parallel facing direction and the vector to the reticule. Used to determine if
      // the cursor is left or right of the facing direction.
      float leftRightDotP = glm::sign( glm::dot(Math::RotateVector(facingDirection, glm::radians(90.0f)), gunToReticule) );
      float newAngle = leftRightDotP * glm::quarter_pi<float>() / 2 + gunPositions[i].second;
      // If the cursor is all the way behind the ship, rotate the reticule around the front.
      if (reticuleAngle > glm::radians(180.0f) - glm::quarter_pi<float>() / 2)
        newAngle = leftRightDotP * (glm::radians(180.0f) - reticuleAngle) + gunPositions[i].second;
      // Get the dot product between the bounding ray of the aiming radius, and the reticule direction.
      float frontBackDotP = glm::dot(Math::RotateVector(facingDirection, leftRightDotP * glm::quarter_pi<float>() / 2), gunToReticule);
      float newLength = 2.0;
      if (frontBackDotP > 0)
        newLength = (reticuleDistance * glm::cos(reticuleAngle - glm::quarter_pi<float>() / 2));
      if (newLength < 2)
        newLength = 2;
      //newAngle += transform->Rotation();
      _swivels[i]->GetTransform()->Rotation() = newAngle;
      glm::vec2 newDirection = glm::vec2(glm::cos(newAngle + transform->Rotation()), glm::sin(newAngle + transform->Rotation()));
      gunToReticule = newDirection;
      _reticule->GetTransform()->Translation() = _swivels[_currentGun]->GetTransform()->GetAbsoluteTranslation() + glm::vec3(newDirection * newLength, 1);

    }
  }

  if (TheInputManager::Instance()->getMouseButtonState(mouse_buttons::LEFT) || _autoplay || (TheInputManager::Instance()->getJoystickSize() > 1 && TheInputManager::Instance()->getRightTrigger(1)))
  {
    if (_cooldown <= 0)
    {
      float velocity = 30.0f;
      glm::vec3 gunpos = _gunObjects[_currentGun]->GetTransform()->GetAbsoluteTranslation();
      float rot = _gunObjects[_currentGun]->GetTransform()->GetAbsoluteRotation();
      glm::vec3 offset;
      if (_guns[_currentGun].archetype == "flame")
        offset = glm::vec3(cos(rot), sin(rot), -0.1f);
      else
        offset = glm::vec3(cos(rot), sin(rot), 0.1f);
      glm::vec3 muzzlePosition = gunpos + offset;
      Object * bullet = Owner().ObjectManager()->CreateArchetypeObjectAtPosition(_guns[_currentGun].archetype, muzzlePosition);
      Owner().ObjectManager()->CreateArchetypeObjectAtPosition("muzzleFlash", muzzlePosition);
      if (_guns[_currentGun].archetype == "flame")
      {
        if (!playedShoot)
        {
          Owner().Find<SoundEmitter>()->PlaySound("FlameThrower");
          playedShoot = true;
        }
        velocity = 10.0f;
      }
      else if (_guns[_currentGun].archetype == "Bullet")
        Owner().Find<SoundEmitter>()->PlaySound("MachineGun");
      else
        Owner().Find<SoundEmitter>()->PlaySound("RailGun");
      if (bullet != nullptr)
      {
        bullet->Find<Physics>()->SetVelocity(gunToReticule * velocity + Owner().Find<Physics>()->GetVelocity());
        bullet->GetTransform()->Rotation() = Math::AngleBetweenFast(gunToReticule, glm::vec2(1, 0)) * glm::sign(glm::dot(gunToReticule, glm::vec2(0, 1)));
        bullet->Add(new Projectile(_guns[_currentGun].damage * (1 + Owner().Find<EnergyController>()->GetEnergyLevel(EnergyController::WEAPONS) / 4.0f), gunToReticule));
        _cooldown = 1.0f / _guns[_currentGun].fireRate;
      }
    }
  }
  else
  {
    playedShoot = false;
    Owner().Find<SoundEmitter>()->StopSound("FlameThrower");
  }
  _cooldown -= Time::DT();

  
}

/*****************************************************************************/
/*!
\brief
  Change the properties of a gun on the boat.

\param index
  The index, from 0-4, of the gun on the boat.

\param archetype
  The name of the sprite archetype to put on the boat. **ONLY PUT SPRITES 
  WITH TRANSFORMS ON HERE IT'S JUST A SPRITE NOT THE GUN ITSELF**

\param gunProperties
  A gun struct with the properties to set to this gun. This is where you
  actually change the properties.

\return
*/
/*****************************************************************************/
void BoatShoot::ChangeGun(int index, std::string archetype, const Gun & gunProperties)
{
  if (index < 4)
  {
    Owner().ObjectManager()->DeleteObject(_gunObjects[index]);
    _gunObjects[index] = Owner().ObjectManager()->CreateArchetypeObjectAtPosition(archetype, glm::vec3(0.15f, 0, 0.1f));
    _gunObjects[index]->ChangeParent(_swivels[index]);
    _gunObjects[index]->GetTransform()->Scale() = _gunObjects[index]->GetTransform()->GetScale() * 0.5f;
    _guns[index] = gunProperties;
  }
}

Component * CreateBoatShootComponent(Json::Value value)
{
  return new BoatShoot(value["shootSound"].asString());
}
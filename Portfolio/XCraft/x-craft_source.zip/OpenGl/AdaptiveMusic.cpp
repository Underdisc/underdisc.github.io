/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file AdaptiveMusic.cpp
\author Gabe Miller
\par E-mail: g.miller@digipen.edu
\par Project: Boat Game
\date 2/18/2017 5:24:47 PM
\brief

\par
Functions Include:
-
*/
/*****************************************************************************/

#include "AdaptiveMusic.h"
#include "Enemy.h"
#include "SoundEmitter.h"
#include "Object.h"

bool AdaptiveMusic::track = false;

AdaptiveMusic::AdaptiveMusic(std::string song, std::string param) : 
  Component("AdaptiveMusic"), _song(song), _param(param)
{

}

void AdaptiveMusic::Init()
{
  Owner().Find<SoundEmitter>()->PlaySound("Ambience");
  if (!track)
  {
    Owner().Find<SoundEmitter>()->PlaySound("Music2");
    _song = "Music2";
  }
  else
  {
    Owner().Find<SoundEmitter>()->PlaySound("Music");
    _song = "Music";
  }
}

void AdaptiveMusic::Update()
{
  int _targetProgression = Enemy::GetActivated();

  if (_song == "Music")
  {
    if (_targetProgression == 0)
      _combatStatus = 0.0f;

    if (_targetProgression >= 2)
      _combatStatus = 1.0f;
  }

  else
  {
    if (_targetProgression == 0)
      _combatStatus = 0.0f;
    if (_targetProgression > 0 && _targetProgression < 3)
      _combatStatus = 0.26f;
    if (_targetProgression > 2)
      _combatStatus = 1.0f;
  }


  Owner().Find<SoundEmitter>()->SetSoundParameter(_song, _param, _combatStatus);
}


Component * CreateAdaptiveMusicComponent(Json::Value value)
{
  return new AdaptiveMusic(value["Song"].asString(), value["Parameter"].asString());
}
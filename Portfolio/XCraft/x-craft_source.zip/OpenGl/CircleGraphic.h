/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file CircleGraphic.h
\author Sukanya Ratanotayanon
\par E-mail: sukanya_r@sci.tu.ac.th
\par Project: Graphics
\date 3/10/2017 3:20:10 PM
\brief
  Contains the interface for a ParticleGraphic.
*/
/*****************************************************************************/

#ifndef CircleGraphic_H
#define CircleGraphic_H

#include <GL\glew.h>

#include "Graphic.h"

/*****************************************************************************/
/*!
\class CircleGraphic
\brief
  Graphic for drawing a filled circle.
*/
/*****************************************************************************/
class CircleGraphic : public Graphic
{
public:
  CircleGraphic();
  virtual void Draw() const;
protected:
  //! The number of elements in the element buffer.
  int _elementSize;
};

#endif //!PARTICLEGRAPHIC_H
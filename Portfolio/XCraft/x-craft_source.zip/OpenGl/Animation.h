/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file Animation.h
\author Connor Deakin
\par E-mail: connor.deakin\@digipen.edu
\par Project: Graphics
\date 28/02/2017
\brief
Contains the interface for an Animtion. Look at the Animation class
for more information.
*/
/*****************************************************************************/

#ifndef ANIMATION_H
#define ANIMATION_H

#include "TextureSheetSprite.h"
#include "Component.h"

// component creator
Component * CreateAnimationComponent(Json::Value value);

/*****************************************************************************/
/*!
\class Animation
\brief
Used to go through all of the frames on a TextureSheet within a specific
time signature in order ot make an animation.

\par Important Notes
- Only use the Update functions once per frame.
*/
/*****************************************************************************/
class Animation : public Component
{
public:
  Animation(TextureSheetSprite * sprite, float time);
  void Init();
  void Update();
  void SwitchDirection();
private:
  void UpdateForward();
  void UpdateBackward();
  //! The direction the animation updates. If true, the animation will update
  // forward.
  bool _forward;
  //! The total amount of time it should take for the animation to complete.
  float _totalTime;
  //! The amount of time it takes for a single frame to pass.
  float _frameTime;
  //! The amount of time passed since the animation began or in the case of
  // going backwards, the amount of time until the animation is over.
  float _timePassed;
  //! The TextureSheetSprite that will be used to create the Animation.
  TextureSheetSprite * _sprite;
};

#endif // !ANIMATION_H

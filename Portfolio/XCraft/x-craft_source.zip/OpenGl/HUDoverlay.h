/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#ifndef HUD_OVERLAY_H
#define HUD_OVERLAY_H

#include "State.h"

class HUDoverlay : public State
{
  public:
    virtual void Allocate();
    virtual void Load();
    virtual bool Update();
};

#endif

/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#ifndef DRIVER_INVENTORY_H
#define DRIVER_INVENTORY_H

#include "State.h"

class DriverInventory : public State
{
public:
  virtual void Allocate();
  virtual void Load();
  virtual bool Update();
};

#endif // DRIVER_INVENTORY_H
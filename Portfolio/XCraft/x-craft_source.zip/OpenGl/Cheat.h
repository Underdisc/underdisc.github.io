/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#ifndef CHEAT_H
#define CHEAT_H

#include "State.h"

class LevelCheat : public State
{
public:
  virtual void Allocate();
  virtual void Load();
  virtual bool Update();
  virtual void Free();
};

#endif // LEVELONE_H
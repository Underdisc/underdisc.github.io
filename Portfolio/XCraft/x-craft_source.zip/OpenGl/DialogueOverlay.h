#pragma once
/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#ifndef DIALOGUE_OVERLAY_H
#define DIALOGUE_OVERLAY_H

#include "State.h"

class DialogueOverlay : public State
{
public:
  virtual void Allocate();
  virtual void Load();
  virtual bool Update();
};

#endif

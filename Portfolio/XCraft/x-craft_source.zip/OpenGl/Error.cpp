/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file Error.cpp
\author Connor Deakin
\par E-mail: connor.deakin\@digipen.edu
\par Project: Graphics
\date 30/09/2016
\brief
  Contains the implementation for the Error class. Look at the Error class in
  Error.h for more info.
*/
/*****************************************************************************/

#include <iostream>
#include <string>
#include <vector>

#include "Error.h"

/*****************************************************************************/
/*!
\brief
  This is the only constructor for an Error.

\param file
  The name of the file where an error was thrown.
\param function
  The name of the function where an error was thrown.
*/
/*****************************************************************************/
Error::Error(const char * file, const char * function)
: _file(file), _function(function) {}

/*****************************************************************************/
/*!
\brief
  Use this to add information to the Error's log. This can be called multiple
  times on a single Error. All of the log information is stored in a vector.
  See the operator<< to see how this is printed to console.

\param info
  The Error info to be added to the log.
*/
/*****************************************************************************/
void Error::Add(const char * info)
{
  _log.push_back(info);
}

/*****************************************************************************/
/*!
\brief
  Operator << overload for the Error class. When an error is printed, the file 
  name, function name, and log will all be printed.

\param os
  The outstream being printed to.
\param error
  The Error to be printed.

\return The outstream being printed to.
*/
/*****************************************************************************/
std::ostream & operator<<(std::ostream & os, const Error & error)
{
  //print header
  std::cout << "---- Error Log ----" << std::endl
            << "Runtime error in '" << error._file
            << "' at function '" << error._function << "'" << std::endl;
  //print log
  std::vector<std::string>::const_iterator info;
  for (info = error._log.begin(); info != error._log.end(); ++info)
    std::cout << *(info) << std::endl;
  std::cout << "--- End of Log ---" << std::endl;
  return os;
}
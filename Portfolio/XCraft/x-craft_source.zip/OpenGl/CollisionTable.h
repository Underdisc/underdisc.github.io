/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#pragma once
#include <map>
#include <string>
#include "Collider.h"

enum ResolutionType
{
  Ignore,
  Detect,
  Resolve
};

class CollisionTable
{
public:
  CollisionTable(Json::Value value);
  ResolutionType GetResolutionType(const std::string & first, const std::string & second);
  static void InitCollisionTables();
private:
  std::vector<std::vector<ResolutionType>> _collisionTable;
  std::map<std::string, size_t> _ids;
};

extern std::map<std::string, CollisionTable *> collisionTables;
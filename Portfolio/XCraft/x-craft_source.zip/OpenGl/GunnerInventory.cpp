/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#include "GunnerInventory.h"
#include "InputManager.h"
#include "Space.h"
#include "GameObjectManager.h"
#include "State.h"
#include "Sprite.h"
#include "BoatShoot.h"
#include "AudioEngine.h"
#include "SpaceManager.h"
#include "SoundEmitter.h"

#define PI 3.14159265359f

static glm::vec3 inventory_slot_positions[] = 
{ 
  glm::vec3(18, -8.8, 0.1), 
  glm::vec3(24.1, -8.8, 0.1),
  glm::vec3(24.1, -12.6, 0.1),
  glm::vec3(18, -12.6, 0.1)
};

static int ZachIndex2GabeIndex(int index)
{
  switch (index)
  {
  case 0:
    return 1;
  case 1:
    return 0;
  case 2:
    return 2;
  case 3:
    return 3;
  case 4:
    return 4;
  default:
    return 0;
  }
}

GunnerInventory::GunnerInventory() :
  Component("GunnerInventory"),
  _weaponChosen(FLAMETHROWER),
  _modularSlot(0),
  _bottomSelected(0),
  _gunIndex(std::vector<std::string>(5)),
  _gunObjs(std::vector<Object*>(5))
{
  for (int i = 0; i < 4; ++i)
  {
    _gunIndex[i] = "machineGun";
  }
}

void GunnerInventory::Update()
{
  spaceID levelOne = Global::SpaceManager::SpaceUnderneath(_HUD);
  _levelone = (**levelOne).GetCurrentState();
  player = (_levelone)->GetObjectManager()->FindObjectByName("Player");

  if (!_bottomSelected)
  {
    _highlight->GetTransform()->Translation() = glm::vec3(18 + _weaponChosen * 2.1, -5.5, 0.1);

    if (InputManager::Instance()->getDpadState(1, 2) || InputManager::Instance()->IsKeyPressed(SDL_SCANCODE_RIGHT))
    {
      _weaponChosen += 1;
      audEngine.PlayEvent("event:/UISFX/InventoryHover");
    }
    if (InputManager::Instance()->getDpadState(1, 8) || InputManager::Instance()->IsKeyPressed(SDL_SCANCODE_LEFT))
    {
      _weaponChosen -= 1;
      audEngine.PlayEvent("event:/UISFX/InventoryHover");
    }
  }
  else
  {
    if (InputManager::Instance()->getDpadState(1, 2) || InputManager::Instance()->IsKeyPressed(SDL_SCANCODE_RIGHT))
    {
      _modularSlot += 1;
      audEngine.PlayEvent("event:/UISFX/InventoryHover");
    }
    if (InputManager::Instance()->getDpadState(1, 8) || InputManager::Instance()->IsKeyPressed(SDL_SCANCODE_LEFT))
    {
      _modularSlot -= 1;
      audEngine.PlayEvent("event:/UISFX/InventoryHover");
    }


    if (_modularSlot < 0)
    {
      _modularSlot = 3;
    }
    if (_modularSlot > 3)
    {
      _modularSlot = 0;
    }

    _highlight->GetTransform()->Translation() = inventory_slot_positions[_modularSlot];
  }


  if (_weaponChosen < 0)
  {
    _weaponChosen = 2;
  }
  if (_weaponChosen == 3)
  {
    _weaponChosen = 0;
  }


  if (_bottomSelected)
  {

    if (InputManager::Instance()->getButtonState(1, SDL_CONTROLLER_BUTTON_A) || InputManager::Instance()->IsKeyPressed(SDL_SCANCODE_RETURN))
    {
      (**_HUD).GetCurrentState()->GetObjectManager()->DeleteObject(_gunObjs[_modularSlot]);
      if (_weaponChosen == 0)
      {
        _gunIndex[_modularSlot] = "machineGun";
        player->Find<BoatShoot>()->ChangeGun(ZachIndex2GabeIndex(_modularSlot), "machineGun", Gun(6.0f, 1, "Bullet"));
        _gunObjs[_modularSlot] = (**_HUD).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("machineGun", inventory_slot_positions[_modularSlot]);
        zeroGun = _gunObjs[_modularSlot]->GetTransform();
      }
      else if (_weaponChosen == 1)
      {
        _gunIndex[_modularSlot] = "flamethrower";
        player->Find<BoatShoot>()->ChangeGun(ZachIndex2GabeIndex(_modularSlot), "flamethrower", Gun(12.0f, 1, "flame"));
        _gunObjs[_modularSlot] = (**_HUD).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("flamethrower", inventory_slot_positions[_modularSlot]);
        zeroGun = _gunObjs[_modularSlot]->GetTransform();
      }
      else
      {
        _gunIndex[_modularSlot] = "railGun";
        player->Find<BoatShoot>()->ChangeGun(ZachIndex2GabeIndex(_modularSlot), "railGun", Gun(1.0f, 5, "energyBullet"));
        _gunObjs[_modularSlot] = (**_HUD).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("railGun", inventory_slot_positions[_modularSlot]);
        zeroGun = _gunObjs[_modularSlot]->GetTransform();
      }
      audEngine.PlayEvent(audEngine.GetMusicEvent("WeaponEquip"));
      _bottomSelected = 0;
    }
  }
  else
  {
    // IF PRESS ENTER
    if ((TheInputManager::Instance()->IsKeyPressed(SDL_SCANCODE_RETURN) || InputManager::Instance()->getButtonState(1, SDL_CONTROLLER_BUTTON_A)) && !_bottomSelected)
    {
      _bottomSelected = 1;
    }
  }

}

void GunnerInventory::SetHUD(spaceID hud)
{
  _HUD = hud;

  _highlight = (**_HUD).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("gunHighlight", glm::vec3(18, -5.5, 0));

  for (int i = 0; i < 5; i++)
  {
    _gunObjs[i] = (**_HUD).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition(_gunIndex[i], inventory_slot_positions[i]);
  }
}

Component * CreateGunnerInventoryComponent(Json::Value value)
{
  return new GunnerInventory();
}
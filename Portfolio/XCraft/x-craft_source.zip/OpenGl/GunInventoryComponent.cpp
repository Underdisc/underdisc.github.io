/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file GunInventoryComponent.cpp
\author Zach Dolph
\par E-mail: z.dolph\@digipen.edu
\par Project: Boat Game
\date 02/24/2017
\brief
*/
/*****************************************************************************/

#include "GunnerInventorySystem.h"
#include "Sprite.h"
#include "Object.h"
#include "State.h"
#include "Collider.h"
#include "AudioEngine.h"
#include "SpaceManager.h"
#include "State.h"
#include "InputManager.h"
#include "BoatShoot.h"
#include "SoundEmitter.h"

#define PI 3.14159265359f

GunnerInventoryComponent::GunnerInventoryComponent() :
  Component("GunnerInventory"),
  _buttonPositionTop(0),
  _buttonPositionBottom(0),
  _weaponChosen(0),
  _opened(0),
  _bottom(false),
  _gunIndex(std::vector<std::string>(5)),
  _gunObjs(std::vector<Object*>(5))
{

}

void GunnerInventoryComponent::OpenInventory()
{
  _gunnerInv = Global::SpaceManager::Add(GUNNER_INVENTORY, 30);
  Object * inventory = (**_gunnerInv).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("gunnerInventory", glm::vec3(15.0f, 1.5f, 0.0f));
  Object * cursor = (**_gunnerInv).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("inventoryArrow", glm::vec3(8.6f, 10.6f, 0.0f));
  menuSelecTran = cursor->GetTransform();
  _levelone = Global::SpaceManager::FindState(LEVEL_ONE);
  player = (_levelone)->GetObjectManager()->FindObjectByName("Player");
  if (!_opened)
  {
    for (int i = 0; i < 5; ++i)
    {
      _gunIndex[i] = "machineGun";
    }
  }

  _gunObjs[0] = (**_gunnerInv).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition(_gunIndex[0], glm::vec3(15.25f, -0.35f, 1.0f));
  zeroGun = _gunObjs[0]->GetTransform();
  zeroGun->SetRotation(-1.5f * PI);
  _gunObjs[1] = (**_gunnerInv).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition(_gunIndex[1], glm::vec3(11.5f, -2.5f, 1.0f));
  oneGun = _gunObjs[1]->GetTransform();
  oneGun->SetRotation(-1.5f * PI);
  _gunObjs[2] = (**_gunnerInv).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition(_gunIndex[2], glm::vec3(11.5f, -6.25f, 1.0f));
  twoGun = _gunObjs[2]->GetTransform();
  twoGun->SetRotation(-1.5f * PI);
  _gunObjs[3] = (**_gunnerInv).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition(_gunIndex[3], glm::vec3(19.15f, -2.5f, 1.0f));
  threeGun = _gunObjs[3]->GetTransform();
  threeGun->SetRotation(-1.5f * PI);
  _gunObjs[4] = (**_gunnerInv).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition(_gunIndex[4], glm::vec3(19.15f, -6.25f, 1.0f));
  fourGun = _gunObjs[4]->GetTransform();
  fourGun->SetRotation(-1.5f * PI);

  _opened = 1;
}

void GunnerInventoryComponent::CloseInventory()
{

}

void GunnerInventoryComponent::Init()
{

}

void GunnerInventoryComponent::Update()
{
  if (InputManager::Instance()->IsKeyPressed(SDL_SCANCODE_RSHIFT) && StateFactory::Active(GUNNER_INVENTORY))
  {
    CloseInventory();
  }


  if (_bottom)
  {
    menuSelecTran->Translation() = glm::vec3(15.25f, 2.0f, 1.0f);

    if (TheInputManager::Instance()->IsKeyPressed(SDL_SCANCODE_RIGHT))
    {
      _buttonPositionBottom += 1;
      audEngine.PlayEvent(audEngine.GetMusicEvent("InventoryHover"));
    }

    if (TheInputManager::Instance()->IsKeyPressed(SDL_SCANCODE_LEFT))
    {
      _buttonPositionBottom -= 1;
      audEngine.PlayEvent(audEngine.GetMusicEvent("InventoryHover"));
    }

    if (_buttonPositionBottom > 4)
      _buttonPositionBottom = 0;
    if (_buttonPositionBottom < 0)
      _buttonPositionBottom = 4;

    if (_buttonPositionBottom == 0)
    {
      menuSelecTran->Translation() = glm::vec3(15.25f, 2.0f, 1.0f);
    }
    else if (_buttonPositionBottom == 1)
    {
      menuSelecTran->Translation() = glm::vec3(19.15f, -0.5f, 1.0f);
    }
    else if (_buttonPositionBottom == 2)
    {
      menuSelecTran->Translation() = glm::vec3(19.15f, -4.25f, 1.0f);
    }
    else if (_buttonPositionBottom == 3)
    {
      menuSelecTran->Translation() = glm::vec3(11.35f, -4.25f, 1.0f);
    }
    else
    {
      menuSelecTran->Translation() = glm::vec3(11.35f, -0.5f, 1.0f);
    }


    if (TheInputManager::Instance()->IsKeyPressed(SDL_SCANCODE_RETURN))
    {
      switch (_buttonPositionBottom)
      {
      case 0:
        (**_gunnerInv).GetCurrentState()->GetObjectManager()->DeleteObject(_gunObjs[0]);
        if (_weaponChosen == 0)
        {
          _gunIndex[0] = "machineGun";
          player->Find<BoatShoot>()->ChangeGun(0, "machineGun", Gun(4.0f, 2, "Bullet"));
          _gunObjs[0] = (**_gunnerInv).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("machineGun", glm::vec3(15.25f, -0.35f, 1.0f));
          zeroGun = _gunObjs[0]->GetTransform();
          zeroGun->SetRotation(-1.5f * PI);
        }
        else if (_weaponChosen == 1)
        {
          _gunIndex[0] = "flamethrower";
          player->Find<BoatShoot>()->ChangeGun(0, "flamethrower", Gun(7.0f, 2, "Bullet"));
          _gunObjs[0] = (**_gunnerInv).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("flamethrower", glm::vec3(15.25f, -0.35f, 1.0f));
          zeroGun = _gunObjs[0]->GetTransform();
          zeroGun->SetRotation(-1.5f * PI);
        }
        else
        {
          _gunIndex[0] = "railGun";
          player->Find<BoatShoot>()->ChangeGun(0, "railGun", Gun(2.0f, 2, "Bullet"));
          _gunObjs[0] = (**_gunnerInv).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("railGun", glm::vec3(15.25f, -0.35f, 1.0f));
          zeroGun = _gunObjs[0]->GetTransform();
          zeroGun->SetRotation(-1.5f * PI);
        }
        audEngine.PlayEvent(audEngine.GetMusicEvent("WeaponEquip"));
        _buttonPositionTop = 3;
        _bottom = false;
        break;
      case 1:
        (**_gunnerInv).GetCurrentState()->GetObjectManager()->DeleteObject(_gunObjs[3]);
        if (_weaponChosen == 0)
        {
          _gunIndex[3] = "machineGun";
          player->Find<BoatShoot>()->ChangeGun(3, "machineGun", Gun(4.0f, 2, "Bullet"));
          _gunObjs[3] = (**_gunnerInv).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("machineGun", glm::vec3(19.15f, -2.5f, 1.0f));
          oneGun = _gunObjs[3]->GetTransform();
          oneGun->SetRotation(-1.5f * PI);
        }
        else if (_weaponChosen == 1)
        {
          _gunIndex[3] = "flamethrower";
          player->Find<BoatShoot>()->ChangeGun(3, "flamethrower", Gun(7.0f, 2, "Bullet"));
          _gunObjs[3] = (**_gunnerInv).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("flamethrower", glm::vec3(19.15f, -2.5f, 1.0f));
          oneGun = _gunObjs[3]->GetTransform();
          oneGun->SetRotation(-1.5f * PI);
        }
        else
        {
          _gunIndex[3] = "railGun";
          player->Find<BoatShoot>()->ChangeGun(3, "railGun", Gun(2.0f, 2, "Bullet"));
          _gunObjs[3] = (**_gunnerInv).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("railGun", glm::vec3(19.15f, -2.5f, 1.0f));
          oneGun = _gunObjs[3]->GetTransform();
          oneGun->SetRotation(-1.5f * PI);
        }
        audEngine.PlayEvent(audEngine.GetMusicEvent("WeaponEquip"));
        _buttonPositionTop = 3;
        _bottom = false;
        break;
      case 2:
        (**_gunnerInv).GetCurrentState()->GetObjectManager()->DeleteObject(_gunObjs[4]);
        if (_weaponChosen == 0)
        {
          _gunIndex[4] = "machineGun";
          player->Find<BoatShoot>()->ChangeGun(4, "machineGun", Gun(4.0f, 2, "Bullet"));
          _gunObjs[4] = (**_gunnerInv).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("machineGun", glm::vec3(19.15f, -6.25f, 1.0f));
          twoGun = _gunObjs[4]->GetTransform();
          twoGun->SetRotation(-1.5f * PI);
        }
        else if (_weaponChosen == 1)
        {
          _gunIndex[4] = "flamethrower";
          player->Find<BoatShoot>()->ChangeGun(4, "flamethrower", Gun(7.0f, 2, "Bullet"));
          _gunObjs[4] = (**_gunnerInv).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("flamethrower", glm::vec3(19.15f, -6.25f, 1.0f));
          twoGun = _gunObjs[4]->GetTransform();
          twoGun->SetRotation(-1.5f * PI);
        }
        else
        {
          _gunIndex[4] = "railGun";
          player->Find<BoatShoot>()->ChangeGun(4, "railGun", Gun(2.0f, 2, "Bullet"));
          _gunObjs[4] = (**_gunnerInv).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("railGun", glm::vec3(19.15f, -6.25f, 1.0f));
          twoGun = _gunObjs[4]->GetTransform();
          twoGun->SetRotation(-1.5f * PI);
        }
        audEngine.PlayEvent(audEngine.GetMusicEvent("WeaponEquip"));
        _buttonPositionTop = 3;
        _bottom = false;
        break;
      case 3:
        (**_gunnerInv).GetCurrentState()->GetObjectManager()->DeleteObject(_gunObjs[2]);
        if (_weaponChosen == 0)
        {
          _gunIndex[2] = "machineGun";
          player->Find<BoatShoot>()->ChangeGun(2, "machineGun", Gun(4.0f, 2, "Bullet"));
          _gunObjs[2] = (**_gunnerInv).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("machineGun", glm::vec3(11.5f, -6.25f, 1.0f));
          threeGun = _gunObjs[2]->GetTransform();
          threeGun->SetRotation(-1.5f * PI);

        }
        else if (_weaponChosen == 1)
        {
          _gunIndex[2] = "flamethrower";
          player->Find<BoatShoot>()->ChangeGun(2, "flamethrower", Gun(7.0f, 2, "Bullet"));
          _gunObjs[2] = (**_gunnerInv).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("flamethrower", glm::vec3(11.5f, -6.25f, 1.0f));
          threeGun = _gunObjs[2]->GetTransform();
          threeGun->SetRotation(-1.5f * PI);
        }
        else
        {
          _gunIndex[2] = "railGun";
          player->Find<BoatShoot>()->ChangeGun(2, "railGun", Gun(2.0f, 2, "Bullet"));
          _gunObjs[2] = (**_gunnerInv).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("railGun", glm::vec3(11.5f, -6.25f, 1.0f));
          threeGun = _gunObjs[2]->GetTransform();
          threeGun->SetRotation(-1.5f * PI);
        }
        audEngine.PlayEvent(audEngine.GetMusicEvent("WeaponEquip"));
        _buttonPositionTop = 3;
        _bottom = false;
        break;
      case 4:
        (**_gunnerInv).GetCurrentState()->GetObjectManager()->DeleteObject(_gunObjs[1]);
        if (_weaponChosen == 0)
        {
          _gunIndex[1] = "machineGun";
          player->Find<BoatShoot>()->ChangeGun(1, "machineGun", Gun(4.0f, 2, "Bullet"));
          _gunObjs[1] = (**_gunnerInv).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("machineGun", glm::vec3(11.5f, -2.5f, 1.0f));
          fourGun = _gunObjs[1]->GetTransform();
          fourGun->SetRotation(-1.5f * PI);
        }
        else if (_weaponChosen == 1)
        {
          _gunIndex[1] = "flamethrower";
          player->Find<BoatShoot>()->ChangeGun(1, "flamethrower", Gun(7.0f, 2, "Bullet"));
          _gunObjs[1] = (**_gunnerInv).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("flamethrower", glm::vec3(11.5f, -2.5f, 1.0f));
          fourGun = _gunObjs[1]->GetTransform();
          fourGun->SetRotation(-1.5f * PI);
        }
        else
        {
          _gunIndex[1] = "railGun";
          player->Find<BoatShoot>()->ChangeGun(1, "railGun", Gun(2.0f, 2, "Bullet"));
          _gunObjs[1] = (**_gunnerInv).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("railGun", glm::vec3(11.5f, -2.5f, 1.0f));
          fourGun = _gunObjs[1]->GetTransform();
          fourGun->SetRotation(-1.5f * PI);
        }
        audEngine.PlayEvent(audEngine.GetMusicEvent("WeaponEquip"));
        _buttonPositionTop = 3;
        _bottom = false;
        break;
      default:
        break;
      }
    }
  }
  else
  {
    if (TheInputManager::Instance()->IsKeyPressed(SDL_SCANCODE_RIGHT))
    {
      _buttonPositionTop += 1;
      _weaponChosen += 1;
      audEngine.PlayEvent(audEngine.GetMusicEvent("InventoryHover"));
    }

    if (TheInputManager::Instance()->IsKeyPressed(SDL_SCANCODE_LEFT))
    {
      _buttonPositionTop -= 1;
      _weaponChosen -= 1;
      audEngine.PlayEvent(audEngine.GetMusicEvent("InventoryHover"));
    }


    if (_buttonPositionTop > 2)
    {
      _buttonPositionTop = 0;
      _weaponChosen = 0;
    }
    if (_buttonPositionTop < 0)
    {
      _buttonPositionTop = 2;
      _weaponChosen = 2;
    }

    menuSelecTran->Translation() = glm::vec3(8.6f + _buttonPositionTop * 2.75f, 10.6f, 1.0f);

    // IF PRESS ENTER
    if (TheInputManager::Instance()->IsKeyPressed(SDL_SCANCODE_RETURN) && !_bottom)
    {
      _bottom = true;
    }
  }
}

void GunnerInventoryComponent::SetSpace(spaceID gunInv)
{
  _gunnerInv = gunInv;
}

spaceID GunnerInventoryComponent::GetSpace()
{
  return _gunnerInv;
}

Component * CreateGunnerInventorySystem(Json::Value value)
{
  return new GunnerInventoryComponent();
}
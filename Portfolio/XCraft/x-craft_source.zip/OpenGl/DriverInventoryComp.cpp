/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file DriverInventoryComp.cpp
\author Zach Dolph
\par E-mail: z.dolph\@digipen.edu
\par Project: Boat Game
\date 02/24/2017
\brief
*/
/*****************************************************************************/

#include "DriverInventorySystem.h"
#include "Time.h"
#include "Sprite.h"
#include "Object.h"
#include "State.h"
#include "Collider.h"
#include "AudioEngine.h"
#include "SpaceManager.h"
#include "State.h"
#include "InputManager.h"

#define PI 3.14159265359f

DriverInventoryComp::DriverInventoryComp() :
  Component("DriverInventory"),
  _lightone(0),
  _lighttwo(0),
  _lightthree(0),
  _lightfour(0),
  _buttonPosition(0),
  _lightsVec(std::vector<Object*>(11)),
  _pipGlassVec(std::vector<Object*>(30))
{

}

void DriverInventoryComp::Init()
{

}

void DriverInventoryComp::OpenInventory()
{
  _driverInv = Global::SpaceManager::Add(DRIVER_INVENTORY, 30);
  Object * inventory = (**_driverInv).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("driverInventory", glm::vec3(-9.5f, 1.0f, 0.0f));
  Object * cursor = (**_driverInv).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("menuArrow", glm::vec3(-20.4f, 4.3f, 0.0f));
  menuSelecTran = cursor->GetTransform();
  menuSelecTran->SetRotation(1.5f * PI);
}

void DriverInventoryComp::CloseInventory()
{
  Global::SpaceManager::Remove(_driverInv);
}

void DriverInventoryComp::Update()
{
  if (!StateFactory::Active(DRIVER_INVENTORY) &&
    TheInputManager::Instance()->IsKeyPressed(SDL_SCANCODE_TAB))
  {
    OpenInventory();
  }

  if (InputManager::Instance()->IsKeyPressed(SDL_SCANCODE_TAB) && 
    StateFactory::Active(DRIVER_INVENTORY))
  {
    CloseInventory();
  }

  if (TheInputManager::Instance()->IsKeyPressed(SDL_SCANCODE_A))
  {
    _buttonPosition -= 1;
    audEngine.PlayEvent(audEngine.GetMusicEvent("InventoryHover"));
  }

  if (TheInputManager::Instance()->IsKeyPressed(SDL_SCANCODE_D))
  {
    _buttonPosition += 1;
    audEngine.PlayEvent(audEngine.GetMusicEvent("InventoryHover"));
  }

  if (_buttonPosition > 3)
    _buttonPosition = 0;
  if (_buttonPosition < 0)
    _buttonPosition = 3;


  if (_lightone > 3)
    _lightone = 3;
  if (_lightone < 0)
    _lightone = 0;

  if (_lighttwo > 3)
    _lighttwo = 3;
  if (_lighttwo < 0)
    _lighttwo = 0;

  if (_lightthree > 3)
    _lightthree = 3;
  if (_lightthree < 0)
    _lightthree = 0;

  if (_lightfour > 3)
    _lightfour = 3;
  if (_lightfour < 0)
    _lightfour = 0;


  menuSelecTran->Translation() = glm::vec3(-20.4f + _buttonPosition * 4.35f, 4.0f, 1.0f);

  // IF PRESS ENTER
  if (TheInputManager::Instance()->IsKeyPressed(SDL_SCANCODE_W))
  {
    switch (_buttonPosition)
    {
    case 0:
      audEngine.PlayEvent(audEngine.GetMusicEvent("MenuStart"));
      if (_lightone != 3)
        _lightsVec[_lightone] = (**_driverInv).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("greenLight", glm::vec3(-21.4f + _buttonPosition * 4.05f + (_lightone), 9.0f, 0.0f));
      if (_lightone < 3)
        _lightone++;
      break;
    case 1:
      audEngine.PlayEvent(audEngine.GetMusicEvent("MenuStart"));
      if (_lighttwo != 3)
        _lightsVec[_lighttwo + 3] = (**_driverInv).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("greenLight", glm::vec3(-21.4f + _buttonPosition * 4.05f + (_lighttwo), 9.0f, 0.0f));
      if (_lighttwo < 3)
        _lighttwo++;
      break;
    case 2:
      audEngine.PlayEvent(audEngine.GetMusicEvent("MenuStart"));
      if (_lightthree != 3)
        _lightsVec[_lightthree + 6] = (**_driverInv).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("greenLight", glm::vec3(-21.4f + _buttonPosition * 4.05f + (_lightthree), 9.0f, 0.0f));
      if (_lightthree < 3)
        _lightthree++;
      break;
    case 3:
      audEngine.PlayEvent(audEngine.GetMusicEvent("MenuStart"));
      if (_lightfour != 3)
        _lightsVec[_lightfour + 9] = (**_driverInv).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("greenLight", glm::vec3(-21.4f + _buttonPosition * 4.05f + (_lightfour), 9.0f, 0.0f));
      if (_lightfour < 3)
        _lightfour++;
      break;
    default:
      break;
    }
  }


  if (TheInputManager::Instance()->IsKeyPressed(SDL_SCANCODE_S))
  {
    switch (_buttonPosition)
    {
    case 0:
      audEngine.PlayEvent("event:/UISFX/MenuNegativeFeedback");
      if (_lightone != 0)
        (**_driverInv).GetCurrentState()->GetObjectManager()->DeleteObject(_lightsVec[_lightone - 1]);
      else
        (**_driverInv).GetCurrentState()->GetObjectManager()->DeleteObject(_lightsVec[_lightone]);
      if (_lightone > 0)
        _lightone--;
      //
      break;
    case 1:
      audEngine.PlayEvent("event:/UISFX/MenuNegativeFeedback");
      if (_lighttwo != 0)
        (**_driverInv).GetCurrentState()->GetObjectManager()->DeleteObject(_lightsVec[_lighttwo + 2]);
      if (_lighttwo > 0)
        _lighttwo--;
      //
      break;
    case 2:
      audEngine.PlayEvent("event:/UISFX/MenuNegativeFeedback");
      if (_lightthree != 0)
        (**_driverInv).GetCurrentState()->GetObjectManager()->DeleteObject(_lightsVec[_lightthree + 5]);
      if (_lightthree > 0)
        _lightthree--;
      //
      break;
    case 3:
      audEngine.PlayEvent("event:/UISFX/MenuNegativeFeedback");
      if (_lightfour != 0)
        (**_driverInv).GetCurrentState()->GetObjectManager()->DeleteObject(_lightsVec[_lightfour + 8]);
      if (_lightfour > 0)
        _lightfour--;
      //
      break;
    default:
      break;
    }
  }
}

void DriverInventoryComp::SetSpace(spaceID driverInv)
{
  _driverInv = driverInv;
}

spaceID DriverInventoryComp::GetSpace()
{
  return _driverInv;
}

Component * CreateDriverInventorySystem(Json::Value value)
{
  return new DriverInventoryComp();
}


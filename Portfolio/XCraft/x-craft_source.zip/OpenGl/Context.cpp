/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file Context.cpp
\author Connor Deakin
\par E-mail: connor.deakin\@digipen.edu
\par Project: Mecha
\date 30/09/2016
\brief
  Contains the implementation of the static Context class. Look at the 
  documentation of the Context class for more info on this code.
*/
/*****************************************************************************/

#include <GL\glew.h>
#include <SDL\SDL.h>
#include <SDL\SDL_opengl.h>

#include "OpenGLError.h"

#include "Context.h"

// Undefine the main define by SDL
#undef main

// static initializations
bool Context::_created = false;
int Context::_windowHeight = 0;
int Context::_windowWidth = 0;
bool Context::_fullscreen = false;
float Context::_aspectRatio = 1.0f;
bool Context::_close = true;
SDL_Window * Context::_window = nullptr;
SDL_GLContext Context::_context = nullptr;
// These will get set on successfull context creation

//! Width for 1280 x 720
#define X720 1280
//! Height for 1280 x 720
#define Y720 720

/*****************************************************************************/
/*!
\brief
  Constructor for the Context class. If all of the parameters are not given,
  the following the defaults will be applied. If the given width and height
  are zero, the Context will instantly fullscreen.

\par
  Defaults
   - name: "Context"
   - width:  600
   - height: 600
   - xposition: 0
   - yposition: 0

\param name
  The name that will be seen in the top left of the window.
\param width
  The width of the window.
\param height
  The height of the window.
\param xposition
  The X position of the top left corner of the window.
\param yposition
  The Y position of the top left cornter of the window.
*/
/*****************************************************************************/
void Context::Create(const char * name, int width, int height, 
                 int xposition, int yposition)
{
  // throwing error if context already exists
  if (_created)
  {
    Error error("Context.cpp", "Init");
    error.Add("A Context already exists.");
    error.Add("Only one context can exist at a time.");
    throw(error);
  }
  InitSDL();
  // creating window
  // not fullscreen
  if (width > 0 || height > 0) {
    _window = SDL_CreateWindow(name, xposition, yposition, width, height,
      SDL_WINDOW_OPENGL | SDL_WINDOW_RESIZABLE | SDL_WINDOW_INPUT_FOCUS |
      SDL_WINDOW_MOUSE_FOCUS);
    _fullscreen = false;
  }
  // fullscreen
  else {
    _window = SDL_CreateWindow(name, xposition, yposition, X720, Y720,
      SDL_WINDOW_OPENGL | SDL_WINDOW_RESIZABLE | SDL_WINDOW_INPUT_FOCUS |
      SDL_WINDOW_MOUSE_FOCUS | SDL_WINDOW_FULLSCREEN_DESKTOP);
    _fullscreen = true;
  }
  // making sure windo was created
  if (!_window)
  {
    SDL_Quit();
    Error error("Context.cpp", "CreateContext");
    error.Add("SDL window creation failed.");
    throw(error);
  }
  // creating context and Adjusting Viewport
  _context = SDL_GL_CreateContext(_window);
  AdjustViewport();
  // Initializing glew with modern OpenGL
  glewExperimental = GL_TRUE;
  if (glewInit() != GLEW_OK)
  {
    SDL_Quit();
    Error error("Context.cpp", "Init");
    error.Add("glew initialization failed.");
    throw(error);
  }
  _created = true;
  _close = false;
  // Clearing error log due to false positive.
  glGetError();
}

/*****************************************************************************/
/*!
\brief
  Destructor for the Context class. This will clean up all the Context
  resources.
*/
/*****************************************************************************/
void Context::Purge()
{
  SDL_GL_DeleteContext(_context);
  SDL_DestroyWindow(_window);
  SDL_Quit();
  _created = false;
}

/*****************************************************************************/
/*!
\brief
  Checks for any SDL Events that exits within SDL's event queue and acts
  according to the type of the event.
*/
/*****************************************************************************/
void Context::CheckEvents()
{
  SDL_Event event;
  // reading all events in queue
  while (SDL_PollEvent(&event))
  {
    switch (event.type)
    {
      case SDL_WINDOWEVENT:
        OnWindowEvent(event);
        break;
    }
  }
}

/*****************************************************************************/
/*!
\brief
  Switches between a fullscreen and a windowed state.
*/
/*****************************************************************************/
void Context::ToggleFullscreen()
{
  if (_fullscreen)
    SDL_SetWindowFullscreen(_window, 0);
  else
    SDL_SetWindowFullscreen(_window, SDL_WINDOW_FULLSCREEN_DESKTOP);
  AdjustViewport();
  _fullscreen = !_fullscreen;
}

/*****************************************************************************/
/*!
\brief
  This will update the OpenGL SDL Context. This should only be called at the end
  of frame generation. This means all drawing code must happen before this is
  called.
*/
/*****************************************************************************/
void Context::Swap()
{
  SDL_GL_SwapWindow(_window);
}

/*****************************************************************************/
/*!
\brief
  Clears eveything that is currently on the back buffer with the color value
  set with the ClearColor() function so a new frame can be rendered.

\param red
  The red color value.
\param green
  The green color value.
\param blue
  The blue color value.
*/
/*****************************************************************************/
void Context::Clear(float red, float green, float blue)
{
  // setting the color and clearing
  glClearColor(red, green, blue, 1.0f);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

/*****************************************************************************/
/*!
\brief
  Used to show or hide the cursor when it is hovering over the Context.

\param hide
  If true, the cursor will be hidden when hovering over the context. If false,
  the cursor will always be visible.
*/
/*****************************************************************************/
void Context::HideCursor(bool hide)
{
  if(hide)
    SDL_ShowCursor(SDL_DISABLE);
  else
    SDL_ShowCursor(SDL_ENABLE);
}

/*****************************************************************************/
/*!
\brief
  Updates the Context to match the current size of the window. If the window
  changes in size, the opengl context will continue to draw in the size of the
  original window. To handle this, this function must be called so opengl knows
  the size of the new window.
*/
/*****************************************************************************/
void Context::AdjustViewport()
{
  int width, height;
  SDL_GL_GetDrawableSize(_window, &width, &height);
  _aspectRatio = (float)width / (float)height;
  _windowWidth = width;
  _windowHeight = height;
  glViewport(0, 0, width, height);
}

/*****************************************************************************/
/*!
\brief
  Used to get the height of the window in SDL screen units.

\return The height of the window.
*/
/*****************************************************************************/
int Context::Height()
{
  return _windowHeight;
}

/*****************************************************************************/
/*!
\brief
  Returns the width of the window in SDL screen units.

\return The width of the window.
*/
/*****************************************************************************/
int Context::Width()
{
  return _windowWidth;
}

/*****************************************************************************/
/*!
\brief
  Use this to get the current aspect ratio of the Context. The aspect ratio is
  the height of the window divided by the width. This applied on the NDC
  transformation for proper aspect ratios.

\return The Context's current aspect ratio.
*/
/*****************************************************************************/
float Context::AspectRatio()
{
  return _aspectRatio;
}

/*****************************************************************************/
/*!
\brief
  Get the current Context status. If it is to remain open, this will return
  true. Otherwise, this will return false.

\return The current status of the Context.
*/
/*****************************************************************************/
bool Context::KeepOpen()
{
  if(_close)
    return false;
  return true;
}

/*****************************************************************************/
/*!
\brief
  Calling this signifies that the context should close. It will not actually
  close when this function called. The close bool in the class will simply be
  set to true. It is your job to check this value using the KeepOpen function.
  This function and KeepOpen are used to maintain a game loop.
*/
/*****************************************************************************/
void Context::Close()
{
  _close = true;
}


/*****************************************************************************/
/*!
\brief
  Translates SDL pixel coordinates into aspect coordinates (NDC coordinates
  with a scale to account of aspect ratio).

\param pixel
  The pixel coordinate that will be changed to an aspect coordinate.
*/
/*****************************************************************************/
void Context::ScreenToAspect(glm::vec2 & pixel)
{
  pixel.x = 2.0f * _aspectRatio * (pixel.x / _windowWidth - 0.5f);
  pixel.y = - 2.0f * (pixel.y / _windowHeight - 0.5f);
}

/*****************************************************************************/
/*!
\brief
  This is used to initialize all the necessary SDL parameters before creating
  a window and OpenGL context.
*/
/*****************************************************************************/
void Context::InitSDL()
{
   SDL_Init(SDL_INIT_VIDEO);
   SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK,
                       SDL_GL_CONTEXT_PROFILE_CORE);
   //version 3.3
   SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
   SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 3);
}

/*****************************************************************************/
/*!
\brief
  This will be called from CheckEvents() when SDL sends a window event. This
  includes evetns such as maximizing, minimizing, resizing, closing, etc.

\param event
  The window event that was pulled off the event queue from SDL_PollEvents.
*/
/*****************************************************************************/
void Context::OnWindowEvent(const SDL_Event & event)
{
  switch (event.window.event)
  {
    case SDL_WINDOWEVENT_RESIZED:
      AdjustViewport();
      break;
    case SDL_WINDOWEVENT_CLOSE:
      Close();
      break;
  }
}



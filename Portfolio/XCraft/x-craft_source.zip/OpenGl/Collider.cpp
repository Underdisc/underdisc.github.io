/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file Collider.cpp
\author Gabe Miller
\par E-mail: g.miller\@digipen.edu
\par Project: Boat Game
\date 10/6/2016 5:09:04 PM
\brief
	This is the implementation file for the collider base class.
\par
Functions Include:
	-Constructor
	-Update
	-StaticCircleToStaticCircle
*/
/*****************************************************************************/

#include "Collider.h"
#include "Vec2Math.h" // Distance Squared
#include "CircleCollider.h"
#include "Object.h" // Find()
#include "GameObjectManager.h" // Object Manager
#include "Transform.h"
#include <iostream> // debug
#include "Physics.h"
#include "CollisionManager.h"
#include "BoxCollider.h"
#include "AudioEngine.h"
#include "CollisionTable.h"

#include "TileMap.h"

/*****************************************************************************/
/*!
\brief
	This is the constructor for colliders. It sets the type of collider,
	and intializes some values to default values.

\param colliderType
	This tells the collider which type of collision to use.
*/
/*****************************************************************************/
Collider::Collider(ColliderType colliderType, std::string collisionGroup) : 
	Component("Collider"), _colliderType(colliderType), 
  _collided(false), _collisionGroup(collisionGroup)
{
}

void Collider::Init()
{
  Owner().ObjectManager()->GetCollisionManager()->AddCollider(this);
  std::cout << "Adding collider to collision manager: " << Owner().Type() << std::endl;
}

Collider::~Collider()
{
  if (&Owner() != nullptr)
    Owner().ObjectManager()->GetCollisionManager()->RemoveCollider(this);
}

/*****************************************************************************/
/*!
\brief
	This is the update function for colliders. It loops through all game objects
	and then calls 
*/
/*****************************************************************************/
void Collider::Update()
{
}


void Collider::ResolveCollision(Object * thisObject, Object * otherObject)
{
  Physics * physics = thisObject->Find<Physics>();
  Physics * otherPhysics = otherObject->Find<Physics>();

  // Get the transforms of both objects.
  Transform * transform = thisObject->GetTransform();
  Transform * otherTransform = otherObject->GetTransform();


  Collider * collider = thisObject->Find<Collider>();
  Collider * otherCollider = otherObject->Find<Collider>();
  if (physics->GetMotionType() == Physics::Dynamic)
  {
    CollisionInfo lastCollision = collider->GetCollisionList().back();
    if (otherPhysics->GetMotionType() == Physics::Dynamic)
    {
      glm::vec2 velocity = physics->GetVelocity();
      glm::vec2 otherVelocity = otherPhysics->GetVelocity();
      glm::vec2 normal = -lastCollision.GetNormal();
      float lengthV = glm::length(velocity);
      float lengthN = glm::length(normal);
      float lengthO = glm::length(otherVelocity);
      float vScale;
      float oScale;
      if (lengthN != 0)
        normal = normal / lengthN;
      // Explanation: The dot product of the normalized velocity and normal vectors
      // is a value from 1 to 0 where 1 is aligned and 0 is perpendicular.
      // If the dot product is lower, then this collision is a glancing blow.
      // If the dot product is higher, this is a dead on hit.
      if (lengthV == 0)
        vScale = 0;
      else
        vScale = glm::abs(glm::dot(velocity / lengthV, -normal));
      if (lengthO == 0)
        oScale = 0;
      else
        oScale = glm::abs(glm::dot(otherVelocity / lengthO, normal));

      // Explanation: v and o influence are vectors with the kinetic energy of
      // each object in the direction of the collision normal.
      glm::vec2 vInfluence = -normal * lengthV * physics->GetMass();
      glm::vec2 oInfluence = normal * lengthO * otherPhysics->GetMass();

      // Explanation: The velocity of the objects after the collision will transfer into each other
      // if the objects hit at a glancing blow, then they will conserve more of their own velocity.
      // if the objects hit dead on, they will take on more of the other object's velocity.
      physics->SetVelocity((oScale * oInfluence + (1 - oScale) * velocity) / physics->GetMass());
      otherPhysics->SetVelocity((vScale * vInfluence + (1 - vScale) * otherVelocity) / otherPhysics->GetMass());
      // TODO: Restitution
    }
    else
    {
      glm::vec2 velocity = physics->GetVelocity();
      // TODO: Reflection vector stuff
      physics->SetVelocity(glm::reflect(velocity, lastCollision.GetNormal()));
    }
  }
}

/*****************************************************************************/
/*!
\brief
	Checks for collision between two static circles.

\param thisObject
	The first object with a circle collider

\param otherObject
	The second object with a circle collider

\return
	Returns true if a collision happened.
*/
/*****************************************************************************/
bool Collider::StaticCircleToStaticCircle(CircleCollider * collider, CircleCollider * otherCollider)
{
  Object * thisObject = &collider->Owner();
  Object * otherObject = &otherCollider->Owner();
	// Get the transforms of both objects.

  Transform * transform = thisObject->GetTransform();
  Transform * otherTransform = otherObject->GetTransform();
	// The distance at which the circles will have collided.
	float collision_distance = collider->GetRadius() + otherCollider->GetRadius();
  float distance_between = Math::DistanceSquared(otherTransform->GetTranslation(), transform->GetTranslation());
  // Check the distance and compare to radius
  if (distance_between < collision_distance * collision_distance)
  {
    float length = glm::sqrt(distance_between);
    float penetration = collider->GetRadius() + otherCollider->GetRadius() - length;
    glm::vec2 normal;
    if (length == 0)
      normal = glm::vec2(1, 0);
    else
    {
      normal = otherTransform->GetTranslation() - transform->GetTranslation();
      normal /= length;
    }
    glm::vec2 contactPoint = glm::vec2(otherTransform->GetTranslation().x, otherTransform->GetTranslation().y)
      + (normal * otherCollider->GetRadius());
    collider->_collisionData.push_back(CollisionInfo(otherObject, normal, contactPoint, penetration));
    otherCollider->_collisionData.push_back(CollisionInfo(thisObject, -normal, contactPoint, penetration));
    
    if ((*collisionTables.begin()).second->GetResolutionType(
      collider->GetCollisionGroup(),
      otherCollider->GetCollisionGroup()) == ResolutionType::Resolve)
    {
      Physics * physics = thisObject->Find<Physics>();
      Physics * otherPhysics = otherObject->Find<Physics>();
      if (physics->GetMotionType() == Physics::Dynamic)
      {
        CollisionInfo lastCollision = collider->GetCollisionList().back();
        if (otherPhysics->GetMotionType() == Physics::Dynamic)
        {
          // Push each object out by half the penentration distance in the normal direction.
          transform->Translation() = transform->GetTranslation() +
            glm::vec3(-normal *
              (penetration / 2), 0);

          otherTransform->Translation() = otherTransform->GetTranslation() +
            glm::vec3(normal *
              (penetration / 2), 0);
        }
        else
        {
          transform->Translation() = transform->GetTranslation() +
            glm::vec3(-normal *
              (penetration), 0);
        }
      }
    }
    
    return true;
  }
	return false;
}

bool Collider::TileCollision(TileMap * tileMap)
{
  int size;
  auto points = GeneratePoints(&size);
  glm::vec3 pos = Owner().GetTransform()->GetTranslation();
  for (int i = 0; i < size; i++)
  {
    glm::vec2 thisPos = points[i] + glm::vec2(pos.x, pos.y);
    int tileValue = tileMap->TileValueAtPosition(thisPos);
    if (tileValue != 0)
    {
      Physics * physics = Owner().Find<Physics>();
      glm::vec2 otherPos = tileMap->TileCenterAtPosition(thisPos);
      float xDist = thisPos.x - otherPos.x;
      float yDist = thisPos.y - otherPos.y;
      float pushDist;
      glm::vec2 normal;
      // Push out along x
      if (glm::abs(xDist) > glm::abs(yDist) && !tileMap->TileValueAtPosition(thisPos + glm::vec2(glm::sign(xDist), 0)))
      {
        pushDist = tileMap->GetWidth() / 2 - glm::abs(xDist);
        pushDist *= glm::sign(xDist);
        normal = glm::vec2(glm::sign(xDist), 0);
        if (physics->GetMotionType() == Physics::Dynamic)
        {
          Owner().GetTransform()->Translation() = glm::vec3(pos.x + pushDist, pos.y, pos.z);
          physics->SetVelocity(glm::vec2(-Owner().Find<Physics>()->GetVelocity().x, Owner().Find<Physics>()->GetVelocity().y));
        }
      }
      else if(!tileMap->TileValueAtPosition(thisPos + glm::vec2(0, glm::sign(yDist))))
      {
        pushDist = tileMap->GetWidth() / 2 - glm::abs(yDist);
        pushDist *= glm::sign(yDist);
        normal = glm::vec2(0, glm::sign(yDist));
        if (physics->GetMotionType() == Physics::Dynamic)
        {
          Owner().GetTransform()->Translation() = glm::vec3(pos.x, pos.y + pushDist, pos.z);
          physics->SetVelocity(glm::vec2(Owner().Find<Physics>()->GetVelocity().x, -Owner().Find<Physics>()->GetVelocity().y));
        }
      }
      else
      {
        pushDist = tileMap->GetWidth() / 2 - glm::abs(xDist);
        pushDist *= glm::sign(xDist);
        normal = glm::vec2(glm::sign(xDist), 0);
        if (physics->GetMotionType() == Physics::Dynamic)
        {
          Owner().GetTransform()->Translation() = glm::vec3(pos.x + pushDist, pos.y, pos.z);
          physics->SetVelocity(glm::vec2(-Owner().Find<Physics>()->GetVelocity().x, Owner().Find<Physics>()->GetVelocity().y));
        }
      }
      _collided = true;
      _collisionData.push_back(CollisionInfo(tileMap->GetTileData()->tile_archetype, -normal, points[i], pushDist));
      delete [] points;
      return true;
    }
  }
  delete[] points;
  return false;
}

bool Collider::StaticBoxToStaticBox(BoxCollider *collider, BoxCollider *otherCollider)
{
  Object * thisObject = &collider->Owner();
  Object * otherObject = &otherCollider->Owner();

  Transform * transform = thisObject->GetTransform();
  Transform * otherTransform = otherObject->GetTransform();

  float x_collide = collider->GetWidth() / 2 + otherCollider->GetWidth() / 2;
  float y_collide = collider->GetHeight() / 2 + otherCollider->GetHeight() / 2;
  glm::vec3 translation = transform->GetTranslation();
  glm::vec3 other_translation = otherTransform->GetTranslation();
  float x_dist = glm::abs(translation.x - other_translation.x);
  float y_dist = glm::abs(translation.y - other_translation.y);
  if (x_dist < x_collide && y_dist < y_collide)
  {
    glm::vec2 normal;
    normal = translation - other_translation;
    float length = x_dist * x_dist + y_dist * y_dist;
    float pen_x = x_collide - x_dist;
    float pen_y = y_collide - y_dist;
    float penetration = glm::sqrt(pen_x * pen_x + pen_y + pen_y);

    if (length != 0)
      normal /= glm::sqrt(length);
    else
      normal = glm::vec2(1, 0);
    glm::vec2 contactPoint = glm::vec2(translation.x, translation.y) + normal * penetration;
    collider->_collisionData.push_back(CollisionInfo(otherObject, normal, contactPoint, penetration));
    otherCollider->_collisionData.push_back(CollisionInfo(thisObject, -normal, contactPoint, penetration));

    if ((*collisionTables.begin()).second->GetResolutionType(
      collider->GetCollisionGroup(),
      otherCollider->GetCollisionGroup()) == ResolutionType::Resolve)
    {
      // Recalculating the normal and penetration for pushing the objects out from each other.
      Physics * physics = thisObject->Find<Physics>();
      Physics * otherPhysics = otherObject->Find<Physics>();
      if (pen_x > pen_y)
      {
        if(length != 0)
          normal = glm::vec2(0, glm::sign(translation.y - other_translation.y));
        penetration = pen_y;
      }
      else if (pen_y > pen_x)
      {
        if (length != 0)
          normal = glm::vec2(glm::sign(translation.x - other_translation.x), 0);
        penetration = pen_x;
      }
      if (physics->GetMotionType() == Physics::Dynamic)
      {
        CollisionInfo lastCollision = collider->GetCollisionList().back();
        if (otherPhysics->GetMotionType() == Physics::Dynamic)
        {
          // Push each object out by half the penentration distance in the normal direction.
          transform->Translation() = transform->GetTranslation() +
            glm::vec3(normal *
              (penetration / 2), 0);

          otherTransform->Translation() = otherTransform->GetTranslation() +
            glm::vec3(-normal *
              (penetration / 2), 0);
        }
        else
        {
          transform->Translation() = transform->GetTranslation() +
            glm::vec3(normal *
              (penetration), 0);
        }
      }
    }

    return true;
  }

  return false;
}

bool Collider::StaticBoxtoStaticCircle(BoxCollider * collider, CircleCollider * otherCollider)
{
  Object * thisObject = &collider->Owner();
  Object * otherObject = &otherCollider->Owner();

  Transform * transform = thisObject->GetTransform();
  Transform * otherTransform = otherObject->GetTransform();
  glm::vec3 translation = transform->GetTranslation();
  glm::vec3 otherTranslation = otherTransform->GetTranslation();
  glm::vec2 contactPoint = glm::vec2(otherTranslation.x, otherTranslation.y);
  // Broad strokes bounding circle check.
  float distsqr = Math::DistanceSquared(translation, otherTranslation);
  float collisionDist = collider->GetBoundingRadius() + otherCollider->GetRadius();
  if (distsqr > collisionDist * collisionDist)
    return false;
  // Make a point to check contact with, and snap it to the edges of the box.
  if (contactPoint.x > translation.x + collider->GetWidth() / 2)
    contactPoint.x = translation.x + collider->GetWidth() / 2;
  if (contactPoint.x < translation.x - collider->GetWidth() / 2)
    contactPoint.x = translation.x - collider->GetWidth() / 2;
  if (contactPoint.y > translation.y + collider->GetHeight() / 2)
    contactPoint.y = translation.y + collider->GetHeight() / 2;
  if (contactPoint.y < translation.y - collider->GetHeight() / 2)
    contactPoint.y = translation.y - collider->GetHeight() / 2;
  distsqr = Math::DistanceSquared(glm::vec2(otherTranslation.x, otherTranslation.y), contactPoint);
  if (distsqr <= otherCollider->GetRadius() * otherCollider->GetRadius())
  {
    glm::vec2 normal;
    float penetration = 0;
    float width = collider->GetWidth() / 2;
    float height = collider->GetHeight() / 2;
    bool xGreater = glm::abs(otherTranslation.x - translation.x) > width;
    bool yGreater = glm::abs(otherTranslation.y - translation.y) > height;
    if (xGreater)
    {
      penetration +=  width * width;
      if (!yGreater)
      {
        normal = glm::vec2(otherTranslation.x - translation.x, 0);
      }
      else
      {
        normal = otherTranslation - translation;
      }
    }
    if (yGreater)
    {
      penetration += height * height;
      if (!xGreater)
      {
        normal = glm::vec2(0, otherTranslation.y - translation.y);
      }
    }

    if (!xGreater && !yGreater)
    {
      penetration += width * width;
      penetration += height * height;
      normal = otherTranslation - translation;
    }

    float length = glm::length(normal);
    if (length == 0)
      length = 0.00001f;
    normal /= length;
    penetration = glm::sqrt(penetration);
    penetration += otherCollider->GetRadius();
    penetration -= length;

    collider->_collisionData.push_back(CollisionInfo(otherObject, normal, contactPoint, penetration));
    otherCollider->_collisionData.push_back(CollisionInfo(thisObject, -normal, contactPoint, penetration));
    
    if ((*collisionTables.begin()).second->GetResolutionType(
      collider->GetCollisionGroup(),
      otherCollider->GetCollisionGroup()) == ResolutionType::Resolve)
    {
      Physics * physics = thisObject->Find<Physics>();
      Physics * otherPhysics = otherObject->Find<Physics>();

      if (physics->GetMotionType() == Physics::Dynamic)
      {
        CollisionInfo lastCollision = collider->GetCollisionList().back();
        if (otherPhysics->GetMotionType() == Physics::Dynamic)
        {
          // Push each object out by half the penentration distance in the normal direction.
          transform->Translation() = transform->GetTranslation() +
            glm::vec3(-normal *
              (penetration / 2), 0);

          otherTransform->Translation() = otherTransform->GetTranslation() +
            glm::vec3(normal *
              (penetration / 2), 0);
        }
        else
        {
          transform->Translation() = transform->GetTranslation() +
            glm::vec3(-normal *
              (penetration), 0);
        }
      }

      else
      {
        if (otherPhysics->GetMotionType() == Physics::Dynamic)
        {
          otherTransform->Translation() = otherTransform->GetTranslation() +
            glm::vec3(normal *
              (penetration), 0);
        }
      }
    }
    return true;
  }

  return false;
}

/*****************************************************************************/
/*!
\brief
	Returns the type of collider on this collider object.

\return
	Returns a collider type enum with the type of collider.
*/
/*****************************************************************************/
Collider::ColliderType Collider::Type()
{
	return _colliderType;
}

/*****************************************************************************/
/*!
\brief
  Check whether or not this collider had any collisions last frame.

\return
  Returns a true if the object collided, or false if it did not.
*/
/*****************************************************************************/
bool Collider::Collided()
{
  return _collided;
}

/*****************************************************************************/
/*!
\brief
  Get a container with the data for all collisions that happened this frame.

\return
  Returns a vector with collisioninfo objects.
*/
/*****************************************************************************/
const std::vector<CollisionInfo> & Collider::GetCollisionList()
{
  return _collisionData;
}

/*****************************************************************************/
/*!
\brief
  

\param


\return
*/
/*****************************************************************************/
CollisionInfo::CollisionInfo(Object * object, glm::vec2 normal, 
  glm::vec2 contactPoint, float penetrationDistance) 
: _object(object), _normal(normal), _contactPoint(contactPoint),
_penetrationDistance(penetrationDistance)
{
}


const std::string & Collider::GetCollisionGroup()
{
  return _collisionGroup;
}

CollisionInfo & CollisionInfo::operator=(const CollisionInfo & rhs)
{
  _object = rhs._object;
  _normal = rhs._normal;
  _contactPoint = rhs._contactPoint;
  _penetrationDistance = rhs._penetrationDistance;
  return *this;
}

Component * CreateColliderComponent(Json::Value value)
{
  if (value["type"].asString() == "Circle")
  {
    float radius = value["radius"].asFloat();
    std::string collisionGroup = "Default Group";
    collisionGroup = value["collisionGroup"].asString();
    Component * newComponent = new CircleCollider(radius, collisionGroup);
    return newComponent;
  }
  if (value["type"].asString() == "Box")
  {
    float width = value["width"].asFloat();
    float height = value["height"].asFloat();
    std::string collisionGroup = "Default Group";
    collisionGroup = value["collisionGroup"].asString();
    Component * newComponent = new BoxCollider(width, height, collisionGroup);
    return newComponent;
  }

  return nullptr;
}

Object * CollisionInfo::GetObject() const { return _object; }
glm::vec2 CollisionInfo::GetNormal() const { return _normal; }
glm::vec2 CollisionInfo::GetContact() const { return _contactPoint; }
float CollisionInfo::GetPenetration() const { return _penetrationDistance; }
/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file Camera.h
\author Connor Deakin
\par E-mail: connor.deakin\@digipen.edu
\par Project: Graphics
\date 24/12/2017
\brief
  Contains the interface for the Camera.
*/
/*****************************************************************************/

#ifndef CAMERA_H
#define CAMERA_H

#include <GLM/glm/vec3.hpp>
#include <GLM/glm/mat4x4.hpp>

/*****************************************************************************/
/*!
\class Camera
\brief
  Used to display the world at different locations, rotations, aspect ratios,
  and sizes.

\par Important Notes
  This will only find the matrix needed to display world coordinates in NDC.
  It is your job to update the shader matrix uniform that does transfromation.
*/
/*****************************************************************************/
class Camera
{
  public:
    Camera();
    void SetWidth(float new_width);
    void SetHeight(float new_height);
    void SetAspectRatio(float new_aspect_ratio);
    void SetRotation(float new_rotation);
    void SetPosition(const glm::vec3 & new_position);
    void Zoom(float delta_width);
    float GetWidth();
    float GetHeight();
    const glm::vec3 & GetPosition();
    const glm::mat4 & WorldToCamera();
    const glm::mat4 & CameraToWorld();
  private:
    //! Width of the Camera.
    float _width;
    //! Height of the Camera.
    float _height;
    //! Rotation of the Camera.
    float _rotation;
    //! Position of the Camera.
    glm::vec3 _position;
    //! Aspect ratio of the Camera (Width / Height).
    float _aspectRatio;
    //! The world to Camera transformation created by the Camera data.
    glm::mat4 _cTw;
    //! The Camera to world transformation created by the Camera data.
    glm::mat4 _wTc;
    //! Tracks whether the world to NDC matrix is correct when the matrix
    // is requested.
    bool _updated;
    void UpdateTransformations();
};

#endif // !CAMERA_H
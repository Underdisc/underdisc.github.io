/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file BoxCollider.h
\author Gabe Miller
\par E-mail: g.miller\@digipen.edu
\par Project: Boat Game
\date 11/11/2016 8:09:06 AM
\brief
*/
/*****************************************************************************/
#pragma once

#ifndef BoxCollider_H
#define BoxCollider_H

#include "Component.h"
#include "Collider.h"

/*****************************************************************************/
/*!
\class BoxCollider
\brief


\par
	Operations include:
	-

\deprecated
	-

\bug
	-
*/
/*****************************************************************************/
class BoxCollider : public Collider
{
public:
  BoxCollider(float width, float height, std::string collisionGroup = "Default Group", Collider::ColliderType type = Box);
  float GetWidth();
  float GetHeight();
  void SetWidth(float width);
  void SetHeight(float height);
  float GetBoundingRadius();
  virtual glm::vec2 * GeneratePoints(int * size);
private:
  float _width;
  float _height;
  bool CheckCollision(Collider * other);
  float _boundingRadius;
};

#endif
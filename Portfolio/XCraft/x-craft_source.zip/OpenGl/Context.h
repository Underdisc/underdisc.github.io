/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file Context.h
\author Connor Deakin
\par E-mail: connor.deakin\@digipen.edu
\par Project: Graphics
\date 30/09/2016
\brief
  Contains the interface to the Context class. Look at the Context class for
  more info. Make sure to pay attention to the important notes.
*/
/*****************************************************************************/

#ifndef CONTEXT_H
#define CONTEXT_H

#include <SDL/SDL.h>
#include <GLM/glm/vec2.hpp>

/*****************************************************************************/
/*!
\class Context
\brief
  This is used for creating an SDL context that can be used by openGL. Once a
  context is created, a new  context cannot be created until the old one is
  destroyed. This is a static class, so an instance of this class will never be
  constructed.

\par
    Important Notes
    - Specify both the width and height to be zero if you want the context to
        instantly go fullscreen.
    - If you are includeing this with a project, make sure that your main
        function is defined as the following.
        (int main(int argc, char * argv[])). SDL requires this for some reason.
*/
/*****************************************************************************/
class Context
{
  public:
    static void Create(const char * name = "Context", 
                       int width = 600, int height = 600,
                       int xposition = 30, int yposition = 30);
    static void Purge();
    static void CheckEvents();
    static void ToggleFullscreen();
    static void Swap();
    static void Clear(float red, float green, float blue);
    static void HideCursor(bool hide);
    static void AdjustViewport();
    static int Width();
    static int Height();
    static float AspectRatio();
    static bool KeepOpen();
    static void Close();
    static void ScreenToAspect(glm::vec2 & pixel);
    static void OnWindowEvent(const SDL_Event & event);
  private:
    static void InitSDL();
    //! Tracks whether a context has been created or not. Once a context is
    // created, a new one cannot be created.
    static bool _created;
    //! The height of the window in SDL units.
    static int _windowHeight;
    //! The width of the window in SDL units.
    static int _windowWidth;
    //! The aspect ratio (width / height) of the current screen.
    static float _aspectRatio;
    //! Tracks whether the screen is in full screen mode or not.
    static bool _fullscreen;
    //! Tracks the status of the Context. If the context is open and should
    // remain open, this will be true. If the Context needs to be closed, this
    // will be false. This value is accessed through the keep open function
    static bool _close;
    //! A pointer to the SDL window.
    static SDL_Window * _window;
    //! The OpenGL context that OpenGL will draw to.
    static SDL_GLContext  _context;
    Context() {}
};

#endif // !CONTEXT_H
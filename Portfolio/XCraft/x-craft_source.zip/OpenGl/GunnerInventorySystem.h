/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file GunInventoryComponent.h
\author Zach Dolph
\par E-mail: z.dolph\@digipen.edu
\par Project: Boat Game
\date 02/24/2017
\brief
*/
/*****************************************************************************/

#ifndef GUNNER_INV_COMP_H
#define GUNNER_INV_COMP_H

#include "Component.h"
#include "Transform.h"
#include "StateFactory.h"
#include "spaceID.h"

/*****************************************************************************/
/*!
\class GunInventoryComp
\brief
Component for

\par
Operations include:
-

\deprecated
-

\bug
-
*/
/*****************************************************************************/
class GunnerInventoryComponent : public Component
{
public:
  GunnerInventoryComponent();
  void Update();
  void OpenInventory();
  void CloseInventory();
  void SetSpace(spaceID gunInv);
  spaceID GetSpace();
  void Init();
private:
  Transform * menuSelecTran;
  Transform * zeroGun;
  Transform * oneGun;
  Transform * twoGun;
  Transform * threeGun;
  Transform * fourGun;
  Object * inventory;
  Object * cursor;
  Object * player;
  int _buttonPositionTop;
  int _buttonPositionBottom;
  int _weaponChosen;
  int _opened;
  bool _bottom;
  State* _levelone;
  spaceID _gunnerInv;
  std::vector<std::string> _gunIndex;
  std::vector<Object*> _gunObjs;

};

Component * CreateGunnerInventorySystem(Json::Value value);

#endif

/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#pragma once
/*****************************************************************************/
/*!
\file EnemyHealth.h
\author Gabe Miller
\par E-mail: g.miller\@digipen.edu
\par Project: Boat Game
\date 3/16/2017 3:43:57 PM
\brief
*/
/*****************************************************************************/

#ifndef EnemyHealth_H
#define EnemyHealth_H

#include "Component.h"
#include "Event.h"
#include "Collider.h"

// *** EXAMPLE EVENT *** //
// Adds a data member called damage, which the callback function will use.
// Note the usage of a static ID. Although this isn't required, I recommend using this as it will be harder to
// mess up the eventID when subscribing the event.
class EnemyDamaged : public Event
{
public:
  EnemyDamaged(int damage, CollisionInfo collisionInfo) : Event(ID), damage(damage), collisionInfo(collisionInfo) {}
  int damage;
  CollisionInfo collisionInfo;
  static const std::string ID;
  static const std::string DeathID;
};


/*****************************************************************************/
/*!
\class EnemyHealth
\brief


\par
	Operations include:
	-

\deprecated
	-

\bug
	-
*/
/*****************************************************************************/
class EnemyHealth : public Component
{
public:
  EnemyHealth(int health);
  void Damaged(Event * damageEvent);
  void Init();
  int GetHealth();
private:
  int _health;
};

Component * CreateEnemyHealthComponent(Json::Value value);

#endif
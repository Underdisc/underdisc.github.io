/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file Collider.h
\author Gabe Miller
\par E-mail: g.miller\@digipen.edu
\par Project: Boat Game
\date 10/6/2016 4:53:44 PM
\brief
	Interface for the collider base class.
*/
/*****************************************************************************/
#pragma once

#ifndef COLLIDER_H
#define COLLIDER_H

#include "Component.h"
#include <glm/glm.hpp> // vec2
#include <vector> // Game object container

/*****************************************************************************/
/*!
\class CollisionInfo
\brief
  Data structure which contains information about collisions between objects.

\par
    Operations include:
    -Get the object that was collided with.
    -Get the normal of collision.
    -Get the contact point of collision.
    -Get the penetration distance.

\deprecated
    -

\bug
    -
*/
/*****************************************************************************/
struct CollisionInfo
{
  CollisionInfo(Object * object, glm::vec2 normal, glm::vec2 contactPoint, float penetrationDistance);
  CollisionInfo & operator=(const CollisionInfo & rhs);
  Object * GetObject() const;
  glm::vec2 GetNormal() const;
  glm::vec2 GetContact() const;
  float GetPenetration() const;
private:
  Object * _object;
  glm::vec2 _normal;
  glm::vec2 _contactPoint;
  float _penetrationDistance;
};

/*****************************************************************************/
/*!
\class Collider
\brief
	Base class for all collider components. The class contains the core
	update loop for colliders, as well as collision detection functions,
	but does not contain the collider data.

\par
	Operations include:
	- Update
	- Circle to Circle Collision
	- Get collider type

\deprecated
	-

\bug
	-
*/
/*****************************************************************************/
class CircleCollider;
class BoxCollider;
class TileMap;

class Collider : public Component
{
  friend class CollisionManager;
public:
	/*****************************************************************************/
	/*!
	\enum ColliderType
	\brief
		Describes the type of collider a collider component has.

	\par
		Members
		- Box
		- Circle
		- Capsule
	*/
	/*****************************************************************************/
	enum ColliderType
	{
		Box,
		Circle,
		Capsule,
	};
	Collider(ColliderType colliderType, 
    std::string collisionGroup = "Default Group");
  ~Collider();
  void Init();
	void Update();
	ColliderType Type();
  bool Collided();
  const std::vector<CollisionInfo> & GetCollisionList();
  virtual bool CheckCollision(Collider * other) = 0;
  static void ResolveCollision(Object * thisObject, Object * otherObject);
  const std::string &GetCollisionGroup();
  bool TileCollision(TileMap * tiles);
  virtual glm::vec2 * GeneratePoints(int * size) = 0;

private:
	ColliderType _colliderType;
  // Tells if there was a collision last update
  bool _collided;
  std::string _collisionGroup;
protected:
	// A list of objects that were collided with last frame.
	std::vector<CollisionInfo> _collisionData;
	static bool StaticCircleToStaticCircle(CircleCollider * collider, CircleCollider * otherCollider);
  static bool StaticBoxToStaticBox(BoxCollider * collider, BoxCollider * otherCollider);
  static bool StaticBoxtoStaticCircle(BoxCollider * collider, CircleCollider * otherCollider);
};

Component * CreateColliderComponent(Json::Value value);

#endif
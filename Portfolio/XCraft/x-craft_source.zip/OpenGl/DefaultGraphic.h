/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file DefaultGraphic.h
\author Connor Deakin
\par E-mail: connor.deakin\@digipen.edu
\par Project: Graphics
\date 13/03/2017
\brief
  Contains the interface for the DefaultGraphic.
*/
/*****************************************************************************/

#ifndef DEFAULTGRAPHIC_H
#define DEFAULTGRAPHIC_H

#include "Graphic.h"

/*****************************************************************************/
/*!
\class DefaultGraphic
\brief
  Used to draw simple squares to the screen.
*/
/*****************************************************************************/
class DefaultGraphic : public Graphic
{
  public:
    DefaultGraphic();
    virtual void Draw() const;
};

#endif // !DEFAULTGRAPHIC_H

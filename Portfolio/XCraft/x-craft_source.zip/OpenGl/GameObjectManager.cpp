/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file GameObjectManager.cpp
\author Gabe Miller
\par E-mail: g.miller\@digipen.edu
\par Project: Boat Game
\date 10/7/2016
\brief
	This is the implementation file for the game object manager class.

\par
	Functions Include:
	-Create Object
	-Delete Object
	-Get Objects
	-Update
	-Destructor
*/
/*****************************************************************************/

#include "GameObjectManager.h"
#include "ArchetypeManager.h"
#include "Space.h"
#include "State.h"
#include "Renderer.h"
#include <iostream> // debug
// Global game object manager

/*****************************************************************************/
/*!
\brief
  Constructor for the GameObjectManager. 
*/
/*****************************************************************************/
GameObjectManager::GameObjectManager() : _collisionManager(this)
{}

/*****************************************************************************/
/*!
\brief
	Creates a new game object, and adds it to the list of game objects.

\param name
  Sets the name of the new object. Objects must have a name.

\return
	Returns a pointer to the newly created object.
*/
/*****************************************************************************/
Object * GameObjectManager::CreateObject(std::string name)
{
	// Make a new object and add it to the end of the list.
	Object * newObject = new Object(name);
	_gameObjects.push_back(newObject);
  newObject->_objManager = this;
	// Pass back the object
	return newObject;
}

/*****************************************************************************/
/*!
\brief
  Copies an existing game object into a new object, and adds it
  to the list of game objects.

\param other
  The object to create the new object off of.

\return
  Returns a pointer to the newly created object.
*/
/*****************************************************************************/
Object * GameObjectManager::CreateObject(const Object & other)
{
  // Make a new object and add it to the end of the list.
  Object * newObject = new Object(other);
  _gameObjects.push_back(newObject);
  newObject->_objManager = this;
  // Pass back the object.
  return newObject;
}

Object * GameObjectManager::CreateArchetypeObject(std::string archetype)
{
  Object * newObject = archetypeManager.CreateArchetypeObject(archetype, this);
  //_gameObjects.push_back(newObject);
  return newObject;
}

Object * GameObjectManager::CreateArchetypeObjectAtPosition(std::string archetype, glm::vec3 position)
{
  Object * newObject = archetypeManager.CreateArchetypeObjectAtPosition(archetype, this, position);
  //_gameObjects.push_back(newObject);
  return newObject;
}

/*****************************************************************************/
/*!
\brief
	Deletes an object from the game object list.

\param object
	A pointer to the object to be deleted
*/
/*****************************************************************************/
void GameObjectManager::DeleteObject(Object * object)
{
  if (object->_active == false)
    return;
  std::vector<Object *>::iterator it;
  for (it = _gameObjects.begin(); it < _gameObjects.end(); it++)
	{
    Object * eObject = *it;
		// Check if this object is the object the user was looking for
		if (eObject == object)
		{
      (**_space).GetRenderer().Remove(eObject->_sprite, &eObject->_transform);
      eObject->_active = false;
			break;
		}
	}
}

/*****************************************************************************/
/*!
\brief
	Gets the container of game objects from the game object manager. 
	The container is returned as const, so users can modify the objects
	inside, but not the pointers to the objects.

\return
	Returns a reference to the container.
*/
/*****************************************************************************/
std::vector<Object *> const & GameObjectManager::GetObjects()
{
	return _gameObjects;
}

/*****************************************************************************/
/*!
\brief
  Gets the first instance of the game object with the given name.

\param name
  The name of the gameobject to look for.

\return
  Returns a pointer to the game object.
*/
/*****************************************************************************/
Object * GameObjectManager::FindObjectByName(std::string name)
{
  for each (Object * object in _gameObjects)
  {
    if (object->Type() == name && object->_active)
      return object;
  }
  return nullptr;
}

/*****************************************************************************/
/*!
\brief
	Updates all the active game objects.
*/
/*****************************************************************************/
void GameObjectManager::Update()
{
  // I am using an int here rather than an iterator because
  // if the size of the game objects array changes mid loop
  // the iterator will become invalid.
  for (size_t i = 0; i < _gameObjects.size(); i++)
	{
    Object * object = _gameObjects[i];
    if(object->_active)
		  object->Update();
	}

  _collisionManager.Update();

  
  //Prune inactive objects
  std::vector<Object *>::iterator it;
  for (it = _gameObjects.begin(); it < _gameObjects.end(); it++)
  {
    Object * eObject = *it;
    
    
    if (!eObject->_active)
    {
      delete eObject;
      // Delete the object
      it = _gameObjects.erase(it);
      if (it == _gameObjects.end())
        break;
    }
    
  }
  

}

CollisionManager * GameObjectManager::GetCollisionManager()
{
  return &_collisionManager;
}

void GameObjectManager::ClearObjects()
{
  std::vector<Object *>::iterator it;
  for (it = _gameObjects.begin(); it != _gameObjects.end(); it++)
  {
    delete *it;
  }
  _gameObjects.clear();
}

/*****************************************************************************/
/*!
\brief
  Gets the ID of the Space that this GameObjectManager exists within. This will
  allow Objects and their Components to acess the Space they exist within.

\return The ID of the Space this GameObjectManager exists within.
*/
/*****************************************************************************/
spaceID GameObjectManager::Space()
{
  return _space;
}

/*****************************************************************************/
/*!
\brief
  Used to set the Space that this GameObjectManager exists within. The
  GameObjectManager is stored within a State which is stored within a Space.
  This Space needs to be known so objects within the Space can manipulate it.

\param space
  The ID of the Space that this GameObjectManager is in.
*/
/*****************************************************************************/
void GameObjectManager::SetSpaceID(spaceID space)
{
  _space = space;
}

/*****************************************************************************/
/*!
\brief
	The destructor for the Game Object Manager class. Deletes all the objects
	in the game object container.
*/
/*****************************************************************************/
GameObjectManager::~GameObjectManager()
{
	for each(Object * object in _gameObjects)
	{
		delete object;
	}
}
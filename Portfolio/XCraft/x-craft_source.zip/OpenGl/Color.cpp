/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#include "Color.h"

glm::vec3 HSVToRGB(glm::vec3 color)
{
  float hue = color.x;
  float sat = color.y;
  float val = color.z;
  float r;
  float g;
  float b;
  while (hue >= 360)
  {
    hue -= 360;
  }
  hue /= 60.0;
  //Truncates to 0-5
  int iHue = (int)hue;
  //The decimal portion of hue, used to determine the amount of secondary color to add
  float variance = hue - iHue;
  //The primary color
  float primary = val;
  //Secondary color ascending
  float secondary1 = val * (1.0f - (sat * (1.0f - variance)));
  //Secondary color descending
  float secondary2 = val * (1.0f - (sat * variance));
  //Changes the color to lighter or darker depending on sat and val, does not affect hue
  float tertiary = val * (1.0f - sat);

  switch (iHue)
  {
    //Red - yellow
  case 0:
    r = primary;
    g = secondary1;
    b = tertiary;
    break;
    //Yellow - green
  case 1:
    r = secondary2;
    g = primary;
    b = tertiary;
    break;
    //Green - blue-green
  case 2:
    r = tertiary;
    g = primary;
    b = secondary1;
    break;
    //Blue-green - blue
  case 3:
    r = tertiary;
    g = secondary2;
    b = primary;
    break;
    //Blue - purple
  case 4:
    r = secondary1;
    g = tertiary;
    b = primary;
    break;
    //Purple - red
  case 5:
    r = primary;
    g = tertiary;
    b = secondary2;
    break;
  }
  return glm::vec3(r, g, b);
}
glm::vec3 RGBToHSV(glm::vec3 color);
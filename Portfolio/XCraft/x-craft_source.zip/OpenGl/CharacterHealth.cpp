/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file CharacterHealth.cpp
\author yourname
\par E-mail: youremail
\par Project: Boat Game
\date 12/24/2016 7:41:03 PM
\brief

\par
Functions Include:
-
*/
/*****************************************************************************/

#include "CharacterHealth.h"
#include "Time.h"
#include "TextureSprite.h"
#include "Object.h"
#include "State.h"
#include "Collider.h"
#include "AudioEngine.h"
#include "SpaceManager.h"
#include "InputManager.h"
#include "TexturePool.h"
#include "CharacterController.h"
#include "EnergyController.h"
#include "GunnerInventory.h"

#include "Level.h"
#include "LoseScreen.h"

#include <iostream>


bool CharacterHealth::_gameStart = true;

CharacterHealth::CharacterHealth(int health, int shield) :
  Component("CharacterHealth"),
  _god(false),
  _health(health),
  _max_health(health),
  _shield(0.0f),
  _max_shield(0.0f),
  _HUD(Global::SpaceManager::NullSpaceID()),
  _invulnTimer(0.0f),
  _shieldCooldown(0.0f)
{
  //TexturePool::Add("Resources/Visual/Craft/Standard/DamagedPlayer.png");
}

CharacterHealth::~CharacterHealth()
{
  //if (_HUD != Global::SpaceManager::NullSpaceID())
    //Global::SpaceManager::Remove(_HUD);
}

void CharacterHealth::Init()
{
  spaceID current_space = Owner().ObjectManager()->Space();
  _HUD = Global::SpaceManager::AddAbove(current_space, HUD_OVERLAY, 30);
  Owner().Find<CharacterController>()->SetHUD(_HUD);
  Owner().Find<EnergyController>()->SetHUD(_HUD);
  Owner().Find<GunnerInventory>()->SetHUD(_HUD);
  for (int i = 0; i < sizeof(_healthSprites) / sizeof(Object *); i++)
  {
    _healthSprites[i] = (**_HUD).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("healthPip", glm::vec3(-11.95 + i * 0.75, -13.85, -1));
}
  for (int i = 0; i < sizeof(_shieldSprites) / sizeof(Object *); i++)
  {
    _shieldSprites[i] = (**_HUD).GetCurrentState()->GetObjectManager()->CreateArchetypeObjectAtPosition("smallPip", glm::vec3(-11.95 + i * 0.75, -12.5, -1));
  }
  (**_HUD).GetCurrentState()->GetObjectManager()->FindObjectByName("shieldBar")->GetSprite()->SetColor(1.0f, 0.94f, 0.27f, 1.0f);
  (**_HUD).GetCurrentState()->GetObjectManager()->FindObjectByName("healthBar")->GetSprite()->SetColor(1.0f, 0.94f, 0.27f, 1.0f);


  _shieldObject = Owner().ObjectManager()->CreateArchetypeObjectAtPosition("Shield", glm::vec3(0.0f, 0.0f, 1.0f));
  _shieldObject->ChangeParent(&Owner());

  if (_gameStart)
    Global::SpaceManager::AddAbove(_HUD, DIALOGUE_LEVEL, 30);
  _gameStart = false;

}

void CharacterHealth::Update()
{
  if (_invulnTimer > 0)
  {
    TextureSprite * sprite = reinterpret_cast<TextureSprite *>(Owner().GetSprite());
    _invulnTimer -= Time::DT();
    if (_invulnTimer <= 0)
    {
      (**_HUD).GetCurrentState()->GetObjectManager()->FindObjectByName("shieldBar")->GetSprite()->SetColor(1.0f, 0.94f, 0.27f, 1.0f);
      (**_HUD).GetCurrentState()->GetObjectManager()->FindObjectByName("healthBar")->GetSprite()->SetColor(1.0f, 0.94f, 0.27f, 1.0f);
    }
  }
  else
  {
  }

  _shieldCooldown -= Time::DT();
  if (_shieldCooldown <= 0)
  {
    if (_shield < 0)
      _shield = 0;
    _shield += 6 * Time::DT();
  }

  if (InputManager::Instance()->IsKeyPressed(SDL_SCANCODE_LCTRL) && TheInputManager::Instance()->IsKeyPressed(SDL_SCANCODE_G))
  {
    _god = !_god;
  }

  _max_shield = Owner().Find<EnergyController>()->GetEnergyLevel(EnergyController::SHIELDS) * 6;

  if (_shield > _max_shield)
    _shield = _max_shield;
  

  if (_invulnTimer <= 0)
  {
    Owner().GetSprite()->SetColor(1.0f, 1.0f, 1.0f, 1.0f);
    _shieldObject->GetSprite()->SetColor(1.0f, 1.0f, 1.0f, _shield / 24.0f);
  }
  else
  {
    float val;
    if (_shield > 0)
      val = _invulnTimer / 0.3f;
    else
      val = 0;
    _shieldObject->GetSprite()->SetColor(1 + val, 1 + val, 1 + val, (_shield / 24.0f) + val);
  }

  Collider * collider = Owner().Find<Collider>();
  for each (CollisionInfo info in collider->GetCollisionList())
  {
    std::string otherObject = info.GetObject()->Find<Collider>()->GetCollisionGroup();
    if ((otherObject == "Enemy" || otherObject == "EnemyBullet") &&
      !_god && _invulnTimer <= 0)
    {
      if (_shield > 0)
      {
        audEngine.PlayEvent("event:/SFX/ShieldImpact");
        _shieldObject->GetSprite()->SetColor(2.0f, 2.0f, 2.0f, 1.0f);
        _shield -= 6;
        _shieldCooldown = 5;
        (**_HUD).GetCurrentState()->GetObjectManager()->FindObjectByName("shieldBar")->GetSprite()->SetColor(1.0f, 0, 0, 1.0f);
      }
      else
      {
        audEngine.PlayEvent("event:/SFX/collision");
        Owner().GetSprite()->SetColor(1.0f, 0.0f, 0.0f, 1.0f);
        _health -= 6;
        (**_HUD).GetCurrentState()->GetObjectManager()->FindObjectByName("healthBar")->GetSprite()->SetColor(1.0f, 0, 0, 1.0f);
      }
      _invulnTimer = 0.3f;
    }
    if (otherObject == "healthKit") {
      if (_health < _max_health) {
        _health += 6;
      }
      if (_health < _max_health)
        _health = _max_health;
      audEngine.PlayEvent("event:/SFX/HealthKit");
    }
  }


  if (_HUD != Global::SpaceManager::NullSpaceID()) {
    int HealthPercent = (_health / _max_health) * sizeof(_healthSprites) / sizeof(Object *);
    int i;
    for (i = 0; i < HealthPercent; i++)
    {
      reinterpret_cast<TextureSprite *>(_healthSprites[i]->GetSprite())->SetTexture(TexturePool::Add("Resources/Visual/HUD/medpip.png"));
    }
    for (; i < sizeof(_healthSprites) / sizeof(Object *); i++)
    {
      reinterpret_cast<TextureSprite *>(_healthSprites[i]->GetSprite())->SetTexture(TexturePool::Add("Resources/Visual/HUD/Nothing.png"));
    }



    for (i = 0; i < _shield; i++)
    {
      reinterpret_cast<TextureSprite *>(_shieldSprites[i]->GetSprite())->SetTexture(TexturePool::Add("Resources/Visual/HUD/smallpip.png"));
    }
    for (; i < sizeof(_shieldSprites) / sizeof(Object *); i++)
    {
      reinterpret_cast<TextureSprite *>(_shieldSprites[i]->GetSprite())->SetTexture(TexturePool::Add("Resources/Visual/HUD/Nothing.png"));
    }
  }

  if (_health <= 0)
  {

    LoseScreen::level = dynamic_cast<Level *>(Global::SpaceManager::FindState(LEVEL_ONE))->GetLevelFile();
    Global::SpaceManager::RemoveAll();
    Global::SpaceManager::Add(LOSE_SCREEN, 30);
  }
}

/*****************************************************************************/
/*!
\brief


\param


\return
*/
/*****************************************************************************/
bool CharacterHealth::IsGod()
{
  return _god;
}

void CharacterHealth::SetHUD(spaceID HUD)
{
  _HUD = HUD;
}


spaceID CharacterHealth::GetHUD()
{
  return _HUD;
}

/*****************************************************************************/
/*!
\brief


\param


\return
*/
/*****************************************************************************/
void CharacterHealth::God(bool is_god)
{
  _god = is_god;
  if (_god)
    _health = _max_health;
}

Component * CreateCharacterHealthComponent(Json::Value value)
{
  return new CharacterHealth(value["health"].asInt(), value["shield"].asInt());
}
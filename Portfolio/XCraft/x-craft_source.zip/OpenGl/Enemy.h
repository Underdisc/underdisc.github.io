/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file Enemy.h
\author Gabe Miller
\par E-mail: g.miller\@digipen.edu
\par Project: Boat Game
\date 10/31/2016 6:21:56 PM
\brief
*/
/*****************************************************************************/
#pragma once

#ifndef Enemy_H
#define Enemy_H

#include "Component.h"
#include "EnemyHealth.h"



/*****************************************************************************/
/*!
\class Enemy
\brief


\par
	Operations include:
	-

\deprecated
	-

\bug
	-
*/
/*****************************************************************************/
class Enemy : public Component
{
public:
  Enemy();
  ~Enemy();
  void Update();
  void Init();
  static int GetActivated();
  void Damaged(Event * damageEvent);
  void Dead(Event * damageEvent);
private:
  Object * _player;
  bool _triggered;
  float _dist;
  static int _activated;
};

Component * CreateEnemyComponent(Json::Value value);
#endif
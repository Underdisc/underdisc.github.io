/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file Emiter.cpp
\author Sukanya Ratanotayanon
\par E-mail: sratanot@sci.tu.ac.th
\par Project: Boat Game
\date 2/13/2017 12:14:13 PM
\brief

\par
Functions Include:
-
*/
/*****************************************************************************/

#include "Emitter.h"
#include "Time.h"
#include <iostream>
#include <random>
#include "Transform.h"
#include <GLM/glm/gtc/type_ptr.hpp>
#include "OpenGLError.h"
#include <GLM/glm/vec4.hpp>
#include "ParticleShader.h"
#include "Shader.h"
#include "ShaderTexture.h"

#define PI 3.14159265f

Emitter::Emitter(const Shader * shader, const Graphic *graphic, Transform * transform, int totalParticle,
  float emissionRate , float defaultSize ,  float defaultSpeed,  float defaultLife, int sizeScale,
  int speedScale , int lifeScale , int shootAmount , int startDegree, int endDegree)
  :_shader(shader), _graphic(graphic), _transform(transform),_totalParticle (totalParticle), _active(false),
  _particlePool(nullptr),_emisionRate(emissionRate), _defaultSize(defaultSize),_sizeScale(sizeScale),
  _defaultSpeed(defaultSpeed),_speedScale(speedScale),_particleIndex(0), _defaultLife(defaultLife), 
  _lifeScale(lifeScale), _shootAmount(shootAmount), _startDegree(startDegree), _endDegree(endDegree), _stopSpawing(false)
{
  _timeCount = 0;
  _color = glm::vec4(1.0, 0.9, 1.0,1.0);
}

void Emitter::Init()
{
  if (_particlePool != nullptr)
  {
    clearParticlePool();
  }
  _particlePool = new Particle*[_totalParticle];
  for (int i = 0; i < _totalParticle; i++) {
    int degree = _startDegree + rand() % (_endDegree - _startDegree) ;
    float angleRad = degree*PI / 180;
    int factorS = rand() % _speedScale+1;
    int factorL = rand() % _lifeScale + 1;
    int factorSize = rand() % _sizeScale + 1;
    //float factorSf = (_defaultSpeed / _speedScale) * factorS;
    //float factorLf = (_defaultLife/_lifeScale)*factorL;
    float factorSizef = (_defaultSize / _sizeScale)*factorSize;
    float life = _defaultLife * factorL;
    float speed = _defaultSpeed *factorS;
    float size = _defaultSize + factorSizef;
    _particlePool[i] = new Particle(life,angleRad,speed,size);
  }
  _particleIndex = 0;
  SetActive(true);
}


void Emitter::clearParticlePool()
{
  SetActive(false);
  if (_particlePool != nullptr)
  {
    for (int i = 0; i < _totalParticle; i++) {
      delete _particlePool[i];
    }
    delete[] _particlePool;
  }
}
void Emitter::shootParticle()
{
  //Check whether there are available particle in the pool. If there are, shoot one.
  // _particleIndex will point to the first available particle in the pool
  if (!IsRunout()) {
    //std::cout << "shoot " << _particleIndex << std:: endl;
    _particlePool[_particleIndex]->Init(_transform->GetAbsoluteTranslation());
    _particleIndex++;
  }
}
void Emitter::shootParticle(int number)
{
  for (int i = 0; i < number; i++) {
    shootParticle();
  }
}

Emitter::~Emitter()
{
  std::cout << "Emitter destructor clears pool" << std::endl;
  clearParticlePool();
  delete _transform;
}
void Emitter::updateParticles(float deltaTime)
{
  for (int i = 0; i < _particleIndex; i++) {
    //Update each particle & draw
    Particle *p = _particlePool[i];
    float pLife = p->getLife();
    if (pLife > 0) {
      
      float x = p->getTransform().GetTranslation().x + p->getSpeed() * deltaTime * cosf(p->getAngleRad());
      float y = p->getTransform().GetTranslation().y + p->getSpeed() * deltaTime * sin(p->getAngleRad());
      glm::vec3 pos = glm::vec3(x, y, p->getTransform().GetTranslation().z);
      //if (size > 0.01f) {
      //  size -= 0.0005f;
      //}
      pLife -= deltaTime;
      
      float size = p->getInitialSize() * p->getAlpha();
      float pAlpha = pLife / p->getInitialLife();
      p->UpdateProperties(pLife,p->getAngleRad(),p->getSpeed(),pos,size,pAlpha);
    }
  }
  
}
void Emitter::Update(const glm::mat4 & world_to_ndc)
{ 
  float deltaTime = Time::DT();

  if (_active) {
    _timeCount = _timeCount + deltaTime;
    //std::cout << "Timecount " << _timeCount << "delta time" << deltaTime << std::endl;
    while (_timeCount > (1.0f / _emisionRate)) {
      if(!_stopSpawing)
        shootParticle(1);
      _timeCount -= (1.0f / _emisionRate);
    }
    updateParticles(deltaTime);
    _shader->Use();
    for (int i = 0; i < _particleIndex; i++) {
      Particle *p = _particlePool[i];
      //***** TODO --- Make this into a draw method
      drawParticle(p, world_to_ndc);
    }

    //std::cout << "Emitter Transformation: " << _transform->Translation().x << "," << _transform->Translation().y << "," << _transform->Translation().z << std::endl;

    //Cliam all dead particle. This is done by going trough the array of particles with 
    //two pointer one at the front and one at the back. We first move the back pointer (using _particleIndex)
    //to make sure that the one before it is alive then move the front pointer. 
    //When we find the first dead particle, we swap it with the one before the back pointer and move the back pointer up.
    //repeat untill the front meet the back pointer
    int checkIndex = 0;
    while (checkIndex < _particleIndex) {
      while (_particleIndex > 0 && _particlePool[_particleIndex-1]->_life <= 0 ) {
        _particleIndex--;
      }
      if (checkIndex < _particleIndex && _particlePool[checkIndex]->_life <= 0 ) {
        _particleIndex--;
        Particle *p = _particlePool[checkIndex];
        _particlePool[checkIndex] = _particlePool[_particleIndex];
        _particlePool[_particleIndex] = p;
      }
      checkIndex++;
    }
  }
}
void Emitter::drawParticle(Particle *p, const glm::mat4 & world_to_ndc) {

  // setting color
  const GraphicShader* gShader = dynamic_cast<const GraphicShader*>(_shader);

  if (gShader != nullptr) {
    gShader->Use();
    glUniform4fv(gShader->ColorU(), 1, glm::value_ptr(glm::vec4(_color.r, _color.g, _color.b, p->getAlpha())));
    glUniformMatrix4fv(gShader->TransformationU(), 1, GL_FALSE, glm::value_ptr(world_to_ndc*p->getTransform().ObjectToWorld()));

  }
  else {
    const ShaderTexture* gtShader = dynamic_cast<const ShaderTexture*>(_shader);
    if (gtShader != nullptr) {
      glm::vec3 texture_scale(_texture->AspectRatio(), 1.0f, 1.0f);
      glm::vec3 pScale = p->getTransform().GetScale();
      p->getTransform().ChangeInScale(glm::vec3(texture_scale.x*pScale.x, texture_scale.y*pScale.y, texture_scale.z*pScale.z));
      gtShader->Use();
      _texture->Bind();
      glUniformMatrix4fv(gtShader->TransformationU(), 1, GL_FALSE, glm::value_ptr(world_to_ndc*p->getTransform().ObjectToWorld()));
      glUniform4fv(gtShader->ColorU(), 1, glm::value_ptr(_color));
    }

  }



  GLenum error_code = glGetError();
  if (error_code) {
    OpenGLError error("GraphicSprite.cpp", "Draw");
    error.Code(error_code);
    error.Add("Encountered while setting the GraphicShader's color uniform.");
    throw(error);
  }
  // drawing
  _graphic->Draw();

}
bool Emitter::IsRunout()
{
  return _particleIndex >= _totalParticle;
}

bool Emitter::IsActive()
{
  return _active;
}

void Emitter::SetActive(bool active)
{
  _active = active;
}



Transform * Emitter::GetTransform()
{
  return _transform;
}

Emitter* Emitter::createEmitter(EmitterType type, const Shader *shader, const Graphic *graphic, Transform * transform,
  int totalParticle, float emissionRate, float defaultSize, float defaultSpeed, 
  float defaultLife, int sizeScale, int speedScale, int lifeScale, 
  int shootAmount , int startDegree, int endDegree)
{
  if (type == CIRCLE_RING) {
    return new RingEmitter(shader, graphic, transform, totalParticle, 
      emissionRate, defaultSize, defaultSpeed, defaultLife, sizeScale, 
      speedScale, lifeScale,shootAmount, startDegree, endDegree);

  }
  else {
    return new Emitter(shader, graphic, transform, totalParticle, emissionRate,
      defaultSize, defaultSpeed, defaultLife, sizeScale, speedScale, 
      lifeScale, shootAmount, startDegree, endDegree);

  }
  
}



RingEmitter::RingEmitter(const Shader *shader, const Graphic *graphic, Transform * transform,
  int totalParticle, float emissionRate, float defaultSize, float defaultSpeed, float defaultLife,
  int sizeScale, int speedScale, int lifeScale, int shootAmount, int startDegree, int endDegree)
  :Emitter(shader, graphic, transform, totalParticle, emissionRate, defaultSize, defaultSpeed, 
    defaultLife, sizeScale, speedScale, lifeScale, shootAmount,startDegree,endDegree)
{
}

RingEmitter::~RingEmitter()
{
}

void RingEmitter::updateParticles(float deltaTime)
{
  for (int i = 0; i < _particleIndex; i++) {
    //Update each particle & draw
    Particle *p = _particlePool[i];
    float pLife = p->getLife();
    if (pLife > 0) {
      //float x = _transform->GetAbsoluteTranslation().x;
      //float y = _transform->GetAbsoluteTranslation().y;
      //float z = _transform->GetAbsoluteTranslation().z;
     // glm::vec3 pos = glm::vec3(x, y, z);
      //float size = p->getSize() + (p->getSize() / 1500.0f);
      float size = p->getSize() + p->getSpeed();
      pLife -= deltaTime;
      float pAlpha = pLife / p->getInitialLife();
      if (this->_willMove) {
        p->UpdateProperties(pLife, p->getAngleRad(), p->getSpeed(), GetTransform()->GetAbsoluteTranslation(), size, pAlpha);
      }
      else {
        p->UpdateProperties(pLife, p->getAngleRad(), p->getSpeed(), p->getTransform().Translation(), size, pAlpha);

      }
    }
  }
}

void RingEmitter::setWillMove(bool move)
{
  this->_willMove = move;
}


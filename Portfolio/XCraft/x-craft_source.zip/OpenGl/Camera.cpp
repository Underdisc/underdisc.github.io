/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file Camera.cpp
\author Connor Deakin
\par E-mail: connor.deakin\@digipen.edu
\par Project: Graphics
\date 24/12/2017
\brief
  Contains the implementation of the Camera. Look at the Camera class
  for more information.
*/
/*****************************************************************************/

#include <glm/glm/gtc/matrix_transform.hpp> 

#include "Camera.h"

/*****************************************************************************/
/*!
\brief
  Constructs a camera at the origin with a width and height of 2.0f.
*/
/*****************************************************************************/
Camera::Camera() : 
_width(2.0f), _height(2.0f), _rotation(0.0f), _position(0.0f, 0.0f, 0.0f),
_aspectRatio(1.0f), _cTw(), _updated(false)
{}

/*****************************************************************************/
/*!
\brief
  Change the width of the camera. This will change the number of world units
  displayed across the width of the camera.

\par Important Notes
  - This will automitically change the height of the camera according to the
    aspect ratio of the camera.

\param new_width
  The new width of the Camera.
*/
/*****************************************************************************/
void Camera::SetWidth(float new_width)
{
  _width = new_width;
  _height = _width / _aspectRatio;
  _updated = false;
}

/*****************************************************************************/
/*!
\brief
  Change the height of the camera. This will change the number of world units
  displayed across the height of the camera.

\par Important Notes
  - This will automitically change the width of the camera according to the
    aspect ratio of the camera.

\param new_height
  The new height of the camera.
*/
/*****************************************************************************/
void Camera::SetHeight(float new_height)
{
  _height = new_height;
  _width = _height * _aspectRatio;
  _updated = false;
}

/*****************************************************************************/
/*!
\brief
  Sets the aspect ratio of the Camera (width / height). This will automatically
  change the height of the camera in order to match the new aspect ratio.

\param new_aspect_ratio
  The new aspect ratio.
*/
/*****************************************************************************/
void Camera::SetAspectRatio(float new_aspect_ratio)
{
  _aspectRatio = new_aspect_ratio;
  _height = _width / _aspectRatio;
  _updated = false;
}

/*****************************************************************************/
/*!
\brief
  Change the rotation of the Camera.

\par Important Notes
  - The rotation value must be given in radians.

\param new_rotation
  The new rotation of the Camera.
*/
/*****************************************************************************/
void Camera::SetRotation(float new_rotation)
{
  _rotation = new_rotation;
  _updated = false;
}

/*****************************************************************************/
/*!
\brief
  Set the position of the camera.

\par Important Notes
  - Changing the Z value will not apply any zoom affect. To be safe, use 0.0f
    for your Z value.

\param new_position
  The new position the Camera will be centered at.
*/
/*****************************************************************************/
void Camera::SetPosition(const glm::vec3 & new_position)
{
  _position = new_position;
  _updated = false;
}

/*****************************************************************************/
/*!
\brief
  Zooms the camera in or out. The camera will zoom by adding some value to the
  current width of the camera. If the camera width is 4.0f and you Zoom by
  2.0f, the new width will be 6.0f.

\par Important Notes
  - This will automitically update the height with the aspect ratio.

\param delta_width
  The change in width.
*/
/*****************************************************************************/
void Camera::Zoom(float delta_width)
{
  _width += delta_width;
  _height = _width / _aspectRatio;
  _updated = false;
}

/*!
\brief Get the camera width.
\return The camera's width.
*/
float Camera::GetWidth()
{
  return _width;
}

/*!
\brief Get the camera height.
\return The camera's height.
*/
float Camera::GetHeight()
{
  return _height;
}

/*!
\brief Get the camera's current positon.
\return The cameras current positon.
*/
const glm::vec3 & Camera::GetPosition()
{
  return _position;
}

/*****************************************************************************/
/*!
\brief
  Returns the world to camera matrix that is used to transform mesh vertices.

\return The world to camera matrix.
*/
/*****************************************************************************/
const glm::mat4 & Camera::WorldToCamera()
{
  if(!_updated)
    UpdateTransformations();
  return _cTw;
}

/*****************************************************************************/
/*!
\brief
  Returns the Camera to world matrix.

\return The Camera to world matrix.
*/
/*****************************************************************************/
const glm::mat4 & Camera::CameraToWorld()
{
  if (!_updated)
    UpdateTransformations();
  return _wTc;
}

/*****************************************************************************/
/*!
\brief
  Updates the world to camera matrix. This will be called if the Camera data is
  different when you fetch the WorldTocamera matrix from the last time it was
  fetched.
*/
/*****************************************************************************/
//CONSIDER: The glm::ortho call may need to go somewhere else.
void Camera::UpdateTransformations()
{
  // update _cTw
  float hw = _width / 2.0f;
  float hh = _height / 2.0f;
  glm::mat4 new_cTw;
  new_cTw = glm::scale(new_cTw, glm::vec3((2.0f/_width), (2.0f/_height), 1.0f));
  new_cTw = glm::rotate(new_cTw, -_rotation, glm::vec3(0.0f, 0.0f, 1.0f));
  new_cTw = glm::translate(new_cTw, -_position);
  _cTw = glm::ortho(-1.0f, 1.0f, -1.0f, 1.0f, -10.f, 10.0f) * new_cTw;
  _updated = true;
  // update _wTc
  _wTc = glm::inverse(_cTw);
}


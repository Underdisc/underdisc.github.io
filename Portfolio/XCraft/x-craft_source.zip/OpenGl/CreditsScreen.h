/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#ifndef CREDITS_SCREEN_H
#define CREDITS_SCREEN_H

#include "State.h"

class CreditsScreen : public State
{
public:
  CreditsScreen() : _done(false) {}
  virtual void Allocate();
  virtual void Load();
  virtual bool Update();
  virtual void Free();
private:
  Transform * _creditsTransform;
  bool _done;

};

#endif
/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
#pragma once
/*****************************************************************************/
/*!
\file CameraController.h
\author Gabe Miller
\par E-mail: g.miller\@digipen.edu
\par Project: Boat Game
\date 2/15/2017 2:21:33 PM
\brief
*/
/*****************************************************************************/

#ifndef CameraController_H
#define CameraController_H

#include "Component.h"
#include "Camera.h"
#include <glm\glm.hpp>

/*****************************************************************************/
/*!
\class CameraController
\brief


\par
	Operations include:
	-

\deprecated
	-

\bug
	-
*/
/*****************************************************************************/
class CameraController : public Component
{
public:
  CameraController();
  void Update();
  void Init();
private:
  Camera * _camera;
  float _shakeDuration;
  float _shakeTimer;
  glm::vec2 _shakeDir;
  float _shakeFrequency;
};

Component * CreateCameraController(Json::Value value);

#endif
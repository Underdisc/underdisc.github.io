/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file Component.h
\author Connor Deakin
\par E-mail: connortdeakin\@gmail.com
\par Project: Mecha
\date 11/09/2016
\brief
  Contains the interface for the Component class.
*/
/*****************************************************************************/

/*****************************************************************************/
#ifndef COMPONENT_H
#define COMPONENT_H

#include <string> // std::string
#include <map> // std::map
#include <json\json.h> // Json::Value

class Object; // Object

/*****************************************************************************/
/*!
\class Component
\brief
  This is the base class for the component hierarchy. All component objects
  are to be derived from this base class. Do not add a component of type
  Component to a game Object.

\par
    Operations include:
    - Creating a Component
    - Getting the type of the Component
    - Getting the owner of a Component
    - Updating the Component
    - Get a function that creates a Component

\deprecated
    - Only one constructor provided
      Component(std::string type);

\bug
    - Nothing
*/
/*****************************************************************************/
class Component
{
  friend class Object;
  public:
    Component(std::string type);
    virtual ~Component() {}
    virtual void Update();
    std::string Type();
    Object & Owner();
    virtual void Init() { };
  protected:
    //! A pointer to the Object that a particular Component is attached to.
    Object * _owner;
  private:
    //! The Component's type in string form.
    std::string _type;
    void SetOwner(Object * new_owner);
    /*Gabe's Code*/
    typedef Component * componentFn(Json::Value);
  public:
    Component(const Component & other, Object * owner);
    virtual void Copy(const Component & other);
    /* The type of this is a function which takes a string, and returns a function pointer
       to a function which takes nothing, and returns a component pointer*/
    static componentFn * GetComponentCreator(std::string type);
    static std::vector<std::string> GetDependencies(std::string type);
  private:
    //! A map with functions to create components
    static std::map<std::string, componentFn*> _componentCreators;
    static std::map<std::string, std::vector<std::string>> _dependencies;
    /*End Gabe's Code*/
};

#endif
/*****************************************************************************/


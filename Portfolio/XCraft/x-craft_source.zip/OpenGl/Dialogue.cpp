/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file Dialogue.cpp
\author Gabe Miller
\par E-mail: g.miller\@digipen.edu
\par Project: Boat Game
\date 4/19/2017 1:27:44 PM
\brief

\par
Functions Include:
-
*/
/*****************************************************************************/

#include "SpaceManager.h"
#include "Dialogue.h"
#include "Object.h"
#include "GameObjectManager.h"
#include "Sprite.h"
#include "SpritePool.h"
#include "ShaderPool.h"
#include "TexturePool.h"
#include "SoundEmitter.h"
#include "Time.h"

#define OFFSET 5.0f


static Sprite * MakeSprite(std::string texture)
{
  return reinterpret_cast<Sprite *>(SpritePool::AddTexture(&ShaderPool::Texture(), TexturePool::Add(texture)));
}

Dialogue::Dialogue() : Component("Dialogue"), _time(0), stage(0)
{

}
void Dialogue::Init()
{
  _picture1 = Owner().ObjectManager()->CreateObject("picture1");
  _picture1->GetTransform()->SetScale(6.0f);
  _picture1->SetSprite(MakeSprite("Resources/Visual/Dialogue/CadetLowlight.png"));
  _picture2 = Owner().ObjectManager()->CreateObject("picture2");
  _picture2->GetTransform()->SetScale(6.0f);
  _picture2->SetSprite(MakeSprite("Resources/Visual/Dialogue/CaptainLowlight.png"));
  _text = Owner().ObjectManager()->CreateObject("text");
  _text->GetTransform()->SetScale(10.0f);

  _spaceRenderer = &(**Owner().ObjectManager()->Space()).GetRenderer();
  _spaceRenderer->Add(_picture1->GetSprite(), _picture1->GetTransform());
  _spaceRenderer->Add(_picture2->GetSprite(), _picture2->GetTransform());

  _picture1->GetSprite()->SetAlpha(0.0f);
  _picture2->GetSprite()->SetAlpha(0.0f);

  Owner().GetSprite()->SetAlpha(0.0f);

}
void Dialogue::Update()
{
  _time += Time::DT();
  if (stage == 0)
  {
    glm::vec3 pos = Owner().GetTransform()->Translation();
    _picture1->GetTransform()->Translation() = pos + glm::vec3(-16.25f, -1.5f, 2);
    _picture2->GetTransform()->Translation() = pos + glm::vec3(16.25f, -1.5f, 2);
    _text->GetTransform()->Translation() = pos + glm::vec3(0, 0, 2);
    Owner().GetSprite()->SetAlpha(_time - OFFSET);
    _picture1->GetSprite()->SetAlpha(_time - OFFSET);
    _picture2->GetSprite()->SetAlpha(_time - OFFSET);
  }
  if (stage == 0 && _time > OFFSET + 1.0f)
  {
    _text->SetSprite(MakeSprite("Resources/Visual/Dialogue/Line1.png"));
    _spaceRenderer->Add(_text->GetSprite(), _text->GetTransform());
    _spaceRenderer->Remove(_picture2->GetSprite(), _picture2->GetTransform());
    _picture2->SetSprite(MakeSprite("Resources/Visual/Dialogue/CaptainHighlight.png"));
    _spaceRenderer->Add(_picture2->GetSprite(), _picture2->GetTransform());
    Owner().Find<SoundEmitter>()->PlaySound("Dialogue1");
    stage++;
  }
  if (stage == 1 && _time > OFFSET + 6.0f)
  {
    _spaceRenderer->Remove(_picture2->GetSprite(), _picture2->GetTransform());
    _picture2->SetSprite(MakeSprite("Resources/Visual/Dialogue/CaptainLowlight.png"));
    _spaceRenderer->Add(_picture2->GetSprite(), _picture2->GetTransform());

    _spaceRenderer->Remove(_picture1->GetSprite(), _picture1->GetTransform());
    _picture1->SetSprite(MakeSprite("Resources/Visual/Dialogue/CadetHighlight.png"));
    _spaceRenderer->Add(_picture1->GetSprite(), _picture1->GetTransform());
    _spaceRenderer->Remove(_text->GetSprite(), _text->GetTransform());
    _text->SetSprite(MakeSprite("Resources/Visual/Dialogue/Line2.png"));
    _spaceRenderer->Add(_text->GetSprite(), _text->GetTransform());
    Owner().Find<SoundEmitter>()->PlaySound("Dialogue2");
    stage++;
  }
  if (stage == 2 && _time > OFFSET + 8.0f)
  {
    Owner().Find<SoundEmitter>()->PlaySound("Dialogue3");
    _spaceRenderer->Remove(_text->GetSprite(), _text->GetTransform());
    _text->SetSprite(MakeSprite("Resources/Visual/Dialogue/Line3.png"));
    _spaceRenderer->Add(_text->GetSprite(), _text->GetTransform());
    stage++;
  }
  if (stage == 3 && _time > OFFSET + 11.0f)
  {
    _spaceRenderer->Remove(_picture2->GetSprite(), _picture2->GetTransform());
    _picture2->SetSprite(MakeSprite("Resources/Visual/Dialogue/CaptainHighlight.png"));
    _spaceRenderer->Add(_picture2->GetSprite(), _picture2->GetTransform());

    _spaceRenderer->Remove(_picture1->GetSprite(), _picture1->GetTransform());
    _picture1->SetSprite(MakeSprite("Resources/Visual/Dialogue/CadetLowlight.png"));
    _spaceRenderer->Add(_picture1->GetSprite(), _picture1->GetTransform());
    _spaceRenderer->Remove(_text->GetSprite(), _text->GetTransform());
    _text->SetSprite(MakeSprite("Resources/Visual/Dialogue/Line4.png"));
    _spaceRenderer->Add(_text->GetSprite(), _text->GetTransform());
    Owner().Find<SoundEmitter>()->PlaySound("Dialogue4");
    stage++;
  }
  if (stage == 4 && _time > OFFSET + 12.0f)
  {
    _text->GetSprite()->SetAlpha(0.0f);
    Owner().GetSprite()->SetAlpha(13.0f - (_time - OFFSET));
    _picture1->GetSprite()->SetAlpha(13.0f - (_time - OFFSET));
    _picture2->GetSprite()->SetAlpha(13.0f - (_time - OFFSET));
  }
  if (stage == 4 && _time > OFFSET + 13.0f)
  {
    Global::SpaceManager::Remove(Owner().ObjectManager()->Space());
    Owner().ObjectManager()->DeleteObject(&Owner());
  }
}

Component * CreateDialogueComponent(Json::Value value)
{
  return new Dialogue();
}
/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file Graphic.h
\author Connor Deakin
\par E-mail: connor.deakin\@digipen.edu
\par Project: Mecha
\date 06/10/2016
\brief
  Contains the interface for the Graphic class. Look at the Graphic class
  comment for more info.
*/
/*****************************************************************************/

#ifndef GRAPHIC_H
#define GRAPHIC_H

#include <GL\glew.h>

/*****************************************************************************/
/*!
\class Graphic
\brief
  This is the base class for a Graphic. Derived classes can define the vertex
  and element buffers and choose how the Graphic is drawn.

\par Important Notes
  - Make sure to Purge the Graphic instance when it is no longer in use.
  - This is an abstract class. You must derive to use it.
*/
/*****************************************************************************/
class Graphic
{
  public:
    Graphic();
    virtual void Draw() const = 0;
    void PrepBuffer(const GLfloat * vertices, unsigned verticies_size,
                    const GLuint * indices, unsigned indices_size);
    GLint VertexArray() const;
    GLint VertexBuffer() const;
    GLint ElementBuffer() const;
    void Purge();
  protected:
    //! The vertex array OpenGL ID.
    GLuint _vertexArray;
    //! The vertex buffer OpenGL ID.
    GLuint _vertexBuffer;
    //! The element buffer OpenGL ID.
    GLuint _elementBuffer;
};

/*****************************************************************************/
/*!
\class GraphicScreen
\brief
  Graphic that frame buffers are displayed on when rendered to the screen.
*/
/*****************************************************************************/
class GraphicScreen : public Graphic
{
  public:
    GraphicScreen();
    virtual void Draw() const;
};

#endif // !GRAPHIC_H

/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file CharacterController.h
\author Gabe Miller
\par E-mail: g.miller\@digipen.edu
\par Project: Boat Game
\date 10/21/2016 5:14:53 PM
\brief
*/
/*****************************************************************************/
#pragma once

#ifndef CharacterController_H
#define CharacterController_H

#include "Component.h"
#include "Transform.h"
#include "spaceID.h"
#include "Emitter.h"

/*****************************************************************************/
/*!
\class CharacterController
\brief
  

\par
	Operations include:
	-

\deprecated
	-

\bug
	-When traveling in reverse while turning, if the throttle is let off, then 
	the boat will turn in the wrong direction. This is due to the fact that the
	forward speed calculations do not account for the fact that a vector's
	magnitude is never below 0.
*/
/*****************************************************************************/
#include "InputManager.h"

class CharacterController : public Component
{
public:
  void Update();
  CharacterController(std::string engineEvent, SDL_Scancode upKey = SDL_SCANCODE_W, SDL_Scancode downKey = SDL_SCANCODE_S,
    SDL_Scancode leftKey = SDL_SCANCODE_A, SDL_Scancode rightKey = SDL_SCANCODE_D);
  ~CharacterController();
  int GetSpeedSetting();
  void Init();
  void SetHUD(spaceID);
private:
  SDL_Scancode _upKey, _downKey, _leftKey, _rightKey;
  // Input spoofs
  int LRInput();
  int FBInput();

  static bool _autoplay;

  int _speedSetting;
  int rudderInput;
  int throttlePositivity;
  int forwardSpeedPositivity;
  float _rudderAngle;
  bool _upKeyWasDown;
  bool _downKeyWasDown;
  std::string _engineEvent;
  bool _playedEngine;
  spaceID _HUD;

  Transform * _leftEmitterTransform;
  Transform * _rightEmitterTransform;
  Emitter * _leftEmitter;
  Emitter * _rightEmitter;

  bool autoplaykeypressed;

  float _time;



};


Component * CreateCharacterControllerComponent(Json::Value value);

#endif
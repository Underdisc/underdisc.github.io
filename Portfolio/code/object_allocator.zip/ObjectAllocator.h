/*****************************************************************************/
/*!
\file ObjectAllocator.h
\author Connor Deakin
\par E-mail: connortdeakin\@gmail.com
\par Project: ObjectAllocator
\date 28/01/2016
\brief
  Contains the interface used for the ObjectAllocator.
*/
/*****************************************************************************/

//---------------------------------------------------------------------------
#ifndef OBJECTALLOCATORH
#define OBJECTALLOCATORH
//---------------------------------------------------------------------------

// typedef ------------------------------------------------------------------//
namespace
{
  typedef unsigned char byte;
  typedef const unsigned char signature;
}

#include <string>

//! The default number of objects per page.
static const int DEFAULT_OBJECTS_PER_PAGE = 4;
//! The default number of pages.
static const int DEFAULT_MAX_PAGES = 3;

/*****************************************************************************/
/*!
\class OAException
\brief
  This exception type will be thrown from the ObjectAllocator whenever it
  encounters an error.
*/
/*****************************************************************************/
class OAException
{
  public:

/*****************************************************************************/
/*!
\enum OA_EXCEPTION
\brief
  The possible forms of exceptions that can occur within the ObjectAllocator.
*/
/*****************************************************************************/
    enum OA_EXCEPTION
    {
      E_NO_MEMORY,      // operator new fails)
      E_NO_PAGES,       // max pages has been reached
      E_BAD_BOUNDARY,   // block address is not on any block-boundary
      E_MULTIPLE_FREE,  // block has already been freed
      E_CORRUPTED_BLOCK // pad bytes have been overwritten
    };

/*****************************************************************************/
/*!
\brief
  Constructor for an OAException.

\param ErrCode
  The type of error encountered.
\param Message
  A message describing exactly what the error was.
*/
/*****************************************************************************/
    OAException(OA_EXCEPTION ErrCode, const std::string& Message)
    : error_code_(ErrCode), message_(Message) {};

/*****************************************************************************/
/*!
\brief
  OAException destructor.
*/
/*****************************************************************************/
    virtual ~OAException() {
    }

/*****************************************************************************/
/*!
\brief
  Gets the type of error code stored in this OAException.

\return The type of the error code.
*/
/*****************************************************************************/
    OA_EXCEPTION code(void) const {
      return error_code_;
    }

/*****************************************************************************/
/*!
\brief
  Gets the message that was sent with OAException.

\return The message in the OAException.
*/
/*****************************************************************************/
    virtual const char *what(void) const {
      return message_.c_str();
    }
  private:
    //! The error code of the OAException.
    OA_EXCEPTION error_code_;
    //! The specific error that occured.
    std::string message_;
};

/*****************************************************************************/
/*!
\class OAConfig
\brief
  Used to set the configurations for an ObjectAllocator. This is passed into
  the constructor of the ObjectAllocator.
*/
/*****************************************************************************/
struct OAConfig
{
  //! Size of a basic header.
  static const size_t BASIC_HEADER_SIZE = sizeof(unsigned) + 1;
  //! Size of a external header.
  static const size_t EXTERNAL_HEADER_SIZE = sizeof(void*);

/*****************************************************************************/
/*!
\enum HBLOCK_TYPE
\brief
  The types of header blocks that can be used with the ObjectAllocator.
*/
/*****************************************************************************/
  enum HBLOCK_TYPE{hbNone, hbBasic, hbExtended, hbExternal};

/*****************************************************************************/
/*!
\class HeaderBlockInfo
\brief
  Stores information about the header block that used for each block of memory
  in the ObjectAllocator.
*/
/*****************************************************************************/
  struct HeaderBlockInfo
  {
    //! The type of the header block.
    HBLOCK_TYPE type_;
    //! The size (in bytes) of the header block.
    size_t size_;
    //! The number of additional bytes that will be added to the header block.
    size_t additional_;

/*****************************************************************************/
/*!
\brief
  Constructor for the HeaderBlockInfo

\param type
  The type of header that will be used in the ObjectAllocator.
\param additional
  The number of additional bytes that will be added to the block headers.
*/
/*****************************************************************************/
    HeaderBlockInfo(HBLOCK_TYPE type = hbNone, unsigned additional = 0)
    : type_(type), size_(0), additional_(additional)
    {
      if (type_ == hbBasic)
        size_ = BASIC_HEADER_SIZE;
      else if (type_ == hbExtended)
        size_ = sizeof(unsigned int) + sizeof(unsigned short)
              + sizeof(char) + additional_;
      else if (type_ == hbExternal)
        size_ = EXTERNAL_HEADER_SIZE;
    };
  };

/*****************************************************************************/
/*!
\brief
  Constructor for the Object Allocator configurations class.

\param UseCPPMemManager
  This will force the ObjectAllocator to use new and delete instead of using
  the Object Allocators implementation for memory management.
\param ObjectsPerPage
  The number of objects on a single page.
\param MaxPages
  The max number of pages that can be in the ObjectAllocator.
\param DebugOn
  Turns Debugging features on or off.
\param PadBytes
  The number of PadBytes that surround each memory block.
\param HBInfo
  The information needed about the headers blocks for each memory block.
\param Alignment
  The Alignment used for the page.
*/
/*****************************************************************************/
  OAConfig(bool UseCPPMemManager = false,
           unsigned ObjectsPerPage = DEFAULT_OBJECTS_PER_PAGE,
           unsigned MaxPages = DEFAULT_MAX_PAGES,
           bool DebugOn = false,
           unsigned PadBytes = 0,
           const HeaderBlockInfo &HBInfo = HeaderBlockInfo(),
           unsigned Alignment = 0)
           : UseCPPMemManager_(UseCPPMemManager),
             ObjectsPerPage_(ObjectsPerPage),
             MaxPages_(MaxPages),
             DebugOn_(DebugOn),
             PadBytes_(PadBytes),
             HBlockInfo_(HBInfo),
             Alignment_(Alignment)
  {
    HBlockInfo_ = HBInfo;
    LeftAlignSize_ = 0;
    InterAlignSize_ = 0;
  }

  //! By-pass the functionality of the OA and use new/delete.
  bool UseCPPMemManager_;
  //! Number of objects on each page.
  unsigned ObjectsPerPage_;
  //! Maximum number of pages the OA can allocate (0=unlimited).
  unsigned MaxPages_;
  //! Enable/disable debugging code (signatures, checks, etc.).
  bool DebugOn_;
  //! Size of the left/right padding for each block.
  unsigned PadBytes_;
  //! Size of the header for each block (0=no headers).
  HeaderBlockInfo HBlockInfo_;
  //! Address alignment of each block.
  unsigned Alignment_;
  //! Number of alignment bytes required to align first block.
  unsigned LeftAlignSize_;
  //! Number of alignment bytes required between remaining blocks.
  unsigned InterAlignSize_;
};

/*****************************************************************************/
/*!
\class OAStats
\brief
  This is the struct that is used to store all of the stats about the
  Object Allocator while it is in use.
*/
/*****************************************************************************/
struct OAStats
{
  OAStats(void) : ObjectSize_(0), PageSize_(0), FreeObjects_(0),
                  ObjectsInUse_(0), PagesInUse_(0), MostObjects_(0),
                  Allocations_(0), Deallocations_(0) {};

  //! Size of each object.
  size_t ObjectSize_;
  //! Size of a page including all headers, padding, etc.
  size_t PageSize_;
  //! Number of objects on the free list.
  unsigned FreeObjects_;
  //! Number of objects in use by client.
  unsigned ObjectsInUse_;
  //! Number of pages allocated.
  unsigned PagesInUse_;
  //! Most objects in use by client at one time.
  unsigned MostObjects_;
  //! Total requests to allocate memory.
  unsigned Allocations_;
  //! Total requests to free memory.
  unsigned Deallocations_;

};

/*****************************************************************************/
/*!
\class GenericObject
\brief
  Simply allows for easy pointer arithmetic when traversing through the memory
  within the Object Allocator.
*/
/*****************************************************************************/
struct GenericObject
{
  //! A pointer to the next GenericObject in the list.
  GenericObject *Next;
};

/*****************************************************************************/
/*!
\class MemBlockInfo
\brief
  This is the struct used for external headers within ObjectAllocator.
*/
/*****************************************************************************/
struct MemBlockInfo
{
  //! Identifies whether a block of memory is in use or not.
  bool in_use;
  //! A pointer to the label indentifier for a memory block.
  const char *label;
  //! The allocation number of the memory block.
  // When a block is allocated, it's allocation number is the number of
  // allocation that the ObjectAllocator has made.
  unsigned alloc_num;
};

/*****************************************************************************/
/*!
\class ObjectAllocator
\brief
  A memory manager class that provides a more efficient new and free operations
  than the standard new and delete.
*/
/*****************************************************************************/
class ObjectAllocator
{
  public:
    //! A callback function that will dump a memory block
    typedef void (*DUMPCALLBACK)(const void *, size_t);
    //! A callback function that will dump information about a corrupted block.
    typedef void (*VALIDATECALLBACK)(const void *, size_t);
    // Debuging pattern types
    //! Empty data
    static const unsigned char EMPTY_PATTERN = 0x00;
    //! Unallcated block byte values
    static const unsigned char UNALLOCATED_PATTERN = 0xAA;
    //! Allocated block byte values
    static const unsigned char ALLOCATED_PATTERN = 0xBB;
    //! Freed block byte values
    static const unsigned char FREED_PATTERN = 0xCC;
    //! Padding block byte values
    static const unsigned char PAD_PATTERN = 0xDD;
    //! Alignment block byte values
    static const unsigned char ALIGN_PATTERN = 0xEE;

    ObjectAllocator(size_t ObjectSize, const OAConfig& config);
    ~ObjectAllocator();
    void *Allocate(const char *label = 0);
    void Free(void *Object);
    unsigned DumpMemoryInUse(DUMPCALLBACK fn) const;
    unsigned ValidatePages(VALIDATECALLBACK fn) const;
    unsigned FreeEmptyPages(void);
    static bool ImplementedExtraCredit(void);
    void SetDebugState(bool State);
    const void *GetFreeList(void) const;
    const void *GetPageList(void) const;
    OAConfig GetConfig(void) const;
    OAStats GetStats(void) const;

  private:
    //! A pointer to the start of the page list.
    GenericObject *PageList_;
    //! A pointer to the start of the free list.
    GenericObject *FreeList_;
    //! The configurations for the Object Allocator.
    OAConfig Config_;
    //! The stats for the Object Allocator.
    OAStats Stats_;

    void create_page(void);
    GenericObject * alloc_page(void);
    void construct_page(GenericObject * new_page);
    void construct_free_blocks(byte * new_page);
    void construct_pad_blocks(byte * new_page);
    void construct_header_blocks(byte * new_page);
    bool allocated(GenericObject * block) const;
    bool is_allocated_without_header(GenericObject * block) const;
    bool is_allocated_with_header(GenericObject * block) const;
    bool on_boundary(GenericObject * block);
    byte * find_page(byte * block);
    void prep_free_block(byte * block, signature pattern);
    void check_pad_blocks(byte * block) const;
    void allocate_update_header(byte * block, const char * label);
    void deallocate_update_header(byte * block);
    void allocate_update_stats(void);
    void deallocate_update_stats(void);
    void put_on_freelist(GenericObject * block);
    void fill_block(byte * block, signature pattern);
    void free_remaining_external_headers(void);

    // functions should not be used
    ObjectAllocator(const ObjectAllocator &oa);
    ObjectAllocator &operator=(const ObjectAllocator &oa);
};

#endif

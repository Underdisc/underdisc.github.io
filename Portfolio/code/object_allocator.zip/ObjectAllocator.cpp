/*****************************************************************************/
/*!
\file ObjectAllocator.cpp
\author Connor Deakin
\par E-mail: connortdeakin\@gmail.com
\par Project: ObjectAllocator
\date 25/01/2017
\brief
  Contains the implementation of the Object Allocator
*/
/*****************************************************************************/

// include ------------------------------------------------------------------//

#include <cstring>

#include "ObjectAllocator.h"

// typedef - static ---------------------------------------------------------//

namespace
{
  typedef unsigned char byte;
  typedef const unsigned char signature;
  const unsigned pointer_size = sizeof(GenericObject);
}


/*****************************************************************************/
/*!
\brief
  Constructor for the ObjectAllocator. This will initialize off the members
  of the ObjectAllocator to the proper values and allocate the first page of
  memory for the ObjectAllocator.

\param ObjectSize
  The size of the objects (in bytes) that the ObjectAllocator will be used to
  allocate.
\param config
  The configurations that will be used by the ObjectAllocator.
*/
/*****************************************************************************/
ObjectAllocator::ObjectAllocator(size_t ObjectSize, const OAConfig& config)
: PageList_(NULL), FreeList_(NULL), Config_(config)
{
  // Setting up the stats for the object allocator's initial state
  Stats_.ObjectSize_ = ObjectSize;
  // Page Size
  Stats_.PageSize_ = pointer_size // page pointer
                   + ObjectSize * Config_.ObjectsPerPage_ // objects
                   + Config_.PadBytes_ * (Config_.ObjectsPerPage_ * 2) // pads
                   + Config_.HBlockInfo_.size_ * Config_.ObjectsPerPage_;

  Stats_.FreeObjects_ = 0;
  Stats_.PagesInUse_ = 0;
  Stats_.MostObjects_ = 0;
  Stats_.Allocations_ = 0;
  Stats_.Deallocations_ = 0;
  // creating a page if new and delete are not being used.
  if(!Config_.UseCPPMemManager_)
    create_page();
}

/*****************************************************************************/
/*!
\brief
  Frees all of the pages that have been created by the ObjectAllocator.
*/
/*****************************************************************************/
ObjectAllocator::~ObjectAllocator()
{
  if(Config_.HBlockInfo_.type_ == OAConfig::hbExternal)
    free_remaining_external_headers();
  GenericObject * page =  PageList_;
  // free each page in this ObjectAllocator.
  while(page)
  {
    GenericObject * page_to_free = page;
    page = page->Next;
    delete [] reinterpret_cast<byte *>(page_to_free);
  }
}

/*****************************************************************************/
/*!
\brief
  This will allocate a chunk of memory within this ObjectAllocator. The size
  of the block provided will be equivalent to the size constructed with
  the ObjectAllocator when the ObjectAllocator was first created.

\param label
  A pointer to the name of this specific block of memeory.

\return A void pointer to the allocated data.
*/
/*****************************************************************************/
void * ObjectAllocator::Allocate(const char * label)
{
  /*
  // The FreeList_ is nice since it will always be
  // at the head of the free object list, therefore, we can allocate
  // and move to the next pointer in the free list
  // also paying attention to edge case of null
  */
  // USING NEW
  if(Config_.UseCPPMemManager_)
  {
    ++Stats_.Allocations_;
    ++Stats_.ObjectsInUse_;
    if(Stats_.ObjectsInUse_ > Stats_.MostObjects_)
      Stats_.MostObjects_ = Stats_.ObjectsInUse_;
    byte * new_mem = new byte[Stats_.ObjectSize_];
    return reinterpret_cast<void *>(new_mem);
  }

  // USING OA
  // just create a page if there are no free objects left.
  if(!FreeList_)
    // will return exception if max capacity is reached.
    create_page();
  // give the allocated block to the user.
  GenericObject * allocated_block = FreeList_;
  FreeList_ = FreeList_->Next;
  fill_block(reinterpret_cast<byte *>(allocated_block), ALLOCATED_PATTERN);
  // set the header for the block
  allocate_update_stats();
  if(Config_.HBlockInfo_.type_ != OAConfig::hbNone)
    allocate_update_header(reinterpret_cast<byte *>(allocated_block), label);
  // return the new block
  return reinterpret_cast<void *>(allocated_block);
}

/*****************************************************************************/
/*!
\brief
  Deallocates a block within the ObjectAllocator. This will add a Free Object
  to the ObjectAllocator that can be Allocated once again.

\param Object
  A pointer to the block of memory that is being deallocated.
*/
/*****************************************************************************/
void ObjectAllocator::Free(void * Object)
{
  // USING NEW
  if(Config_.UseCPPMemManager_)
  {
    --Stats_.ObjectsInUse_;
    ++Stats_.Deallocations_;
    byte * freed_block = reinterpret_cast<byte *>(Object);
    delete [] freed_block;
    return;
  }
  // USING OA - This will not run if the above runs
  GenericObject * new_free_block = reinterpret_cast<GenericObject *>(Object);
  //Making sure that the pointer is indeed a block
  if(!on_boundary(new_free_block))
  {
    OAException error(OAException::E_BAD_BOUNDARY,
        "Pointer does not point to the start of an object memeory block.");
    throw(error);
  }
  //Making sure that the block is allocated
  if(!allocated(new_free_block))
  {
    OAException error(OAException::E_MULTIPLE_FREE,
      "Block has been freed multiple times.");
      throw(error);
  }
  // checking for pad byte corruptions
  if(Config_.PadBytes_ > 0)
    check_pad_blocks(reinterpret_cast<byte *>(new_free_block));
  //Freeing the block by putting it back on the free list.
  prep_free_block(reinterpret_cast<byte *>(new_free_block), FREED_PATTERN);
  deallocate_update_stats();
  if(Config_.HBlockInfo_.type_ != OAConfig::hbNone)
    deallocate_update_header(reinterpret_cast<byte *>(new_free_block));
}

/*****************************************************************************/
/*!
\brief If there is still memory in use within the ObjectAllocator, this
  function will find those blocks that are in use and use the callback function
  supplied to dump those used memory blocks to screen.

\param fn
  The function that is called when a block that is in use is found.

\return The number of objects that are still in use.
*/
/*****************************************************************************/
unsigned ObjectAllocator::DumpMemoryInUse(DUMPCALLBACK fn) const
{
  GenericObject * page = PageList_;
  while(page)
  {
    byte * memblock = reinterpret_cast<byte *>(page);
    memblock += pointer_size + Config_.HBlockInfo_.size_ + Config_.PadBytes_;
    // checking first clock
    if(allocated(reinterpret_cast<GenericObject *>(memblock)))
      fn(reinterpret_cast<GenericObject *>(memblock), Stats_.ObjectSize_);
    // checking rest of the blocks
    for(size_t block = 0; block < Config_.ObjectsPerPage_ - 1; ++block)
    {
      memblock += Stats_.ObjectSize_
               +  (Config_.PadBytes_ * 2)
               +  Config_.HBlockInfo_.size_;
      if(allocated(reinterpret_cast<GenericObject *>(memblock)))
        fn(reinterpret_cast<GenericObject *>(memblock), Stats_.ObjectSize_);
    }
    page = page->Next;
  }
  return Stats_.ObjectsInUse_;
}

/*****************************************************************************/
/*!
\brief  If called, this function will go through each block of memeory in the
  ObjectAllocator and make sure that the padbytes for that block have not been
  overwritten. Debug mode must be on since the creation of this ObjectAllocator
  in order to use this function.

\param fn
  The call back function that will be used to print out information about
  corrupted blocks of memeory.

\return The number of corrupted blocks found.
*/
/*****************************************************************************/
unsigned ObjectAllocator::ValidatePages(VALIDATECALLBACK fn) const
{
  unsigned num_corruptions = 0;
  GenericObject * page = PageList_;
  while(page)
  {
    byte * memblock = reinterpret_cast<byte *>(page);
    // checking first block
    memblock += pointer_size + Config_.HBlockInfo_.size_ + Config_.PadBytes_;
    try { check_pad_blocks(memblock); }
    catch(const OAException & error)
    {
      fn(reinterpret_cast<GenericObject *>(memblock), Stats_.ObjectSize_);
      ++num_corruptions;
    }
    // checking remainder of blocks in the page
    for(size_t block = 0; block < Config_.ObjectsPerPage_ - 1; ++block)
    {
      memblock += Stats_.ObjectSize_
               +  (Config_.PadBytes_ * 2)
               +  Config_.HBlockInfo_.size_;
      try { check_pad_blocks(memblock); }
      catch(const OAException & error)
      {
        fn(reinterpret_cast<GenericObject *>(memblock), Stats_.ObjectSize_);
        ++num_corruptions;
      }
    }
    page = page->Next;
  }
  return num_corruptions;
}

/*****************************************************************************/
/*!
\brief
  Unimplemented.

\return Unimplemented.
*/
/*****************************************************************************/
unsigned ObjectAllocator::FreeEmptyPages(void)
{
  return 0;
}

/*****************************************************************************/
/*!
\brief
  Uhhh, I think I am ok for now.

\return no
*/
/*****************************************************************************/
bool ObjectAllocator::ImplementedExtraCredit(void)
{
  return false;
}

/*****************************************************************************/
/*!
\brief
  Turns Debug features on or off within the ObjectAllocator.

\param State
  The new Debuging state. True will turn the features on. False will turn them
  off
*/
/*****************************************************************************/
void ObjectAllocator::SetDebugState(bool State)
{
  Config_.DebugOn_ = State;
}

/*****************************************************************************/
/*!
\brief
  Returns a pointer to the start of the ObjectAllocator's free list.

\return A pointer to the start of the free list.
*/
/*****************************************************************************/
const void * ObjectAllocator::GetFreeList(void) const
{
  return FreeList_;
}

/*****************************************************************************/
/*!
\brief
  Gets the pointer to the start of the page list.

\return A pointer to the start of the page list.
*/
/*****************************************************************************/
const void * ObjectAllocator::GetPageList(void) const
{
  return PageList_;
}

/*****************************************************************************/
/*!
\brief
  Gets the current config of the ObjectAllocator.

\return The ObjectAllocator's current configurations.
*/
/*****************************************************************************/
OAConfig ObjectAllocator::GetConfig(void) const
{
  return Config_;
}

/*****************************************************************************/
/*!
\brief
  Gets the current stats of the ObjectAllocator.

\return The ObjectAllocator's stats.
*/
/*****************************************************************************/
OAStats ObjectAllocator::GetStats(void) const
{
  return Stats_;
}

/*****************************************************************************/
/*!
\brief
  Creates a new page that can be used by the ObjectAllocator.
  This will throw an exception if there is not enough memory left for another
  page. An exceptions ll also be thrown if new fails.
*/
/*****************************************************************************/
void ObjectAllocator::create_page(void)
{
  if(Config_.MaxPages_ == 0 || Stats_.PagesInUse_ != Config_.MaxPages_)
  {
    //create a new page
    GenericObject * new_page = alloc_page();
    new_page->Next = PageList_;
    PageList_ = new_page;
    // since we are performing a reinterpret_cast on the byte data, that data
    // is percieved as a GenericObject.
    // So when we say (TheGenericObject->Next), we are referring to the pointer
    // that is at the start of that data.
    construct_page(new_page);
    Stats_.PagesInUse_ += 1;
  }
  else
  {
    // no more pages can be created
    OAException error(OAException::E_NO_PAGES, "Max number of pages reached.");
    throw(error);
  }
}

/*****************************************************************************/
/*!
\brief
  Allocates a new page with the new operator.

\return A GenericObject pointer to the start of the newly allocated page.
*/
/*****************************************************************************/
inline GenericObject * ObjectAllocator::alloc_page(void)
{
  try
  {
    // allocating new page
    byte * page_data = new byte[Stats_.PageSize_];
    GenericObject * new_page = reinterpret_cast<GenericObject *>(page_data);
    return new_page;
  }
  catch(std::bad_alloc& mem_error)
  {
    // not enough memory for new page
    OAException error(OAException::E_NO_MEMORY, "new operator failed.");
    throw(error);
  }
}

/*****************************************************************************/
/*!
\brief
  Constructs a new page that can be used and manipulated by the ObjectAllocator.

\param new_page
  The page that has just been allocated.
*/
/*****************************************************************************/
void ObjectAllocator::construct_page(GenericObject * new_page)
{
  construct_free_blocks(reinterpret_cast<byte *>(new_page));

  if(Config_.PadBytes_ > 0)
    construct_pad_blocks(reinterpret_cast<byte *>(new_page));

  // constructing the header blocks if they exist
  if(Config_.HBlockInfo_.type_ != OAConfig::hbNone)
    construct_header_blocks(reinterpret_cast<byte *>(new_page));
}

/*****************************************************************************/
/*!
\brief
  Constructs all of the free blocks in a newly allocated page by adding all
  the free blocks to the free list.

\param new_page
  A pointer to the start of the new page.
*/
/*****************************************************************************/
void ObjectAllocator::construct_free_blocks(byte * new_page)
{
  new_page += pointer_size
           + Config_.PadBytes_
           + Config_.HBlockInfo_.size_;
  // setting all free block pointers to point to the previous free block.
  for(unsigned object = 0; object < Config_.ObjectsPerPage_ - 1; ++object)
  {
    // prepping the free block
    prep_free_block(new_page, UNALLOCATED_PATTERN);
    new_page += Stats_.ObjectSize_
             + Config_.PadBytes_ * 2
             + Config_.HBlockInfo_.size_;
  }
  // prepping the last block
  prep_free_block(new_page, UNALLOCATED_PATTERN);
  Stats_.FreeObjects_ += Config_.ObjectsPerPage_;
}

/*****************************************************************************/
/*!
\brief
  Constructs all of the Pad blocks within a newly allocated page.

\param new_page
  A pointer to the start of a newly allocated page.
*/
/*****************************************************************************/
void ObjectAllocator::construct_pad_blocks(byte * new_page)
{
  new_page += pointer_size
           +  Config_.HBlockInfo_.size_;
  fill_block(new_page, PAD_PATTERN);
  new_page += Config_.PadBytes_;
  for(unsigned object = 0; object < Config_.ObjectsPerPage_ - 1; ++object)
  {
    new_page += Stats_.ObjectSize_;
    fill_block(new_page, PAD_PATTERN);
    new_page += Config_.PadBytes_
             + Config_.HBlockInfo_.size_;
    fill_block(new_page, PAD_PATTERN);
    new_page += Config_.PadBytes_;
  }
  new_page += Stats_.ObjectSize_;
  fill_block(new_page, PAD_PATTERN);
}

/*****************************************************************************/
/*!
\brief
  This will construct the header blocks for a page by setting all the values\
  in each header block to zero.

\param new_page
  The new_page that has just been allocated.
*/
/*****************************************************************************/
void ObjectAllocator::construct_header_blocks(byte * new_page)
{
   new_page += pointer_size;
   for(unsigned object = 0; object < Config_.ObjectsPerPage_ - 1; ++object)
   {
     // setting all the values in block to zero
     memset(new_page, EMPTY_PATTERN, Config_.HBlockInfo_.size_);
     // moving to next block
     new_page += Config_.HBlockInfo_.size_
              +  Config_.PadBytes_ * 2
              +  Stats_ .ObjectSize_;
   }
   memset(new_page, EMPTY_PATTERN, Config_.HBlockInfo_.size_);
}
/*****************************************************************************/
/*!
\brief
  This checks to see if a block is currently allocated. This will only happen
  if Debug features are on. If Debug features are off, this will automatically
  assume that the block is allocated. This will also assume that the given
  block is on the correct boundary.

\param block
  The block the function will identify as allocated or not.

\return If the block is allocated, true. If the block is free, false.
*/
/*****************************************************************************/
bool ObjectAllocator::allocated(GenericObject * block) const
{
  if(Config_.DebugOn_)
  {
    if(Config_.HBlockInfo_.type_ == OAConfig::hbNone)
      return is_allocated_without_header(block);
    else
      return is_allocated_with_header(block);
  }
  // automatically assume block is allocated
  return true;
}

/*****************************************************************************/
/*!
\brief
  Finds out if a block of memory is free or not when headers do not exist
  within the memory pages.

\param block
  A pointer to the block of memory that the function will search to see if it
  is allocated or not.

\return If the block is currently allocated, true. If the block isn't
  allocated, false.
*/
/*****************************************************************************/
inline bool ObjectAllocator::is_allocated_without_header(GenericObject * block)
const
{
  GenericObject * free_block = FreeList_;
  // checking all the blocks in the freelist.
  while(free_block)
  {
    if(free_block == block)
      return false;
    free_block = free_block->Next;
  }
  return true;
}

/*****************************************************************************/
/*!
\brief
  This will find out whether a block is allocated or not using the headers
  that are currently built into the pages. This should not be valid, if
  the blocks do not have headers.

\param block
  The block that is being checked for allocation.

\return If the block is currently allocated, true. If not, false.
*/
/*****************************************************************************/
inline bool ObjectAllocator::is_allocated_with_header(GenericObject * block)
const
{
  if(Config_.HBlockInfo_.type_ == OAConfig::hbExternal)
  {
    --block;
    MemBlockInfo * block_info = *(reinterpret_cast<MemBlockInfo **>(block));
    // The pointer exists, therefore the block must exist since, the pointer
    // gets set to zeros on deallocation
    if(block_info)
      return true;
  }
  else
  {
    byte * flag = reinterpret_cast<byte *>(block);
    // move to flag
    --flag;
    if(*flag)
      return true;
  }
  return false;
}

/*****************************************************************************/
/*!
\brief
  Tests to see if a pointer is on a block boundary. Essentially, checking that
  a block is indeed a block.

\param block
  The pointer that the function will use to determine if the pointer is on a
  block boundary or not.


\return If the pointer is on a block boundary, true. If it is not, false.
*/
/*****************************************************************************/
bool ObjectAllocator::on_boundary(GenericObject * block)
{
  if(Config_.DebugOn_)
  {
    // get the page the block is on
    byte * page = find_page(reinterpret_cast<byte *>(block));
    if(!page)
      return false;
    // go to the first block on the page
    page += pointer_size
         + Config_.PadBytes_
         + Config_.HBlockInfo_.size_;
    // see if the block is on the right boundary
    long distance = reinterpret_cast<byte *>(block) - page;
    long spacing = Stats_.ObjectSize_
                 + Config_.PadBytes_ * 2
                 + Config_.HBlockInfo_.size_;
    if(distance % spacing == 0)
      return true;
    return false;
  }
  return true;
}

/*****************************************************************************/
/*!
\brief
  Finds the page that a pointer to a memory block exists on.

\param block_byte
  The block of memeory whose page is being searched for.

\return A pointer to the page that the memory block was found on.
*/
/*****************************************************************************/
byte * ObjectAllocator::find_page(byte * block_byte)
{
  GenericObject * page = PageList_;
  // moving through whole page list.
  while(page)
  {
    byte * page_byte = reinterpret_cast<byte *>(page);
    size_t distance = block_byte - page_byte;
    // seeing if the block is on the page by
    // using the differernce between the block pointer and
    // the page start pointer.
    if(distance < Stats_.PageSize_)
      return page_byte;
    page = page->Next;
  }
  return NULL;
}

//TODO: This should be removed
/*****************************************************************************/
/*!
\brief
  This functinon pepares a free block of memory by adding it to the freelist.
  If the debug features are on, this function will also initialize all of the
  data besides the pointer within the free memory block to the pattern provided.

\param block
  The block of memory to be preppared for later allocation.
\param pattern
  This is the pattern the block will be filled with if debug features are on.
*/
/*****************************************************************************/
void ObjectAllocator::prep_free_block(byte * block, signature pattern)
{
  // adding the memory block to the FreeList_
  put_on_freelist(reinterpret_cast<GenericObject *>(block));
  // initializing the memory block if debug features are on.
  fill_block(block, pattern);
}

/*****************************************************************************/
/*!
\brief
  Adds a memory block to the FreeList_.

\param block
  A pointer to the block that is to be added to the FreeList_.
*/
/*****************************************************************************/
void ObjectAllocator::put_on_freelist(GenericObject * block)
{
  block->Next = FreeList_;
  FreeList_ = block;
}

/*****************************************************************************/
/*!
\brief
  Fills a block with a signature when debug mode is on. Blocks will not
  be filled with these pattern types when the debug mode is off.

\param block
  The block to be filled.
\param pattern
  The byte pattern the block will be filled with.
*/
/*****************************************************************************/
void ObjectAllocator::fill_block(byte * block, signature pattern)
{
  if(Config_.DebugOn_)
  {
    size_t bytes_to_fill = 0;
    // unallocated and freed
    if(pattern == UNALLOCATED_PATTERN || pattern == FREED_PATTERN)
    {
      block += pointer_size;
      bytes_to_fill = Stats_.ObjectSize_ - pointer_size;
    }
    // allocated
    else if(pattern == ALLOCATED_PATTERN)
      bytes_to_fill = Stats_.ObjectSize_;
    // pad
    else if(pattern == PAD_PATTERN)
      bytes_to_fill = Config_.PadBytes_;
    memset(block, pattern, bytes_to_fill);
  }
} // TODO: REMOVE FOR EFFICIENCY

/*****************************************************************************/
/*!
\brief
  Given a pointer to a block of memory that has just been freed by the user,
  this function will go to the left and right pad bytes of the block to make
  sure that the user has not overwritten them. This will only be ran if
  Debug mode is on. Only in debug mode will pad bytes be initialized. If a pad
  byte was overwritten, an exception will be thrown.

\param freed_block
  The block of memeory that has just been freed.
*/
/*****************************************************************************/
void ObjectAllocator::check_pad_blocks(byte * block) const
{
  // Only operates if debug features are on.
  if(Config_.DebugOn_)
  {
    //check left of block
    for(size_t cur_byte = 0; cur_byte < Config_.PadBytes_; ++cur_byte)
    {
      --block;
      if(*block != PAD_PATTERN)
      {
        OAException error(OAException::E_CORRUPTED_BLOCK,
            "Left side of memory block has been corrupted.");
        throw(error);
      }
    }
    // check right side of block.
    block += (Config_.PadBytes_ * 2) + Stats_.ObjectSize_;
    for(size_t cur_byte = 0; cur_byte < Config_.PadBytes_; ++cur_byte)
    {
      --block;
      if(*block != PAD_PATTERN)
      {
        OAException error(OAException::E_CORRUPTED_BLOCK,
            "Right side of memory block has been corrupted.");
        throw(error);
      }
    }
  }
}

/*****************************************************************************/
/*!
\brief
  This will update the header for a block when the block is allocated.

\param block
  The block that has been allocated.
\param label
  The null terminated string that will be used to give the memory block a name.
  This lable will only be used if an external header is being used.
*/
/*****************************************************************************/
void ObjectAllocator::allocate_update_header(byte * block, const char * label)
{
  // EXTERNAL HEADER TYPE
  if(Config_.HBlockInfo_.type_ == OAConfig::hbExternal)
  {
    block -= (Config_.PadBytes_ + Config_.HBlockInfo_.size_);
    // allocating and storing external header
    MemBlockInfo * block_info = new MemBlockInfo;
    *(reinterpret_cast<MemBlockInfo **>(block)) = block_info;
    // initialize values in external header
    block_info->in_use = true;
    block_info->label = label;
    block_info->alloc_num = Stats_.Allocations_;
  }
  // OTHER HEADER TYPES
  else if (Config_.HBlockInfo_.type_ != OAConfig::hbNone)
  {
    // function for both basic and Extended blocks.
    //size_t offset = sizeof(byte) + Config_.PadBytes_;
    block -= (sizeof(byte) + Config_.PadBytes_);
    // setting the allocated flag
    *block = 1;
    block -= sizeof(unsigned);
    // setting the total allocations value.
    *(reinterpret_cast<unsigned *>(block)) = Stats_.Allocations_;

    // purely for Extended blocks
    if(Config_.HBlockInfo_.type_ == OAConfig::hbExtended)
    {
      // adding one to the allocation counter
      block -= sizeof(unsigned short);
      ++(*(reinterpret_cast<unsigned short *>(block)));
    }
  }
}

/*****************************************************************************/
/*!
\brief
  This will update the header for a block when the block is deallocated.

\param block
  The block that has been deallocated.
*/
/*****************************************************************************/
void ObjectAllocator::deallocate_update_header(byte * block)
{
  // EXTERNAL HEADER TYPE
  if(Config_.HBlockInfo_.type_ == OAConfig::hbExternal)
  {
    block -= (Config_.PadBytes_ + Config_.HBlockInfo_.size_);
    // freeing the memory block
    MemBlockInfo * block_info = *(reinterpret_cast<MemBlockInfo **>(block));
    delete block_info;
    // setting all the values to zero in the block header
    memset(block, EMPTY_PATTERN, Config_.HBlockInfo_.size_);
  }
  // OTHER HEADER TYPE
  else
  {
    // clearing basic block
    size_t basic_size = sizeof(byte) + sizeof(unsigned);
    block -= (Config_.PadBytes_ + basic_size);
    memset(block, EMPTY_PATTERN, basic_size);

    // clearing user header memory
    if(Config_.HBlockInfo_.type_ == OAConfig::hbExtended)
    {
      block -= (sizeof(unsigned short) + Config_.HBlockInfo_.additional_);
      memset(block, EMPTY_PATTERN, Config_.HBlockInfo_.additional_);
    }
  }
}

/*****************************************************************************/
/*!
\brief
  When a user allocates a new block of data, this function is called in order
  to update the stats of the ObjectAllocator that need to be updated after
  an allocation.
*/
/*****************************************************************************/
inline void ObjectAllocator::allocate_update_stats(void)
{
  ++Stats_.Allocations_;
  ++Stats_.ObjectsInUse_;
  if(Stats_.ObjectsInUse_ > Stats_.MostObjects_)
    Stats_.MostObjects_ = Stats_.ObjectsInUse_;
  --Stats_.FreeObjects_;
}

/*****************************************************************************/
/*!
\brief
  This will update all the ObjectAllocator stats that need to be updated
  when the client performs a single deallocation.
*/
/*****************************************************************************/
inline void ObjectAllocator::deallocate_update_stats(void)
{
  ++Stats_.Deallocations_;
  ++Stats_.FreeObjects_;
  --Stats_.ObjectsInUse_;
}

/*****************************************************************************/
/*!
\brief
  When the ObjectAllocator is destroyed by the destructor, there is a chance,
  that the user did not free all the memory in the OA. This is a major
  problem if external header blocks are being used, because that data needs to
  be freed. This function will run during the destructor if the external header
  blocks are being used for this reason.
*/
/*****************************************************************************/
void ObjectAllocator::free_remaining_external_headers(void)
{
  GenericObject * page = PageList_;
  // checking headers on all pages.
  while(page)
  {
    byte * data = reinterpret_cast<byte *>(PageList_);
    MemBlockInfo * block_info;

    // moving to first header
    data += pointer_size;
    // checking first header
    block_info = *(reinterpret_cast<MemBlockInfo **>(data));
    if(block_info)
      delete block_info;
    for(unsigned object = 0; object < Config_.ObjectsPerPage_ -1; ++object)
    {
      // moving to next header
      data += Config_.HBlockInfo_.size_
           +  (Config_.PadBytes_ * 2)
           +  Stats_.ObjectSize_;
      // checking that the header has been freed.
      block_info = *(reinterpret_cast<MemBlockInfo **>(data));
      if(block_info)
        delete block_info;
    }
    page = page->Next;
  }
}

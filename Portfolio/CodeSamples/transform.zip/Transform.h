/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file Transform.h
\author Connor Deakin
\par E-mail: connor.deakin\@digipen.edu
\par Project: Graphics
\date 06/03/2017
\brief
  Contains the interface for the Transform class. Look at the Transform class
  comment for more information.
*/
/*****************************************************************************/
#ifndef TRANSFORM_H
#define TRANSFORM_H

#include <vector>

#include <GLM/glm/vec3.hpp>
#include <GLM/glm/mat4x4.hpp>

/*****************************************************************************/
/*!
\class Transform
\brief
  Used to compute and store an affine transformation that scales, rotates, and
  translates a homogenous coordinate to a new position.

\par Important Notes
  - Transform's can have parents. If a Transform has a parent, the parent's
    affine transformation will be applied to this transformation.
*/
/*****************************************************************************/
class Transform
{
  private:
    //! Transform proxy class for Transform's Scale.
    // Use Transform::Scale() to set, get and apply change in Transform scale.
    class TransformPS
    {
      public:
        TransformPS(Transform * transform);
        operator glm::vec3() const;
        Transform & operator=(const glm::vec3 & new_scale);
        Transform & operator+=(const glm::vec3 & delta_scale);
        Transform & operator=(float new_scale);
        Transform & operator+=(float delta_scale);
      private:
        //! The Transform this proxy will modify or use.
        Transform * _transform;
    };
    //! Transform proxy class for Transform's Rotation.
    // Use Transform::Rotation() to set and get a Transform's rotation.
    class TransformPR
    {
      public:
        TransformPR(Transform * transform);
        operator float() const;
        Transform & operator=(float new_rotation);
        Transform & operator+=(float delta_rotation);
      private:
        //! The Transform this proxy will modify or use.
        Transform * _transform;
    };
    //! Transform proxy class for Transform's Translation.
    // Use Transform::Translation() to set and get a Transform's translation.
    class TransformPT
    {
      public:
        TransformPT(Transform * transform);
        operator glm::vec3() const;
        Transform & operator=(const glm::vec3 & new_translation);
        Transform & operator+=(const glm::vec3 & delta_translation);
      private:
        //! The Transform this proxy will modify or use.
        Transform * _transform;
    };
  public:
    Transform();
    Transform(Transform * parent);
    float Z() const;
    bool Moved() const;
    const glm::vec3 & GetScale() const;
    float GetRotation() const;
    float GetAbsoluteRotation() const;
    const glm::vec3 & GetTranslation() const;
    glm::vec3 GetAbsoluteTranslation() const;
    void SetScale(const glm::vec3 & new_scale);
    void SetScale(float new_scale);
    void SetRotation(float new_rotation);
    void SetTranslation(const glm::vec3 & new_translation);
    void ChangeInScale(const glm::vec3 & delta_scale);
    void ChangeInScale(float delta_scale);
    void ChangeInRotation(float delta_rotation);
    void ChangeInTranslation(const glm::vec3 & delta_translation);
    TransformPS Scale();
    TransformPR Rotation();
    TransformPT Translation();
    void ChangeParent(Transform * new_parent);
    void AddChild(Transform * new_child);
    void RemoveChild(Transform * child);
    const glm::mat4 & ObjectToWorld();
  private:
    bool _moved;
    //! Tracks whether the stored transform matrix is updated with the proper
    // scale, rotate, and translate values.
    bool _updated;
    //! The scaler values applied to each value of the point.
    glm::vec3 _scale;
    //! The rotation of the point around the origin.
    float _rotation;
    //! The translation of the point from it's current location.
    glm::vec3 _translation;
    //! The calculated affine transformation.
    glm::mat4 _transform;
    //! The parent Transform of this Transform.
    Transform * _parent;
    //! All of the children that this Transform is a parent of.
    std::vector<Transform *> _children;
    void UpdateTranformation();
    void ChildrenModified();
};

#endif // !TRANSFORM_H
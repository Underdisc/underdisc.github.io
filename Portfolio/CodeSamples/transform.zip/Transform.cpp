/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file Transform.cpp
\author Connor Deakin
\par E-mail: connor.deakin\@digipen.edu
\par Project: Graphics
\date 06/03/2017
\brief
  Contains the implementation of the Transform class. Look in Transform.h for
  more information.
*/
/*****************************************************************************/

#include <GLM\glm\gtc\matrix_transform.hpp>

#include "Error.h"

#include "Transform.h"

/*****************************************************************************/
/*!
\brief
  Creates a Transform proxy for a Transform's Scale value.

\param transform
  The Transform whose scale is being modified.
*/
/*****************************************************************************/
Transform::TransformPS::TransformPS(Transform * transform) :
_transform(transform) 
{}

/*!
\brief Converts the proxy to the Transform's scale value.
\return The Transform's scale.
*/
Transform::TransformPS::operator glm::vec3() const
{
  return _transform->_scale;
}

/*!
\brief Set the Transform's scale through the proxy.
\param new_scale The Transform's new scale.
*/
Transform & Transform::TransformPS::operator=(const glm::vec3 & new_scale)
{
  _transform->SetScale(new_scale);
  return *_transform;
}

/*!
\brief Add a value to the Transform's scale through the proxy.
\param delta_scale The change in the Transform's scale.
*/
Transform & Transform::TransformPS::operator+=(const glm::vec3 & delta_scale)
{
  _transform->ChangeInScale(delta_scale);
  return *_transform;
}

/*!
\brief Set the Transform's uniform scale through the proxy.
\param new_scale The Transform's new uniform scale.
*/
Transform & Transform::TransformPS::operator=(float new_scale)
{
  _transform->SetScale(new_scale);
  return *_transform;
}

/*!
\brief Add a uniform scale to the Transform's scale through the proxy.
\param delta_scale The uniform change in the Transform's scale.
*/
Transform & Transform::TransformPS::operator+=(float delta_scale)
{
  _transform->ChangeInScale(delta_scale);
  return *_transform;
}

/*****************************************************************************/
/*!
\brief
  Creates a Transform proxy for a Transform's rotation value.

\param transform
  The Transform whose rotation is being modified.
*/
/*****************************************************************************/
Transform::TransformPR::TransformPR(Transform * transform) :
_transform(transform)
{}

/*!
\brief Converts the proxy to the Transform's rotation value.
\return The Transform's rotation.
*/
Transform::TransformPR::operator float() const
{
  return _transform->_rotation;
}

/*!
\brief Set the Transform's rotation through the proxy.
\param new_rotation The Transform's new rotation.
*/
Transform & Transform::TransformPR::operator=(float new_rotation)
{
  _transform->SetRotation(new_rotation);
  return *_transform;
}

/*!
\brief Add a value to the Transform's rotation through the proxy.
\param delta_rotation The change in the Transform's rotation.
*/
Transform & Transform::TransformPR::operator+=(float delta_rotation)
{
  _transform->ChangeInRotation(delta_rotation);
  return *_transform;
}

/*****************************************************************************/
/*!
\brief
 Creates a Transform proxy for a Transform's translation value.

\param transform
 The Transform whose translation is being modified.
*/
/*****************************************************************************/
Transform::TransformPT::TransformPT(Transform * transform) :
_transform(transform)
{}

/*!
\brief Converts the proxy to the Transform's translation value.
\return The Transform's translation.
*/
Transform::TransformPT::operator glm::vec3() const
{
  return _transform->_translation;
}

/*!
\brief Set the Transform's translation through the proxy.
\param new_translation The Transform's new translation.
*/
Transform & Transform::TransformPT::operator=(const glm::vec3 & new_translation)
{
  _transform->SetTranslation(new_translation);
  return *_transform;
}

/*!
\brief Add a value to the Transform's translation through the proxy.
\param delta_translationThe change in the Transform's translation.
*/
Transform & Transform::TransformPT::operator+=(const glm::vec3 & delta_translation)
{
  _transform->ChangeInTranslation(delta_translation);
  return *_transform;
}


/*!
\brief Contstructs an affine transformation that has no effect when applied to
  a point.
*/
Transform::Transform() : 
_updated(true), _scale(1.0f, 1.0f, 1.0f), _rotation(0.0f), 
_translation(0.0f, 0.0f, 0.0f), _parent(nullptr)
{}

/*****************************************************************************/
/*!
\brief Contstructs an affine transformation that has no effect when applied to
a point.

\param parent
  The Transform instance that this Transform is a child of. The parent's affine
  transformation will be applied to this affine transformation.
*/
/*****************************************************************************/
Transform::Transform(Transform * parent) :
_moved(false), _updated(true), _scale(1.0f, 1.0f, 1.0f), _rotation(0.0f),
_translation(0.0f, 0.0f, 0.0f), _parent(nullptr)
{
  ChangeParent(parent);
}

/*!
\brief Returns the Z coordinate of the Transform.
\return The Z coordinate of the Transform.
*/
float Transform::Z() const
{
  return _translation.z;
}

/*!
\brief Tells if the Transform has been updated since the previous matrix update.
\return If the Transform has moved, true, else false.
*/
bool Transform::Moved() const
{
  return _moved;
}

/*!
\brief Gets the Transform's scale.
\return The Transform's scale.
*/
const glm::vec3 & Transform::GetScale() const
{
  return _scale;
}

/*!
\brief Gets the Transform's rotation in radians.
\return The Transform's rotation in radians.
*/
float Transform::GetRotation() const 
{
  return _rotation;
}

/*
\brief Gets the absolute rotation of this transformation.
\return The absolute rotation of this transformation.
*/
float Transform::GetAbsoluteRotation() const
{
  float final_rot = _rotation;
  Transform * upper_parent = _parent;
  while (upper_parent) {
    final_rot += upper_parent->_rotation;
    upper_parent = upper_parent->_parent;
  }
  return final_rot;
}

/*!
\brief Gets the Transform's translation.
\return The Transform's translation.
*/
const glm::vec3 & Transform::GetTranslation() const 
{
  return _translation;
}

/*!
\brief Gets the Transform's absolute translation.
\return The Transform's absolute translation.
*/
glm::vec3 Transform::GetAbsoluteTranslation() const
{
  glm::vec4 result(_translation.x, _translation.y, _translation.z, 1.0f);
  if (_parent)
    result = _parent->ObjectToWorld() * result;
  return glm::vec3(result.x, result.y, result.z);
}

/*!
\brief Sets the Transform's scale.
\param new_scale The Transform's new scale.
*/
void Transform::SetScale(const glm::vec3 & new_scale)
{
  _scale = new_scale;
  // changed
  _updated = false;
  _moved = true;
  ChildrenModified();
}

/*****************************************************************************/
/*!
\brief
  Sets the Transform's scale by using the same value for all three
  scale values.

\param new_scale
  The new uniform scaling value.
*/
/*****************************************************************************/
void Transform::SetScale(float new_scale)
{
  _scale = glm::vec3(new_scale, new_scale, new_scale);
  // changed
  _updated = false;
  _moved = true;
  ChildrenModified();
}

/*!
\brief Sets the Transform's rotation in radians.
\param new_rotation The Transform's new rotation in radians.
*/
void Transform::SetRotation(float new_rotation)
{
  _rotation = new_rotation;
  // changed
  _updated = false;
  _moved = true;
  ChildrenModified();
}

/*!
\brief Sets the Transform's translation.
\param new_translation The Transform's new translation.
*/
void Transform::SetTranslation(const glm::vec3 & new_translation)
{
  _translation = new_translation;
  _transform[3].x = new_translation.x;
  _transform[3].y = new_translation.y;
  _transform[3].z = new_translation.z;
  // only children need update
  _moved = true;
  ChildrenModified();
}

/*!
\brief Adds a given change in scale to the Transform's current scale.
\param delta_scale The change in scale.
*/
void Transform::ChangeInScale(const glm::vec3 & delta_scale)
{
  _scale += delta_scale;
  // all changed
  _updated = false;
  _moved = true;
  ChildrenModified();
}

/*****************************************************************************/
/*!
\brief
  Adds the same change in scale to each of the Transform's scale values.

\param delta_scale
  The uniform change in scale.
*/
/*****************************************************************************/
void Transform::ChangeInScale(float delta_scale)
{
  _scale += glm::vec3(delta_scale, delta_scale, delta_scale);
  // all changed
  _updated = false;
  _moved = true;
  ChildrenModified();
}

/*!
\brief Adds a given change in rotation to the Transform's current 
  rotation in radians.
\param delta_rotation The change in rotation in radians.
*/
void Transform::ChangeInRotation(float delta_rotation)
{
  _rotation += delta_rotation;
  // all changed
  _updated = false;
  _moved = true;
  ChildrenModified();
}

/*!
\brief Adds a given change in translation to the Transform's 
  current translation.
\param delta_translation The change in translation.
*/
void Transform::ChangeInTranslation(const glm::vec3 & delta_translation)
{
  _translation += delta_translation;
  _transform[3].x += delta_translation.x;
  _transform[3].y += delta_translation.y;
  _transform[3].z += delta_translation.z;
  // only children changed
  _moved = true;
  ChildrenModified();
}

/*!
\brief Allows use the = and += operator with Transform::Scale().
\return A proxy for the Transform's scale value.
*/
Transform::TransformPS Transform::Scale()
{
  return TransformPS(this);
}

/*!
\brief Allows use the = and += operator with Transform::Rotation().
\return A proxy for the Transform's scale value.
*/
Transform::TransformPR Transform::Rotation()
{
  return TransformPR(this);
}

/*!
\brief Allows use the = and += operator with Transform::Translation().
\return A proxy for the Transform's translation value.
*/
Transform::TransformPT Transform::Translation()
{
  return TransformPT(this);
}

/*****************************************************************************/
/*!
\brief
  Change this Transform's parent to a different Transform.

\par Important Notes
  - Use nullptr for the new_parent to remove the parent.

\param new_parent
  The new parent that this Transform will become a child of.
*/
/*****************************************************************************/
void Transform::ChangeParent(Transform * new_parent)
{
  // make sure that this transform does not have a parent
  // relationship with self
  Transform * upper_parent = new_parent;
  while (upper_parent) {
    if (upper_parent == this) {
      Error error("Transform.cpp", "ChangeParent");
      error.Add("Infinite parent loop created by this relationship.");
      throw(error);
    }
    upper_parent = upper_parent->_parent;
  }
  // set new parent
  if (_parent)
    _parent->RemoveChild(this);
  _parent = new_parent;
  // add child to parent
  _parent->_children.push_back(this);
  _updated = false;
  _moved = true;
}

/*****************************************************************************/
/*!
\brief
  Add a child Transform to this Transform.

\param new_child
  The Transform that will become a child of this Transform.
*/
/*****************************************************************************/
void Transform::AddChild(Transform * new_child) 
{
  new_child->ChangeParent(this);
}

/*****************************************************************************/
/*!
\brief
  Remove a child from the this Transform.

\param child
  The child that will be no longer be parented to this Transform.
*/
/*****************************************************************************/
void Transform::RemoveChild(Transform * child)
{
  // find child and erase
  std::vector<Transform *>::iterator it = _children.begin();
  std::vector<Transform *>::iterator it_e = _children.end();
  for (; it != it_e; ++it){
    if (*it == child) {
      (*it)->_parent = nullptr;
      (*it)->_updated = false;
      (*it)->_moved = true;
      _children.erase(it);
      return;
    }
  }
  // child not found
  Error error("Transform.cpp", "RemoveChild");
  error.Add("Child Transform pointer not found in this Transform's children.");
  throw(error);
}


/*****************************************************************************/
/*!
\brief
  Returns the affine transformation (object to world) matrix that was
  calculated using the scale, rotate, and translate values given.

\return The affine transformation.
*/
/*****************************************************************************/
const glm::mat4 & Transform::ObjectToWorld()
{
  if (!_updated)
    UpdateTranformation();
  return _transform;
}

/*****************************************************************************/
/*!
\brief
  When the user requests the transformation, it may not be the proper matrix.
  If it is not, this function will be used to update the transformation so the
  user has the correct transformation.
*/
/*****************************************************************************/
void Transform::UpdateTranformation()
{
  // applying any parent transformation.
  // note the parent transform will also update if needed.
  if (_parent)
    _transform = _parent->ObjectToWorld();
  else
    _transform = glm::mat4();
  _transform = glm::translate(_transform, _translation);
  _transform = glm::rotate(_transform, _rotation, glm::vec3(0.0f, 0.0f, 1.0f));
  _transform = glm::scale(_transform, _scale);
  _updated = true;
  _moved = false;
}

/*****************************************************************************/
/*!
\brief
  Will tell all of the Child transforms that they must be updated when their
  Transform matrix is fetched.
*/
/*****************************************************************************/
void Transform::ChildrenModified()
{
  if (!_children.empty()) {
    std::vector<Transform *>::iterator it = _children.begin();
    std::vector<Transform *>::iterator it_e = _children.end();
    for (; it != it_e; ++it) {
      (*it)->_updated = false;
      (*it)->_moved = true;
      (*it)->ChildrenModified();
    }
  }
}
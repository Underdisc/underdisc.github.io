/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file RendererPoo.h
\author Connor Deakin
\par E-mail: connor.deakin\@digipen.edu
\par Project: Graphics
\date 21/03/2017
\brief
  The interface for the RendererPool.
*/
/*****************************************************************************/

#ifndef RENDERERPOOL_H
#define RENDERERPOOL_H

#include <GL/glew.h>

#include "ShaderScreen.h"
#include "Camera.h"
#include "Renderer.h"


//temp
#include "Texture.h"

/*****************************************************************************/
/*!
\class RendererPool
\brief
  Used to manage all renderers and process all renderes in a single step.

\par Important Notes
  - Make sure to Initialize at the start and purge at the end
    of the program.
*/
/*****************************************************************************/
class RendererPool
{
public:
  static void Initialize();
  static void Add(Renderer * new_renderer, Camera * camera);
  static void Remove(Renderer * dead_renderer, Camera * camera);
  static void Clear();
  static void Render();
  static void SetScreenShader(const ShaderScreen * screen_shader);
  static void Purge();
private:
  //! All of the Renderers in the RenderPool.
  static std::vector<std::pair<Renderer *, Camera *> > _renderers;
  static void RenderWater();
  static void GenerateFrameBuffer();
  static void GenerateFrameTexture();
  static void GenerateRenderBuffer();
  static void UpdateBufferDimensions();
  //! The ID of the frame buffer that Renderers are rendered to.
  static GLuint _frameBuffer;
  //! The ID for the texture that is used on the frame buffer.
  static GLuint _frameTexture;
  //! The ID for the render buffer used by the frame buffer.
  static GLuint _renderBuffer;
  //! The pixel width of the frame buffer.
  static int _bufferWidth;
  //! The pixel height of the frame buffer.
  static int _bufferHeight;
  //! The shader that will be used to display the frames from Renderers.
  static const ShaderScreen * _screenShader;

  RendererPool() {}
};

#endif // !RENDERERPOOL_H


/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file RendererPool.cpp
\author Connor Deakin
\par E-mail: connor.deakin\@digipen.edu
\par Project: Graphics
\date 21/03/2017
\brief
  Contains the implementation of the RendererPool.
*/
/*****************************************************************************/

#include <glm/glm/gtc/matrix_transform.hpp> 
#include <iostream>

#include "OpenGLError.h"
#include "Context.h"
#include "ShaderPool.h"
#include "GraphicPool.h"
#include "RendererWater.h"

#include "RendererPool.h"


//! A Renderer, Camera pair.
typedef std::pair<Renderer *, Camera *> rcp;

// static initializations
std::vector<rcp> RendererPool::_renderers = std::vector<rcp>();
GLuint RendererPool::_frameTexture = 0;
GLuint RendererPool::_frameBuffer = 0;
GLuint RendererPool::_renderBuffer = 0;
int RendererPool::_bufferWidth = 0;
int RendererPool::_bufferHeight = 0;
const ShaderScreen * RendererPool::_screenShader = nullptr;


/*****************************************************************************/
/*!
\brief
  Initializes the RendererPool, so the RendererPool has a frame buffer to draw
  all of the existing Renderers to.
*/
/*****************************************************************************/
void RendererPool::Initialize()
{
  try {
    _screenShader = &ShaderPool::Screen();
    _bufferWidth = Context::Width();
    _bufferHeight = Context::Height();
    GenerateFrameBuffer();
  }
  catch (const Error & error) {
    std::cout << error << std::endl;
  }
}

/*****************************************************************************/
/*!
\brief
  Add a new Renderer to the RenderPool.

\param new_renderer
  The Renderer being added to the Render.
\param camera
  The Camera that will be used for the new Renderer.
*/
/*****************************************************************************/
void RendererPool::Add(Renderer * new_renderer, Camera * camera)
{
  _renderers.push_back(rcp(new_renderer, camera));
}

/*****************************************************************************/
/*!
\brief
  Remove a Renderer from the RendererPool.

\param renderer
  The renderer that will be removed from the pool.
\param camera
  The camera that was being used with the renderer.
*/
/*****************************************************************************/
void RendererPool::Remove(Renderer * renderer, Camera * camera)
{
  // find and delete
  rcp value(renderer, camera);
  std::vector<rcp>::iterator it = _renderers.begin();
  std::vector<rcp>::iterator it_e = _renderers.end();
  for (; it != it_e; ++it){
    if (*it == value) {
      _renderers.erase(it);
      return;
    }
  }
  // not found
  Error error("RendererPool.cpp", "Remove");
  error.Add("The Renderer Camera pair was not found in the Pool");
  throw(error);
}

/*****************************************************************************/
/*!
\brief
  Clears all Rendere Camera pairs from the RenderPool.
*/
/*****************************************************************************/
void RendererPool::Clear()
{
  _renderers.clear();
}

/*****************************************************************************/
/*!
\brief
  Renders all Renderers from back to front currently in the RendererPool.
*/
/*****************************************************************************/
void RendererPool::Render()
{
  // make sure buffer dimensions are up to date
  if (_bufferWidth != Context::Width() || _bufferHeight != Context::Height())
    UpdateBufferDimensions();
  RenderWater();
  // find camera to ndc (context aspect)
  glm::mat4 camera_to_ndc;
  glm::vec3 context_scale(1.0f / Context::AspectRatio(), 1.0f, 1.0f);
  camera_to_ndc = glm::scale(camera_to_ndc, context_scale);
  // Render all renderers
  glEnable(GL_BLEND);
  glDepthFunc(GL_LEQUAL);
  auto it = _renderers.begin();
  auto it_e = _renderers.end();
  for (; it != it_e; ++it) {
    // binding, clearing, and preping frame buffer
    glBindFramebuffer(GL_FRAMEBUFFER, _frameBuffer);
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glEnable(GL_DEPTH_TEST);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    // error check
    GLenum error_code = glGetError();
    OPENGLERRORCHECK("RenderPool.cpp", "Render",
                     "While binding frame buffer.", error_code);
     // drawing to framebuffer
    glm::mat4 world_to_ndc(camera_to_ndc * it->second->WorldToCamera());
    it->first->Render(world_to_ndc);
    // draw complete
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glDisable(GL_DEPTH_TEST);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    // error check
    error_code = glGetError();
    OPENGLERRORCHECK("RenderPool.cpp", "Render",
                     "While unbinding frame buffer.", error_code);
    // drawing frame buffer
    _screenShader->Use();
    glBindTexture(GL_TEXTURE_2D, _frameTexture);
    //error check
    error_code = glGetError();
    OPENGLERRORCHECK("RenderPool.cpp", "Render",
                     "While binding frame texture.", error_code);
    GraphicPool::Screen().Draw();
  }
}

/*****************************************************************************/
/*!
\brief
  Sets the shader that individual frames are drawn to the screen with.

\param screen_shader The shader that will be used for screen drawing operations.
*/
/*****************************************************************************/
void RendererPool::SetScreenShader(const ShaderScreen * screen_shader)
{
  _screenShader = screen_shader;
}

/*****************************************************************************/
/*!
\brief
  Deletes the frame buffer that the renderers are rendered too.
*/
/*****************************************************************************/
void RendererPool::Purge()
{
  glDeleteFramebuffers(1, &_frameBuffer);
}

/*!
\brief Renders water to the frame buffer and then renders the frame to
 the screen.
*/
void RendererPool::RenderWater()
{
  // Render water to frame texutre
  glBindFramebuffer(GL_FRAMEBUFFER, _frameBuffer);
  glDisable(GL_DEPTH_TEST);
  RendererWater::Render();
  glBindFramebuffer(GL_FRAMEBUFFER, 0);
  // draw frame texture to screen
  _screenShader->Use();
  glBindTexture(GL_TEXTURE_2D, _frameTexture);
  GraphicPool::Screen().Draw();
}

/*!
\brief Creates the RendererPool's frame buffer.
*/
void RendererPool::GenerateFrameBuffer()
{
  // generate frame buffer
  glGenFramebuffers(1, &_frameBuffer);
  glBindFramebuffer(GL_FRAMEBUFFER, _frameBuffer);
  GLenum error_code = glGetError();
  if (error_code) {
    OpenGLError error("Renderer.cpp", "Renderer()");
    error.Code(error_code);
    error.Add("Encountered while generating the frame buffer.");
    throw(error);
  }
  // generate texture and render buffer
  GenerateFrameTexture();
  GenerateRenderBuffer();
  // make sure the buffer is complete
  if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) {
    OpenGLError error("Renderer.cpp", "Renderer()");
    error.Add("The frame buffer was not successfully completed");
    throw(error);
  }
  glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

/*!
\brief Creates the RendererPool's texture that is used for the frame buffer.
*/
void RendererPool::GenerateFrameTexture()
{
  // generate frame texture
  glGenTextures(1, &_frameTexture);
  glBindTexture(GL_TEXTURE_2D, _frameTexture);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, _bufferWidth, _bufferHeight,
               0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glBindTexture(GL_TEXTURE_2D, 0);
  // attach texture to frame buffer
  glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0,
                         GL_TEXTURE_2D, _frameTexture, 0);
  // error check
  GLenum error_code = glGetError();
  if (error_code) {
    OpenGLError error("Renderer.cpp", "GenerateFrameTexture");
    error.Code(error_code);
    error.Add("Encountered while generating and attaching frame texture.");
    throw(error);
  }
}

/*!
\brief Creates the render buffer that is used for the frame buffer.
*/
void RendererPool::GenerateRenderBuffer()
{
  // create render buffer
  glGenRenderbuffers(1, &_renderBuffer);
  glBindRenderbuffer(GL_RENDERBUFFER, _renderBuffer);
  glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH24_STENCIL8,
                        _bufferWidth, _bufferHeight);
  glBindRenderbuffer(GL_RENDERBUFFER, 0);
  // attach render buffer to frame buffer
  glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_STENCIL_ATTACHMENT,
                            GL_RENDERBUFFER, _renderBuffer);
  // error check
  GLenum error_code = glGetError();
  if (error_code) {
    OpenGLError error("Renderer.cpp", "GenerateFrameTexture");
    error.Code(error_code);
    error.Add("Encountered while generating and attaching render buffer.");
    throw(error);
  }
}


/*!
\brief Updates the dimensions of the frame texture and render buffer with the
  Context's current width and height.
*/
void RendererPool::UpdateBufferDimensions()
{
  // new width and height
  _bufferWidth = Context::Width();
  _bufferHeight = Context::Height();
  // update size of frame texture
  glBindTexture(GL_TEXTURE_2D, _frameTexture);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, _bufferWidth, _bufferHeight,
               0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
  glBindTexture(GL_TEXTURE_2D, 0);
  // updated size of render buffer
  glBindRenderbuffer(GL_RENDERBUFFER, _renderBuffer);
  glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH24_STENCIL8,
                        _bufferWidth, _bufferHeight);
  glBindRenderbuffer(GL_RENDERBUFFER, 0);
}

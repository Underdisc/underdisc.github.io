/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file Renderer.h
\author Connor Deakin
\par E-mail: connor.deakin\@digipen.edu
\par Project: Graphics
\date 10/03/2017
\brief
  Contains the interface for the Renderer.
*/
/*****************************************************************************/

#ifndef RENDERER_H
#define RENDERER_H

#include <vector>
#include <utility>
#include <GLM/glm/mat4x4.hpp>

#include "TileMap.h"
#include "Sprite.h"
#include "Transform.h"
#include "Emitter.h"

/*****************************************************************************/
/*!
\class Renderer
\brief
  Used to display a set of sprites at the locations defined by the Transforms
  paired with the Sprites.
*/
/*****************************************************************************/
class Renderer
{
  public:
    Renderer();
    void Render(const glm::mat4 & world_to_ndc);
    void Add(const Sprite * sprite, Transform * transform);
    void Add(const TileMap * tile_map);
    void Add(Emitter* emitter);
    void Remove(const Sprite * sprite, Transform * transform);
    void Remove(const TileMap * tile_map);
    void Remove(const Emitter * emitter);
    void Activate();
    void Deactivate();
    void Clear();
  private:
    void RenderTileMaps(const glm::mat4 & world_to_ndc);
    //! Tracks whether this Renderer does anything when Render is called.
    bool _active;
    //! A sprite transform pair.
    typedef std::pair<const Sprite *, Transform *> stp;
    //! The vector of Sprite / Transform pairs to be rendered.
    std::vector<stp> _sprites;
    std::vector<Emitter*> _emitters;
    //! The tile maps that will be drawn by the renderer.
    std::vector<const TileMap *> _tileMaps;
};

#endif //!RENDERER_H


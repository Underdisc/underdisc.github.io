/* All content(c) 2016 - 2017 DigiPen(USA) Corporation, all rights reserved. */
/*****************************************************************************/
/*!
\file Renderer.cpp
\author Connor Deakin
\par E-mail: connor.deakin\@digipen.edu
\par Project: Graphics
\date 10/03/2017
\brief
  Contains the implementation of the Renderer.
*/
/*****************************************************************************/

#include <algorithm>
#include <glm/glm/gtc/matrix_transform.hpp> 

#include "Context.h"
#include "Error.h"

#include "Renderer.h"

/*!
\brief Creates an empty Renderer.
*/
Renderer::Renderer() : _active(true), _sprites(), _tileMaps()
{}

/*****************************************************************************/
/*!
\brief
  Draws all the Sprites in the Renderer at their specified location.

\param world_to_ndc
  The World to NDC matrix transformation to be applied to all Sprite world
  coordinates.
*/
/*****************************************************************************/
void Renderer::Render(const glm::mat4 & world_to_ndc)
{
  // make sure renderer is active
  if (!_active)
    return;
  // draw emitters
  for (Emitter *emitter : _emitters) {
    emitter->Update(world_to_ndc);
  }
  // draw tile maps
  RenderTileMaps(world_to_ndc);
  // sort by Z values
  std::sort(_sprites.begin(), _sprites.end(), [] (stp a, stp b){
    return a.second->Z() < b.second->Z();
  });
  // draw sprites
  auto it = _sprites.begin();
  auto it_e = _sprites.end();
  for (; it != it_e; ++it) {
    // draw only active sprites
    if (it->first->_active) {
      glm::mat4 transformation = (world_to_ndc * it->second->ObjectToWorld());
      it->first->Draw(transformation);
    }
  }
}

/*****************************************************************************/
/*!
\brief
  Adds a new Sprite / Transform pair to the Renderer.

\param sprite
  The Sprite that will be drawn during the Renderer.
\param transform
  The transformation applied to the Sprite.
*/
/*****************************************************************************/
void Renderer::Add(const Sprite * sprite, Transform * transform)
{
  _sprites.push_back(std::pair<const Sprite *, Transform *>(sprite, transform));
}

/*****************************************************************************/
/*!
\brief
Adds a new Emitter to the Renderer.

\param emitter
The emitter that will be drawn during the Renderer.

*/
/*****************************************************************************/
void Renderer::Add(Emitter * emitter)
{
  _emitters.push_back(emitter);
}


/*****************************************************************************/
/*!
\brief
  Adds a tile map to the renderer that will be rendered at the start of every
  Render call.

\param tile_map
  The tile_map to be rendererd by the renderer.
*/
/*****************************************************************************/
void Renderer::Add(const TileMap * tile_map)
{
  _tileMaps.push_back(tile_map);
}

/*****************************************************************************/
/*!
\brief
  Remove a Sprite / Transform pair from the Renderer so it is no longer
  displayed on the screen.

\par Important Notes
  - If the Sprite / Transform pair does not exist, an exception will be thrown.

\param sprite
  The Sprite that is being removed.
\param transform
  The transformation that was being applied to the Sprite.
*/
/*****************************************************************************/
void Renderer::Remove(const Sprite * sprite, Transform * transform)
{
  // value to find
  std::pair<const Sprite *, Transform *> value(sprite, transform);
  auto it = _sprites.begin();
  auto it_e = _sprites.end();
  // finding and deleting
  for (; it != it_e; ++it) {
    if (*it == value) {
      _sprites.erase(it);
      return;
    }
  }
  // not found
  Error error("Renderer.cpp", "Remove");
  error.Add("The Sprite / Transform pair being removed "
            "was not in the renderer.");
  throw(error);
}

/*****************************************************************************/
/*!
\brief
  Remove a tile map from the Renderer so it is no longer drawn when this
  Renderer's Render is called.

\param tile_map
  The tile map being removed.
*/
/*****************************************************************************/
void Renderer::Remove(const TileMap * tile_map)
{
  std::vector<const TileMap *>::iterator it = _tileMaps.begin();
  std::vector<const TileMap *>::iterator it_e = _tileMaps.end();
  // removing tile map from renderer
  for (; it != it_e; ++it) {
    if (*it == tile_map) {
      _tileMaps.erase(it);
      return;
    }
  }
  // not found
  Error error("Renderer.cpp", "Remove");
  error.Add("The tile map being removed is not in the Renderer.");
  throw(error);
}

void Renderer::Remove(const Emitter * emitter)
{
  std::vector<Emitter *>::iterator it = _emitters.begin();
  std::vector<Emitter *>::iterator it_e = _emitters.end();
  // removing emitter
  for (; it != it_e; ++it) {
    if (*it == emitter) {
      _emitters.erase(it);
      return;
    }
  }
  // emitter not found
  Error error("Renderer.cpp", "Remove");
  error.Add("The emitter being removed is not in the Renderer.");
  throw(error);
}

/*!
\brief Forces the Renderer to display when Render is called.
*/
void Renderer::Activate()
{
  _active = true;
}

/*!
\brief Stops the Renderer from displaying when Render is called.
*/
void Renderer::Deactivate()
{
  _active = false;
}

/*****************************************************************************/
/*!
\brief
  Removes all the Sprite Transform pairs from the Renderer.
*/
/*****************************************************************************/
void Renderer::Clear()
{
  _sprites.clear();
  _tileMaps.clear();
}

/*****************************************************************************/
/*!
\brief
  Renders all of the tilemaps that are currently on this Renderer.

\param world_to_ndc
  The world to ndc matrix applied to each tile transform.
*/
/*****************************************************************************/
inline void Renderer::RenderTileMaps(const glm::mat4 & world_to_ndc)
{
  Transform tile;
  auto it = _tileMaps.begin();
  auto it_e = _tileMaps.end();
  // going through all tilemaps
  for (; it != it_e; ++it) {
    // prep tile data
    const TileData * tile_data = (*it)->GetTileData();
    const glm::vec2 * start = &(tile_data->base_pos);
    float scale = tile_data->Scale;
    tile.SetScale(tile_data->Scale);
    // drawing all tiles
    unsigned num_rows = (tile_data->_tileMap)->size();
    for (unsigned row = 0; row < num_rows; ++row) {
      // next row translation
      tile.SetTranslation(glm::vec3(start->x, start->y - row * scale, -8.0f));
      unsigned num_cols = (*tile_data->_tileMap)[row].size();
      for (unsigned col = 0; col < num_cols; ++col) {
        unsigned int frame_number = (*tile_data->_tileMap)[row][col];
        if (frame_number != 0) {
          tile_data->texture_sheet->SetFrameNumber(frame_number - 1);
          tile_data->texture_sheet->Draw(world_to_ndc * tile.ObjectToWorld());
        }
        tile.Translation() += glm::vec3(scale, 0.0f, 0.0f);
      }
    }
  }
}

